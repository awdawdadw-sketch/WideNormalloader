#include "../src/fault_report.h"
#include <assert.h>
#include <string>
#include <stdio.h>
static volatile LONG recovered=0;
static LONG CALLBACK recover(EXCEPTION_POINTERS* p){
    if(p->ExceptionRecord->ExceptionCode==EXCEPTION_ACCESS_VIOLATION){InterlockedIncrement(&recovered);return EXCEPTION_CONTINUE_EXECUTION;}
    return EXCEPTION_CONTINUE_SEARCH;
}
static DWORD WINAPI worker(void*){ULONG_PTR args[]={1,0x12345678};RaiseException(EXCEPTION_ACCESS_VIOLATION,0,2,args);return 0;}
int main(){
    using namespace wide::faults;
    assert(!selected(0xE06D7363));assert(!selected(EXCEPTION_BREAKPOINT));assert(selected(EXCEPTION_ACCESS_VIOLATION));
    assert(initialize());assert(findModule((DWORD)(uintptr_t)&main)>=0);
    stage("test_stage");counts(1024,15);
    PVOID recovery=AddVectoredExceptionHandler(0,recover);assert(recovery);
    worker(nullptr);HANDLE thread=CreateThread(nullptr,0,worker,nullptr,0,nullptr);assert(thread);
    assert(WaitForSingleObject(thread,10000)==WAIT_OBJECT_0);CloseHandle(thread);
    assert(read(recovered)==2);assert(read(eventCount)==2);
    // Exercise unreadable stack and no cached module without dereferencing them.
    EXCEPTION_RECORD record{};record.ExceptionCode=EXCEPTION_ILLEGAL_INSTRUCTION;record.ExceptionAddress=(void*)0x1234;
    CONTEXT context{};context.Eip=0x1234;context.Esp=1;EXCEPTION_POINTERS pointers{&record,&context};
    assert(observe(&pointers)==EXCEPTION_CONTINUE_SEARCH);assert(read(eventCount)==3);
    record.ExceptionCode=EXCEPTION_BREAKPOINT;assert(observe(&pointers)==EXCEPTION_CONTINUE_SEARCH);assert(read(eventCount)==3);
    // A fault arriving during another report must pass through without a lock.
    record.ExceptionCode=EXCEPTION_ACCESS_VIOLATION;InterlockedExchange(&busy,1);
    assert(observe(&pointers)==EXCEPTION_CONTINUE_SEARCH);assert(read(eventCount)==3);InterlockedExchange(&busy,0);
    controlledStop("test deliberate stop");assert(read(eventCount)==3);
    RemoveVectoredExceptionHandler(recovery);RemoveVectoredExceptionHandler(handler);handler=nullptr;
    CloseHandle(report);report=INVALID_HANDLE_VALUE;
    HANDLE input=CreateFileW(reportPath,GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,0,nullptr);assert(input!=INVALID_HANDLE_VALUE);
    char bytes[32768]{};DWORD got=0;assert(ReadFile(input,bytes,sizeof(bytes)-1,&got,nullptr));CloseHandle(input);
    std::string text(bytes,got);assert(text.find("last_loader_stage=test_stage")!=std::string::npos);
    assert(text.find("selected_plugin_count_hex=00000400")!=std::string::npos);
    assert(text.find("requested_adapter_mask_hex=0000000F")!=std::string::npos);
    assert(text.find("access_target=12345678")!=std::string::npos);
    assert(text.find("[outside cached module images")!=std::string::npos);
    assert(text.find("FIRST_CHANCE: may be handled later")!=std::string::npos);
    assert(text.find("reason=test deliberate stop")!=std::string::npos);
    puts("Fault observer checks passed: handled faults, worker thread, registers/context, invalid stack, filtering and pass-through.");
}
