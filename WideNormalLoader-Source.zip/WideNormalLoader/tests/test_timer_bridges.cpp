#include <windows.h>
#include <cstdio>
#ifdef WIDE_UPDATED_OPTIONAL
#include "../src/showoff_timer_runtime.h"
static constexpr uint32_t kCallRva=0x754A2,kRootRva=0xF7E4C;
static const unsigned char kOriginalCall[]={0xe8,0x39,0x14,0,0};
#else
#include "../src/showoff_timer_runtime.h"
static constexpr uint32_t kCallRva=0x75402,kRootRva=0xF6E4C;
static const unsigned char kOriginalCall[]={0xe8,0x99,0x12,0,0};
#endif
using namespace wide;
#define CHECK(x) do{if(!(x)){fprintf(stderr,"FAIL %u %s\n",__LINE__,#x);ExitProcess(1);}}while(0)
static uint32_t savedSp,registers[9],chosen,seenScript,seenKey,writes;
alignas(16) static unsigned char beforeFx[512],afterFx[512],frame[128];
static uint32_t event[4],node[5];
static void clobber(){__asm__ __volatile__("pxor %%xmm0,%%xmm0\n\tfld1":::"xmm0");}
static uint32_t __cdecl getOwner(void* script){seenScript=uint32_t(script);clobber();return seenScript;}
static uint32_t __cdecl match(void* script,uint32_t key){seenKey=key;return getOwner(script)==key;}
static uint32_t __cdecl getClear(void* script,uint32_t mode){seenKey=mode;auto own=getOwner(script);return mode==2?255:own;}
static void __cdecl writer(){++writes;clobber();}
static bool resolve(void* script,uint32_t& value){value=uint32_t(script);return true;}
static LONG CALLBACK fault(EXCEPTION_POINTERS* p){fprintf(stderr,"EXCEPTION %08lX EIP=%08lX\n",p->ExceptionRecord->ExceptionCode,p->ContextRecord->Eip);ExitProcess(2);}
int main(){
    SetErrorMode(SEM_FAILCRITICALERRORS|SEM_NOGPFAULTERRORBOX);AddVectoredExceptionHandler(1,fault);
    auto* image=(unsigned char*)VirtualAlloc(nullptr,0x110000,MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);CHECK(image);
    uint32_t base=uint32_t(image);unsigned runs=0;
    for(auto& site:timerBridgeSites){
        auto stub=ShowOffTimerRuntime::stub(site,base+0x1000,base,uint32_t(getOwner),uint32_t(match),uint32_t(getClear),uint32_t(writer));
        CHECK(stub.size()<256);memcpy(image+0x1000,stub.data(),stub.size());
        std::vector<unsigned char> bytes;auto b=[&](std::initializer_list<unsigned char> v){bytes.insert(bytes.end(),v);};auto w=[&](uint32_t v){auto* p=(unsigned char*)&v;bytes.insert(bytes.end(),p,p+4);};
        auto landing=[&](uint32_t rva,uint32_t choice){bytes.clear();b({0xc7,0x05});w(uint32_t(&chosen));w(choice);b({0xe9});w(base+0x800-(base+rva)-uint32_t(bytes.size())-4);memcpy(image+rva,bytes.data(),bytes.size());};
        landing(site.kind==4?site.target:site.end,1);if(site.kind==2)landing(site.target,0);
        bytes.clear();b({0x9c,0x60,0x89,0xe6,0xbf});w(uint32_t(registers));b({0xb9});w(9);b({0xf3,0xa5,0x0f,0xae,0x05});w(uint32_t(afterFx));
        b({0x8b,0x25});w(uint32_t(&savedSp));b({0x61,0x9d,0xc3});memcpy(image+0x800,bytes.data(),bytes.size());
        for(uint32_t own:{0u,252u,255u,256u,1000u,1001u,1026u,UINT32_MAX})for(unsigned alternate=0;alternate<2;++alternate){
            event[1]=own;node[1]=alternate?own^1:own;*(uint32_t*)(frame+64+0x18)=own;*(uint32_t*)(frame+64-0x14)=uint32_t(node);
            uint32_t ecx=alternate?2:1;chosen=99;seenScript=seenKey=0;unsigned prior=writes;
            bytes.clear();b({0x9c,0x60,0x89,0x25});w(uint32_t(&savedSp));
            b({0xb8});w(0x12345678);b({0xbb});w(uint32_t(event));b({0xb9});w(ecx);b({0xba});w(0x44556677);
            b({0xbe});w(0x55667788);b({0xbf});w(uint32_t(event));b({0xbd});w(uint32_t(frame+64));
            b({0x0f,0xae,0x05});w(uint32_t(beforeFx));b({0x68});w(0x287);b({0x9d,0xe9});w(base+0x1000-base-uint32_t(bytes.size())-4);
            memcpy(image,bytes.data(),bytes.size());FlushInstructionCache(GetCurrentProcess(),image,0x110000);
            ((void(__cdecl*)())image)();++runs;CHECK(!memcmp(beforeFx,afterFx,512));
            uint32_t expected[]={uint32_t(event),0x55667788,uint32_t(frame+64),0,uint32_t(event),0x44556677,ecx,0x12345678};
            if(site.kind==0 || site.kind==1 || site.kind==3)expected[site.target/4]=site.kind==3 && alternate?255:own;
            for(unsigned i=0;i<8;++i)if(i!=3)CHECK(registers[i]==expected[i]);
            if(site.kind==2){CHECK(chosen==!alternate && seenScript==own && seenKey==node[1]);CHECK((registers[8]&~0x40u)==0x287 && bool(registers[8]&0x40)==!alternate);}
            else {CHECK(chosen==1 && registers[8]==0x287);if(site.kind==4)CHECK(writes==prior+1);else CHECK(seenScript==own);}
            if(site.kind==3)CHECK(seenKey==ecx);
        }
    }
    // Preflight and rollback operate on all 29 spans as one transaction.
    memset(image,0,0x110000);
    for(auto& s:timerWidthSites)memcpy(image+s.rva,s.before,s.size);
    for(auto& s:timerBridgeSites){auto bytes=ShowOffTimerRuntime::expected(s,base);memcpy(image+s.begin,bytes.data(),bytes.size());}
    memcpy(image+kCallRva,kOriginalCall,5);
    ShowOffTimerRuntime runtime;
    CHECK(base!=0x10000000u && timerBridgeSites[11].relocationCount==1 && timerBridgeSites[12].relocationCount==3);
    // The original failed guard compared preferred-base bytes in a rebased DLL.
    // Reject that stale representation, then accept the loader-relocated span.
    auto relocated=ShowOffTimerRuntime::expected(timerBridgeSites[11],base);
    CHECK(memcmp(relocated.data(),timerBridgeSites[11].bytes,relocated.size()));
    memcpy(image+timerBridgeSites[11].begin,timerBridgeSites[11].bytes,relocated.size());
    CHECK(!runtime.installSynthetic(base,resolve,1024));memcpy(image+timerBridgeSites[11].begin,relocated.data(),relocated.size());
    *(uint32_t*)(image+kRootRva)=1;CHECK(!runtime.installSynthetic(base,resolve,1024));*(uint32_t*)(image+kRootRva)=0;
    image[timerBridgeSites[0].begin]^=1;CHECK(!runtime.installSynthetic(base,resolve,1024));image[timerBridgeSites[0].begin]^=1;
    CHECK(runtime.installSynthetic(base,resolve,1024));runtime.uninstallSynthetic();
    for(auto& s:timerWidthSites)CHECK(!memcmp(image+s.rva,s.before,s.size));
    for(auto& s:timerBridgeSites){auto bytes=ShowOffTimerRuntime::expected(s,base);CHECK(!memcmp(image+s.begin,bytes.data(),bytes.size()));}CHECK(!memcmp(image+kCallRva,kOriginalCall,5));
    VirtualFree(image,0,MEM_RELEASE);
    printf("PASS: %u x86 bridge calls across 13 spans; full owners, callback branches, public clear, writer ABI, GPR/flags/x87/SSE preservation, four PE relocations, stale preferred-base rejection, preflight and rollback. Synthetic image only.\n",runs);
}
