#include "jip_profile_test_addresses.h"
#define WIDE_JIP_LINK_TEST
#include "../src/nvse_abi.h"
#include "../src/nvse_commands.h"
#include "../src/jip_link_owners_runtime.h"
#include <cstdio>
#include <cstdlib>
#define CHECK(x) do{if(!(x)){printf("FAIL line %d: %s\n",__LINE__,#x);exit(1);}}while(0)
static uint32_t base=0,tempValue=0,nativeCalls=0,tempCalls=0;
static unsigned char subject[32]{},target[32]{},entry[16]{};static uint32_t buckets[1]{};
static bool __thiscall nativeSet(void* s,void* t,uint8_t byte){CHECK(s==subject && t==target && byte==253);++nativeCalls;
    *(uint32_t*)(entry+4)=*(uint32_t*)(subject+0xc);*(uint32_t*)(entry+8)=*(uint32_t*)(target+0xc);entry[12]=byte;
    buckets[0]=uint32_t(entry);*(uint32_t*)(base+jipTestRva(0x6a31c))=uint32_t(buckets);*(uint32_t*)(base+jipTestRva(0x6a324))=1;return true;}
static uint32_t* __thiscall tempInsert(void* map,uint32_t id){CHECK(uint32_t(map)==base+jipTestRva(0x6a2f8) && id==0xff001111);++tempCalls;return &tempValue;}
int main(){base=uint32_t(VirtualAlloc(nullptr,0xa0000,MEM_RESERVE|MEM_COMMIT,PAGE_EXECUTE_READWRITE));CHECK(base);
    *(uint32_t*)(base+jipTestRva(0x6a320))=1;*(uint32_t*)(subject+0xc)=0xff001111;*(uint32_t*)(target+0xc)=0xff002222;
    *(uint8_t*)(base+jipTestRva(0x3610))=0xe9;*(uint32_t*)(base+jipTestRva(0x3611))=uint32_t(tempInsert)-(base+jipTestRva(0x3615));
    wide::JipLinkOwnersRuntime runtime;runtime.bindSynthetic(base,(void*)nativeSet);uint32_t owner=0;
    CHECK(!runtime.owner(0xff001111,0xff002222,253,owner));
    CHECK(runtime.restore(subject,target,1000));CHECK(nativeCalls==1 && tempCalls==1 && tempValue==0xff002222);
    CHECK(*(uint8_t*)(base+jipTestRva(0x7637a))==8);CHECK(runtime.owner(0xff001111,0xff002222,253,owner) && owner==1000);
    CHECK(runtime.restore(subject,target,1001));CHECK(nativeCalls==1 && tempCalls==2);CHECK(runtime.owner(0xff001111,0xff002222,253,owner) && owner==1001);
    CHECK(!runtime.owner(0xff001111,0xff999999,253,owner));runtime.clear();CHECK(!runtime.owner(0xff001111,0xff002222,253,owner));
    CHECK(runtime.owner(123,456,252,owner) && owner==252);CHECK(runtime.owner(123,456,255,owner) && owner==255);
    puts("PASS executed x86 link bridge: full authors, native byte, post-load retention, changed flag, adoption preserves default, unknown-owner rejection");
}
