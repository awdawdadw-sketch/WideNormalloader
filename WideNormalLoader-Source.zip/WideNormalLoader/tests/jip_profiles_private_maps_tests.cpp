#include "jip_profile_test_addresses.h"
#include <windows.h>
#include <cstdint>
#include "../src/nvse_abi.h"
#include "../src/nvse_commands.h"
#define WIDE_JIP_PRIVATE_MAP_TEST
#include "../src/jip_private_maps_runtime.h"
#include "../src/jip_condition_probe_inputs.h"
#include <cstdio>
using namespace wide;
#define CHECK(...) do{if(!(__VA_ARGS__)){fprintf(stderr,"FAIL %d %s\n",__LINE__,#__VA_ARGS__);ExitProcess(1);}}while(0)
static unsigned char* image;static WideCommandInfo infos[32];
static uint32_t savedSp,registers[9],requested;
alignas(16) static unsigned char beforeFx[512],afterFx[512],frame[128];
static LONG CALLBACK fault(EXCEPTION_POINTERS* p){fprintf(stderr,"EXCEPTION %08lX EIP=%08lX\n",p->ExceptionRecord->ExceptionCode,p->ContextRecord->Eip);ExitProcess(2);}
static bool source(void* script,uint32_t& owner){
    requested=uint32_t(script);owner=requested;
    __asm__ __volatile__("pxor %%xmm0,%%xmm0\n\tfld1":::"xmm0");
    return PluginOwnerScope::valid(owner);
}
static const WideCommandInfo* __cdecl byName(const char* name){for(auto& info:infos)if(!strcmp(info.longName,name))return &info;return nullptr;}
int main(){
    const auto& testMapCommands=wide::jipBuild==wide::JipBuild::PPLN?wide::jipPPMapCommands:wide::jipMapCommands;
    const auto& testOwnerSites=wide::jipBuild==wide::JipBuild::PPLN?wide::jipPPMapOwnerSites:wide::jipMapOwnerSites;
    SetErrorMode(SEM_FAILCRITICALERRORS|SEM_NOGPFAULTERRORBOX);AddVectoredExceptionHandler(1,fault);
    image=(unsigned char*)VirtualAlloc(nullptr,0xa0000,MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);CHECK(image);
    // Pinned position-independent JIP GetVariable body, executed only in this
    // inert allocation: checks the controlled condition-input layout and ABI.
    const unsigned char getVariable[]={0x8b,0x41,0x0c,0x0f,0x1f,0x40,0,0x66,0x0f,0x1f,0x84,0,0,0,0,0,0x85,0xc0,0x74,0x0f,0x8b,0x08,0x8b,0x40,0x04,0x85,0xc9,0x74,0xf3,0x39,0x11,0x75,0xef,0x8b,0xc1,0xc3};
    memcpy(image+jipTestRva(0x573a0),getVariable,sizeof(getVariable));
    auto get=(JipConditionVariable*(__fastcall*)(JipConditionLocals*,uint32_t))(image+jipTestRva(0x573a0));
    JipConditionVariable first{37,0,123,0,{}},second{38,0,456,0,{}};
    JipConditionNode tail{&second,nullptr},head{&first,&tail},empty{nullptr,&head};
    JipConditionLocals locals{nullptr,0,nullptr,&empty,nullptr};
    CHECK(get(&locals,37)==&first && get(&locals,38)==&second && !get(&locals,39));
    locals.variables=nullptr;CHECK(!get(&locals,37));
    size_t n=0;for(auto& s:testMapCommands){infos[n].longName=s.name;infos[n++].execute=(CommandExecute)(image+s.entry);}
    infos[n].longName="AuxVarGetFltCond";infos[n].eval=image+wide::jipRva(wide::jipMapConditionEval);
    std::vector<void*> harness;
    for(auto& s:testOwnerSites){memcpy(image+s.call,s.callBytes,5);memcpy(image+s.narrow,s.narrowBytes,3);
        if(s.narrow!=s.call+5){const unsigned char compare[]={0x83,0x7d,0xec,0};memcpy(image+s.call+5,compare,4);}
        auto* memory=(unsigned char*)VirtualAlloc(nullptr,256,MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);CHECK(memory);harness.push_back(memory);
        std::vector<unsigned char> bytes;
        auto b=[&](std::initializer_list<unsigned char> v){bytes.insert(bytes.end(),v);};auto w=[&](uint32_t v){auto* p=(unsigned char*)&v;bytes.insert(bytes.end(),p,p+4);};
        b({0x9c,0x60,0x89,0x25});w(uint32_t(&savedSp));
        // The caller's chosen ECX script is patched for each test invocation.
        b({0xb9});w(1000);b({0xb8});w(0x123400fd);b({0xbb});w(0x11223344);b({0xbe});w(0x55667788);b({0xbf});w(0x99aabbcc);b({0xba});w(0x10203040);b({0xbd});w(uint32_t(frame+64));
        b({0x0f,0xae,0x05});w(uint32_t(beforeFx));b({0x68});w(0x202);b({0x9d,0xe9});w(uint32_t(image+s.call)-uint32_t(memory)-uint32_t(bytes.size())-4);
        memcpy(memory,bytes.data(),bytes.size());bytes.clear();
        b({0x9c,0x60,0x89,0xe6,0xbf});w(uint32_t(registers));b({0xb9});w(9);b({0xf3,0xa5,0x0f,0xae,0x05});w(uint32_t(afterFx));b({0x8b,0x25});w(uint32_t(&savedSp));b({0x61,0x9d,0xc3});
        memcpy(image+s.narrow+3,bytes.data(),bytes.size());
    }
    WideCommandTable table{};table.getName=byName;JipPrivateMapsRuntime runtime;
    for(uint32_t offset:{jipTestRva(0x6a30c),jipTestRva(0x6a318),jipTestRva(0x6a354),jipTestRva(0x6a360)}){*(uint32_t*)(image+offset)=1;CHECK(!runtime.installSynthetic((HMODULE)image,&table,source));*(uint32_t*)(image+offset)=0;}
    image[testOwnerSites[0].narrow]^=1;CHECK(!runtime.installSynthetic((HMODULE)image,&table,source));image[testOwnerSites[0].narrow]^=1;
    CHECK(runtime.installSynthetic((HMODULE)image,&table,source));
    uint32_t owners[]={0,252,255,256,1000,1001,1026,253};
    for(size_t i=0;i<harness.size();++i)for(auto owner:owners)for(unsigned clear=0;clear<2;++clear){
        auto& s=testOwnerSites[i];*(uint32_t*)((unsigned char*)harness[i]+9)=owner;
        *(uint32_t*)(frame+64-0x14)=clear;memset(beforeFx,0,512);memset(afterFx,0,512);
        ((void(__cdecl*)())harness[i])();uint32_t full=owner==253?UINT32_MAX:owner;CHECK(requested==owner && registers[7]==full);
        const unsigned offsets[]={7,6,5,4,3,2,1,0};unsigned reg=(s.narrowBytes[2]>>3)&7;
        CHECK(registers[offsets[reg]]==full);
        if(reg!=3)CHECK(registers[4]==0x11223344);if(reg!=6)CHECK(registers[1]==0x55667788);if(reg!=7)CHECK(registers[0]==0x99aabbcc);
        if(reg!=1)CHECK(registers[6]==owner);if(reg!=2)CHECK(registers[5]==0x10203040);CHECK(registers[2]==uint32_t(frame+64));
        CHECK(!memcmp(beforeFx,afterFx,512));
        if(s.narrow==s.call+5)CHECK((registers[8]&0x8d5)==0);else CHECK(bool(registers[8]&0x40)==!clear);
    }
    runtime.uninstallSynthetic();for(auto& s:testOwnerSites){CHECK(!memcmp(image+s.call,s.callBytes,5));CHECK(!memcmp(image+s.narrow,s.narrowBytes,3));}
    for(auto* h:harness)VirtualFree(h,0,MEM_RELEASE);VirtualFree(image,0,MEM_RELEASE);
    puts("PASS: 21 installed synthetic JIP owner transfers; ECX source capture; full owners and invalid sentinel; integer/flags/x87/SSE preservation; intervening cleanup compare; four nonempty-map rejection checks; mismatch rejection and rollback. No installed JIP/game code execution.");
}
