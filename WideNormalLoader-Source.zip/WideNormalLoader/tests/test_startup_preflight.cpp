#include "../src/startup_preflight.h"
using namespace wide::startup;
#define CHECK(x) do{if(!(x)){fprintf(stderr,"FAIL line %u: %s\n",__LINE__,#x);return 1;}}while(0)
static void sub(std::vector<unsigned char>& b,const char* tag,const std::vector<unsigned char>& data){b.insert(b.end(),tag,tag+4);uint16_t n=uint16_t(data.size());b.push_back(n&255);b.push_back(n>>8);b.insert(b.end(),data.begin(),data.end());}
static bool parse(std::vector<unsigned char> body,std::vector<std::string>& masters){unsigned char h[24]{};memcpy(h,"TES4",4);uint32_t n=uint32_t(body.size());memcpy(h+4,&n,4);std::string reason;return header(h,body,masters,reason);}
int main(int argc,char** argv){
    std::vector<std::string> names;
    CHECK(lines("\xef\xbb\xbf# comment\r\n Base.esm\r\n*Addon.esp\n",names));CHECK(names==std::vector<std::string>({"Base.esm","Addon.esp"}));
    CHECK(lines("Base.esm\n*Addon.esp\n",names,true));CHECK(names==std::vector<std::string>({"Addon.esp"}));
    CHECK(lines("Base.esm\nAddon.esp\n",names,true));CHECK(names.size()==2);
    CHECK(!lines("../bad.esp\n",names));CHECK(!lines(std::string("Bad\0Name.esp",12),names));
    auto d=compare({"Base.esm","Addon.esp"},{"Base.esm","Addon.esp","Extended.esp"},{"Base.esm","Addon.esp","Extended.esp"});
    CHECK(d.missing.empty() && !d.reordered && d.wideOnly==std::vector<std::string>({"Extended.esp"}));
    CHECK(compare({"Base.esm","New.esp"},{"Base.esm","New.esp"},{"Base.esm"}).missing==std::vector<std::string>({"New.esp"}));
    CHECK(compare({"Base.esm","Addon.esp"},{"Addon.esp","Base.esm"},{"Base.esm","Addon.esp"}).reordered);
    CHECK(!compare({"BASE.esm"},{"base.esm"},{"Base.esm"}).reordered);
    std::vector<unsigned char> body;sub(body,"HEDR",std::vector<unsigned char>(12));sub(body,"MAST",{'B','a','s','e','.','e','s','m',0});
    std::vector<std::string> masters;CHECK(parse(body,masters));CHECK(masters==std::vector<std::string>({"Base.esm"}));
    masters.clear();auto truncated=body;truncated.pop_back();CHECK(!parse(truncated,masters));
    masters.clear();auto duplicate=body;sub(duplicate,"MAST",{'b','a','s','e','.','e','s','m',0});CHECK(!parse(duplicate,masters));
    masters.clear();std::vector<unsigned char> bad;sub(bad,"MAST",{'A',0});CHECK(!parse(bad,masters));
    masters.clear();bad.clear();sub(bad,"HEDR",std::vector<unsigned char>(12));sub(bad,"XXXX",{12,0,0,0});CHECK(!parse(bad,masters));
    masters.clear();bad.clear();sub(bad,"HEDR",std::vector<unsigned char>(12));sub(bad,"MAST",{'A',0,'B',0});CHECK(!parse(bad,masters));
    masters.clear();bad.clear();sub(bad,"HEDR",std::vector<unsigned char>(12));
    for(unsigned i=0;i<256;++i){auto name=std::to_string(i)+".esm";std::vector<unsigned char> bytes(name.begin(),name.end());bytes.push_back(0);sub(bad,"MAST",bytes);}
    CHECK(!parse(bad,masters));
    std::string before="WideNormalLoader baseline v1\n";section(before,"MO2Active",{"Base.esm"});section(before,"MO2Order",{"Base.esm"});section(before,"WideOrder",{"Base.esm"});section(before,"PluginFiles",{});section(before,"NativeDLLs",{"test.dll|hashA"});section(before,"Settings",{"autodetect=1"});
    CHECK(validBaseline(before));CHECK(!validBaseline("WideNormalLoader baseline v2\n"));
    CHECK(sectionValues(before,"NativeDLLs")==std::vector<std::string>({"test.dll|hasha"}));CHECK(sectionValues(before,"PluginFiles").empty());
    CHECK(changedSections(before,before).empty());auto after=before;auto p=after.find("hasha");CHECK(p!=after.npos);after.replace(p,5,"hashb");CHECK(changedSections(before,after)==std::vector<std::string>({"NativeDLLs"}));
    wchar_t temp[MAX_PATH]{};CHECK(GetTempPathW(MAX_PATH,temp));auto file=std::wstring(temp)+L"WideNativePreflight-"+std::to_wstring(GetCurrentProcessId())+L".test";
    CHECK(writeAtomic(file,before));std::string got;std::wstring resolved;CHECK(text(file,got,&resolved));CHECK(got==before && !resolved.empty());
    CHECK(writeAtomic(file,after));CHECK(text(file,got));CHECK(got==after);CHECK(DeleteFileW(file.c_str()));
    CHECK(!exists(file));
    if(argc==2){
        std::string manifest;CHECK(text(widen(argv[1]),manifest));size_t pos=0;unsigned count=0;
        while(pos<manifest.size()){
            auto end=manifest.find('\n',pos);auto path=trim(manifest.substr(pos,end==manifest.npos?manifest.npos:end-pos));pos=end==manifest.npos?manifest.size():end+1;
            if(path.empty())continue;File f(widen(path));CHECK(f.h!=INVALID_HANDLE_VALUE);unsigned char h[24]{};CHECK(f.read(h,24));CHECK(u32(h+4)<=16*1024*1024);
            std::vector<unsigned char> data(u32(h+4));CHECK(data.empty() || f.read(data.data(),DWORD(data.size())));std::vector<std::string> ms;std::string why;
            if(!header(h,data,ms,why)){fprintf(stderr,"REJECTED %s: %s\n",path.c_str(),why.c_str());return 2;}++count;
        }
        printf("PASS: native parser accepted %u installed plugin headers\n",count);CHECK(count>0);
    }
    return 0;
}
