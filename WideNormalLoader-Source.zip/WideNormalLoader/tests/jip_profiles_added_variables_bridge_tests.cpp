#include "jip_profile_test_addresses.h"
#include <windows.h>
#include <stdint.h>
#include <cstdio>
#include "../src/nvse_abi.h"
#include "../src/nvse_commands.h"
#include "../src/jip_added_variables_runtime.h"
using namespace wide;
#define CHECK(x) do{if(!(x)){fprintf(stderr,"FAIL line=%u %s\n",__LINE__,#x);ExitProcess(1);}}while(0)
static uint32_t savedSp,registers[9],chosen,entrySeen,scriptSeen;
static bool answer;
alignas(16) static unsigned char beforeFx[512],afterFx[512],frame[128];
static bool __cdecl callback(uint32_t entry,void* script){entrySeen=entry;scriptSeen=uint32_t(script);
    __asm__ __volatile__("pxor %%xmm0,%%xmm0\n\tfld1":::"xmm0");return answer;}
int main(){
    AddedVariableOwners owners;
    CHECK(!owners.matches(17,253,1000));owners.assigned(17,253,1000);owners.assigned(18,253,1001);
    CHECK(owners.matches(17,253,1000) && !owners.matches(17,253,1001));
    CHECK(owners.matches(18,253,1001) && !owners.matches(18,253,1000));
    CHECK(!owners.matches(17,254,1000));owners.assigned(17,253,1001);
    CHECK(!owners.matches(17,253,1000) && owners.matches(17,253,1001));
    owners.assigned(17,253,253);CHECK(!owners.matches(17,253,1001));
    CHECK(owners.matches(99,252,252) && !owners.matches(99,252,1000));
    CHECK(owners.matches(99,255,255) && !owners.matches(99,255,1000));
    owners.clear();CHECK(!owners.matches(18,253,1001));
    auto* memory=(unsigned char*)VirtualAlloc(nullptr,1024,MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);CHECK(memory);
    auto stub=JipAddedVariablesRuntime::compareStub(uint32_t(memory+256),uint32_t(memory+700),uint32_t(memory+732),uint32_t(memory+800));
    CHECK(stub.size()<128);memcpy(memory+256,stub.data(),stub.size());
    std::vector<unsigned char> bytes;auto b=[&](std::initializer_list<unsigned char> v){bytes.insert(bytes.end(),v);};
    auto w=[&](uint32_t v){auto* p=(unsigned char*)&v;bytes.insert(bytes.end(),p,p+4);};
    b({0x9c,0x60,0x89,0x25});w(uint32_t(&savedSp));
    b({0xb8});w(0x12345678);b({0xbb});w(0x22334455);b({0xb9});w(0x33445566);b({0xba});w(0x44556677);
    b({0xbe});w(0x55667788);b({0xbf});w(0x66778899);b({0xbd});w(uint32_t(frame+64));
    b({0x0f,0xae,0x05});w(uint32_t(beforeFx));b({0x68});w(0x287);b({0x9d,0xe9});w(uint32_t(memory+256)-uint32_t(memory)-uint32_t(bytes.size())-4);
    memcpy(memory,bytes.data(),bytes.size());bytes.clear();
    b({0x9c,0x60,0x89,0xe6,0xbf});w(uint32_t(registers));b({0xb9});w(9);b({0xf3,0xa5,0x0f,0xae,0x05});w(uint32_t(afterFx));
    b({0x8b,0x25});w(uint32_t(&savedSp));b({0x61,0x9d,0xc3});memcpy(memory+512,bytes.data(),bytes.size());
    for(unsigned value=0;value<2;++value){bytes.clear();auto offset=value?700:732;
        b({0xc7,0x05});w(uint32_t(&chosen));w(value);b({0xe9});w(uint32_t(memory+512)-uint32_t(memory+offset)-uint32_t(bytes.size())-4);
        memcpy(memory+offset,bytes.data(),bytes.size());}
    *(uint32_t*)(frame+64+0x18)=0x778899aa;FlushInstructionCache(GetCurrentProcess(),memory,1024);
    // A valid x86 bool callback deliberately leaves nonzero upper EAX bits on
    // BOTH returns. Only AL describes its result. Also clobber x87 and SSE.
    bytes.clear();b({0x8b,0x44,0x24,0x04,0xa3});w(uint32_t(&entrySeen));
    b({0x8b,0x44,0x24,0x08,0xa3});w(uint32_t(&scriptSeen));
    b({0xb8});w(0x12345600);b({0xa0});w(uint32_t(&answer));b({0x66,0x0f,0xef,0xc0,0xd9,0xe8,0xc3});
    memcpy(memory+800,bytes.data(),bytes.size());FlushInstructionCache(GetCurrentProcess(),memory,1024);
    for(unsigned n=0;n<32;++n){answer=n&1;chosen=99;memset(beforeFx,0,512);memset(afterFx,0,512);
        ((void(__cdecl*)())memory)();CHECK(chosen==answer && entrySeen==0x66778899 && scriptSeen==0x778899aa);
        CHECK(registers[0]==0x66778899 && registers[1]==0x55667788 && registers[2]==uint32_t(frame+64));
        CHECK(registers[4]==0x22334455 && registers[5]==0x44556677 && registers[6]==0x33445566 && registers[7]==0x12345678);
        CHECK((registers[8]&~0x40u)==0x287 && bool(registers[8]&0x40)==answer);CHECK(!memcmp(beforeFx,afterFx,512));
    }
    VirtualFree(memory,0,MEM_RELEASE);
    puts("PASS: separate same-byte authors, reassignment, stale byte rejection, ambiguous owner rejection, legacy/public fallback, reset; 32 executed x86 comparison bridges preserve GPRs/stack/other flags/x87/SSE and take both branches with nonzero upper EAX bits on false/true bool returns.");
}
