#include "jip_profile_test_addresses.h"
#define WIDE_JIP_SCRIPT_LINK_TEST
#include "../src/jip_script_link_runtime.h"
#include <cstdio>
#include <cstdlib>
#define CHECK(x) do{if(!(x)){printf("FAIL line %d: %s\n",__LINE__,#x);exit(1);}}while(0)
static unsigned char quest[128]{},script[128]{},locals[32]{},variable[24]{},node[8]{};
static unsigned char from[128]{},to[128]{},vtable[256]{};
static unsigned calls=0;static uint32_t lastAuthor=0;
static void* lookup(uint32_t id){return id==0xfd001111?quest:id==0xff001111?from:id==0xff002222?to:nullptr;}
static bool varOwner(uint32_t v,uint8_t b,uint32_t& owner){if(v!=uint32_t(variable) || b==254)return false;owner=b==253?1000:b;return true;}
static bool linkOwner(uint32_t s,uint32_t t,uint8_t b,uint32_t& owner){if(s!=0xff001111 || t!=0xff002222 || b==254)return false;owner=b==253?1001:b;return true;}
static uint32_t moduleBase=0,expectedRows=0,saveCalls=0;
static void __cdecl nativeSave(void*){++saveCalls;CHECK(*(uint32_t*)(moduleBase+jipTestRva(0x6a2dc))==expectedRows);CHECK(*(uint32_t*)(moduleBase+jipTestRva(0x6a324))==expectedRows);
    if(expectedRows){uint32_t root=**(uint32_t**)(moduleBase+jipTestRva(0x6a2d4));uint32_t child=**(uint32_t**)(root+8);CHECK(*(uint8_t*)(child+16)==42);
        uint32_t link=**(uint32_t**)(moduleBase+jipTestRva(0x6a31c));CHECK(*(uint8_t*)(link+12)==255);}}
static void __cdecl failedSave(void*){throw "synthetic_writer_failure";}
static void* add(void* s,void* l,uint32_t id,const std::string& n,uint32_t o){CHECK(s==script && l==locals && id==0xfd001111 && n=="WidePersist");++calls;lastAuthor=o;return variable;}
static bool link(void* s,void* t,uint32_t o){CHECK(s==from && t==to && o==1001);++calls;return true;}
static void d(void* p,unsigned off,uint32_t n){memcpy((char*)p+off,&n,4);}
int main(){
    std::vector<unsigned char> module(0xa0000);uint32_t b=uint32_t(module.data());
    uint32_t varBuckets[1]{},linkBuckets[1]{},namesBuckets[1]{};
    unsigned char subjectEntry[20]{},varEntry[20]{},linkEntry[16]{};
    char name[]="WidePersist";uint64_t bits=0;double number=123.75;memcpy(&bits,&number,8);memcpy(variable+8,&bits,8);
    d(quest,0,uint32_t(vtable));quest[4]=0x47;d(quest,0x1c,uint32_t(script));d(quest,0x5c,uint32_t(locals));
    d(vtable,0xf0,0x8d0360);d(from,0,uint32_t(vtable));d(to,0,uint32_t(vtable));
    // Quest is not a reference even though it shares the test vtable initially.
    unsigned char questVtable[256]{};d(quest,0,uint32_t(questVtable));
    d(locals,0xc,uint32_t(node));d(node,0,uint32_t(variable));
    d(subjectEntry,4,0xfd001111);d(subjectEntry,8,uint32_t(namesBuckets));d(subjectEntry,12,1);d(subjectEntry,16,1);
    namesBuckets[0]=uint32_t(varEntry);d(varEntry,8,uint32_t(name));d(varEntry,12,uint32_t(variable));varEntry[16]=253;
    varBuckets[0]=uint32_t(subjectEntry);d(module.data(),jipTestRva(0x6a2d4),uint32_t(varBuckets));d(module.data(),jipTestRva(0x6a2d8),1);d(module.data(),jipTestRva(0x6a2dc),1);
    linkBuckets[0]=uint32_t(linkEntry);d(linkEntry,4,0xff001111);d(linkEntry,8,0xff002222);linkEntry[12]=253;
    d(module.data(),jipTestRva(0x6a31c),uint32_t(linkBuckets));d(module.data(),jipTestRva(0x6a320),1);d(module.data(),jipTestRva(0x6a324),1);
    wide::JipScriptLinkRuntime runtime;runtime.bindSynthetic(b,lookup,varOwner,linkOwner,add,link);
    moduleBase=b;unsigned char originalRoots[24];memcpy(originalRoots,module.data()+jipTestRva(0x6a2d4),12);memcpy(originalRoots+12,module.data()+jipTestRva(0x6a31c),12);
    CHECK(runtime.filteredSave(nativeSave,nullptr));CHECK(saveCalls==1);
    CHECK(!memcmp(originalRoots,module.data()+jipTestRva(0x6a2d4),12) && !memcmp(originalRoots+12,module.data()+jipTestRva(0x6a31c),12));
    varEntry[16]=42;linkEntry[12]=255;expectedRows=1;CHECK(runtime.filteredSave(nativeSave,nullptr));CHECK(saveCalls==2);
    CHECK(!runtime.filteredSave(failedSave,nullptr));CHECK(!memcmp(originalRoots,module.data()+jipTestRva(0x6a2d4),12) && !memcmp(originalRoots+12,module.data()+jipTestRva(0x6a31c),12));
    varEntry[16]=254;CHECK(!runtime.filteredSave(nativeSave,nullptr));CHECK(saveCalls==2);
    varEntry[16]=253;linkEntry[12]=253;
    wide::ScriptLinkSave saved;CHECK(runtime.snapshot(1024,saved));CHECK(saved.variables.size()==1 && saved.links.size()==1);
    CHECK(saved.variables[0].author==997 && saved.links[0].author==998 && saved.variables[0].bits==bits);
    memset(variable+8,0,8);CHECK(runtime.restore(saved,1024));CHECK(calls==2 && lastAuthor==1000);uint64_t actual=0;memcpy(&actual,variable+8,8);CHECK(actual==bits);
    auto bad=saved;bad.links[0].target=0xff999999;calls=0;CHECK(!runtime.restore(bad,1024));CHECK(calls==0);
    bad=saved;bad.variables[0].bits=0xfd999999;CHECK(!runtime.restore(bad,1024));CHECK(calls==0);
    // Failed snapshots leave the caller's previous output unchanged.
    varEntry[16]=254;CHECK(!runtime.snapshot(1024,saved));CHECK(saved.variables[0].bits==bits);varEntry[16]=253;
    d(varEntry,0,uint32_t(varEntry));CHECK(!runtime.snapshot(1024,saved));d(varEntry,0,0);
    d(module.data(),jipTestRva(0x6a2dc),2);CHECK(!runtime.snapshot(1024,saved));d(module.data(),jipTestRva(0x6a2dc),1);
    d(node,0,0);CHECK(!runtime.restore(saved,1024));
    puts("PASS JIP native-layout snapshot/restore/filter: full authors, bits, missing-target preflight, unknown author, cycles/counts, locals membership, legacy/public subset, writer failure root restoration");
}
