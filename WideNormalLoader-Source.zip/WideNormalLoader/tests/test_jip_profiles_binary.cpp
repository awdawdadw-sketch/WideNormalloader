#include <windows.h>
#include <cstdio>
#include <vector>
#include "../src/nvse_abi.h"
#include "../src/nvse_commands.h"
#define WIDE_JIP_PRIVATE_MAP_TEST
#include "../src/jip_private_maps_runtime.h"
#include "../src/jip_added_variables_runtime.h"
#include "../src/jip_link_owners_runtime.h"
#include "../src/jip_script_link_runtime.h"
#include "../src/jip_save_runtime.h"
using namespace wide;
#define CHECK(x) do{if(!(x)){fprintf(stderr,"FAIL %u %s\n",__LINE__,#x);ExitProcess(1);}}while(0)
static std::vector<WideCommandInfo> commands;
static const WideCommandInfo* byName(const char* name){for(auto& c:commands)if(!strcmp(c.longName,name))return &c;return nullptr;}
static bool resolve(void*,uint32_t& owner){owner=1000;return true;}
static void* lookup(uint32_t){return nullptr;}
static bool variableOwner(uint32_t,uint8_t,uint32_t&){return false;}
static bool linkOwner(uint32_t,uint32_t,uint8_t,uint32_t&){return false;}
static void* addVariable(void*,void*,uint32_t,const std::string&,uint32_t){return nullptr;}
static bool setLink(void*,void*,uint32_t){return false;}
static void failure(){}
int main(int argc,char** argv){
    CHECK(argc==3);jipBuild=!strcmp(argv[1],"pp")?JipBuild::PPLN:JipBuild::Original;
    FILE* f=fopen(argv[2],"rb");CHECK(f);fseek(f,0,SEEK_END);long size=ftell(f);CHECK(size>0);rewind(f);
    std::vector<unsigned char> disk(size);CHECK(fread(disk.data(),1,disk.size(),f)==disk.size());fclose(f);
    auto* dos=(IMAGE_DOS_HEADER*)disk.data();CHECK(dos->e_magic==IMAGE_DOS_SIGNATURE);
    auto* nt=(IMAGE_NT_HEADERS32*)(disk.data()+dos->e_lfanew);CHECK(nt->Signature==IMAGE_NT_SIGNATURE);
    auto* image=(unsigned char*)VirtualAlloc(nullptr,nt->OptionalHeader.SizeOfImage,MEM_RESERVE|MEM_COMMIT,PAGE_EXECUTE_READWRITE);CHECK(image);
    memcpy(image,disk.data(),nt->OptionalHeader.SizeOfHeaders);auto* section=IMAGE_FIRST_SECTION(nt);
    for(unsigned i=0;i<nt->FileHeader.NumberOfSections;++i)if(section[i].SizeOfRawData)memcpy(image+section[i].VirtualAddress,disk.data()+section[i].PointerToRawData,section[i].SizeOfRawData);
    DWORD base=uint32_t(image),delta=base-nt->OptionalHeader.ImageBase;
    auto dir=nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC];
    for(DWORD offset=0;offset<dir.Size;){auto* block=(IMAGE_BASE_RELOCATION*)(image+dir.VirtualAddress+offset);CHECK(block->SizeOfBlock>=8);
        auto* entries=(WORD*)(block+1);for(unsigned i=0;i<(block->SizeOfBlock-8)/2;++i){unsigned kind=entries[i]>>12;
            CHECK(kind==IMAGE_REL_BASED_ABSOLUTE || kind==IMAGE_REL_BASED_HIGHLOW);if(kind==IMAGE_REL_BASED_HIGHLOW)*(DWORD*)(image+block->VirtualAddress+(entries[i]&0xfff))+=delta;}
        offset+=block->SizeOfBlock;}
    for(auto& s:(jipBuild==JipBuild::PPLN?jipPPMapCommands:jipMapCommands)){WideCommandInfo c{};c.longName=s.name;c.execute=(CommandExecute)(image+s.entry);commands.push_back(c);}
    for(auto entry:{std::pair<const char*,uint32_t>{"AddScriptVariable",0x34d70},{"RemoveAllAddedVariables",0x34d90},{"SetLinkedReference",0x28dd0}}){WideCommandInfo c{};c.longName=entry.first;c.execute=(CommandExecute)(image+jipRva(entry.second));commands.push_back(c);}
    WideCommandInfo condition{};condition.longName="AuxVarGetFltCond";condition.eval=image+jipRva(jipMapConditionEval);commands.push_back(condition);
    WideCommandTable table{};table.getName=byName;
    JipPrivateMapsRuntime maps;CHECK(maps.installSynthetic((HMODULE)image,&table,resolve));
    JipAddedVariablesRuntime variables;CHECK(variables.install((HMODULE)image,&table,resolve));
    JipLinkOwnersRuntime links;CHECK(links.install((HMODULE)image,&table,resolve));
    JipScriptLinkRuntime scripts;CHECK(scripts.bind((HMODULE)image,lookup,variableOwner,linkOwner,addVariable,setLink));CHECK(scripts.installSaveFilter(failure));
    JipSaveRuntime saves;CHECK(saves.bind((HMODULE)image));
    printf("PASS %s: adapter signatures and command entrypoints on a relocated copy of the installed binary. No DLL code or entrypoint executed.\n",jipBuildName());
}
