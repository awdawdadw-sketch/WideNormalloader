#pragma once
#include "../src/jip_build_profile.h"
#ifdef WIDE_JIP_PP_PROFILE
inline struct JipTestSelect {JipTestSelect(){wide::jipBuild=wide::JipBuild::PPLN;}} jipTestSelect;
#endif
inline uint32_t jipTestRva(uint32_t original){
    if(wide::jipBuild==wide::JipBuild::Original)return original;
    switch(original){
    case 0x3610:return 0x36d0;
    case 0x3611:return 0x36d1;
    case 0x3615:return 0x36d5;
    case 0x573a0:return 0x63a60;
    case 0x6a2d4:return 0x7c2fc;
    case 0x6a2d8:return 0x7c300;
    case 0x6a2dc:return 0x7c304;
    case 0x6a2f8:return 0x7c320;
    case 0x6a30c:return 0x7c334;
    case 0x6a318:return 0x7c340;
    case 0x6a31c:return 0x7c344;
    case 0x6a320:return 0x7c348;
    case 0x6a324:return 0x7c34c;
    case 0x6a354:return 0x7c37c;
    case 0x6a360:return 0x7c388;
    case 0x7637a:return 0x8895a;
    default:return 0;
    }
}
