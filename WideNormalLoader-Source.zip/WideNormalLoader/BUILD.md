# Build and test

## Toolchain

The maintained build uses **Zig 0.13.0**, targeting `x86-windows-gnu`, with C++17 and Windows system libraries. Download Zig separately from https://ziglang.org/download/ and put it on PATH, or pass its full path to the scripts. The compiler is not bundled. Python is not required for building or packaging this repository.

Run these commands in Windows PowerShell from the repository root:

```powershell
.\Build.ps1 -ZigPath 'C:\Tools\zig\zig.exe'
.\Build.ps1 -ZigPath 'C:\Tools\zig\zig.exe' -RunTests
.\Package.ps1
```

Outputs:

- `build/WideNormalLoader.dll`
- `build/tests/` for locally compiled test executables
- `dist/WideNormalLoader-Manual.zip` after packaging

PowerShell may require your normal local script-execution policy to permit scripts. The equivalent direct DLL build is:

```text
zig c++ src/normal_loader.cpp -target x86-windows-gnu -shared -o WideNormalLoader.dll -O2 -std=c++17 -fno-omit-frame-pointer -ladvapi32 -luser32 -lshell32 -lole32
```

This is a 32-bit injected engine plugin. Do not change the target architecture to x64. The scripts write only build/package outputs; they do not modify an installed game or launch it.

## Tests

`-RunTests` runs original/PP ownership and script/link tests, startup parsing/baseline checks, fault-handler pass-through checks and ShowOff x86 bridge tests. These use controlled data and synthetic images; they do not execute the game or certify runtime/save compatibility.

To check hook signatures against local original-JIP and PP binaries without executing their native entrypoints, supply both paths:

```powershell
.\Build.ps1 -RunTests -OriginalJipDll 'C:\Mods\OriginalJIP\jip_nvse.dll' -JipPPDll 'C:\Mods\JipPP\jip_nvse.dll'
```

Those DLLs are external test inputs and are not included. The binary-image test uses command addresses from each audited manifest; live command registration is additionally checked by the loader in game.

The reference release DLL fingerprint is in `docs/COMPATIBILITY.md`. Rebuilding in a different directory can change debug records, linker metadata and addresses; this export does not promise byte-for-byte identical output.

## Testing changes in game

Use a separate mod-manager profile, preserve the current INI/order and paired FOS/NVSE saves, and inspect the startup report. Do not weaken build, empty-map or hook-signature checks to force a mismatch through. Keep the normal loader log, preflight report, fault report and Crash Logger output together when investigating failures.
