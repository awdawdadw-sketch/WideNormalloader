#pragma once
#include <stdint.h>
#include <string>
#include <vector>
namespace wide {
struct ArrayContentElement {uint64_t keyBits=0,bits=0;std::string keyText,text;uint8_t type=0;};
struct ArrayContent {uint32_t id=0;uint8_t owner=0,key=0,packed=0;std::vector<ArrayContentElement> elements;};
}
