#pragma once
#include <vector>
#include <stdint.h>
#include <cstring>
namespace wide {
struct ArrayBridgeBytes {
 std::vector<unsigned char> code;uint32_t address;
 explicit ArrayBridgeBytes(uint32_t at):address(at){}
 void bytes(std::initializer_list<unsigned char> b){code.insert(code.end(),b);}
 void word(uint32_t n){for(unsigned i=0;i<4;++i)code.push_back(uint8_t(n>>(8*i)));}
 void jump(uint32_t to){bytes({0xE9});word(to-(address+(uint32_t)code.size()+4));}
 void call(uint32_t callback){bytes({0xB8});word(callback);bytes({0xFF,0xD0,0x83,0xC4,0x04});}
 void branch(size_t at,size_t to){code[at]=uint8_t(to-at-1);}
};
inline std::vector<unsigned char> buildArrayOwnerBridge(uint32_t address,uint32_t callback,uint32_t resume){
 ArrayBridgeBytes b(address);b.bytes({0x51,0x52,0x0F,0xB6,0xC0,0x50});b.call(callback);
 b.bytes({0x5A,0x59,0x3C,0xFF,0x75,0x04,0x32,0xDB,0xEB,0x02,0x8A,0xD8});b.jump(resume);return std::move(b.code);
}
inline std::vector<unsigned char> buildArrayRefBridge(uint32_t address,uint32_t callback,uint32_t buffer,uint32_t resume,bool context=false){
 ArrayBridgeBytes b(address);b.bytes({0x0F,0xB6,0xC1,0x51,0x52});
 if(context){b.bytes({0x56,0xFF,0x75,0xE0,0x50,0xB8});b.word(callback);b.bytes({0xFF,0xD0,0x83,0xC4,0x0C});}
 else{b.bytes({0x50});b.call(callback);}
 b.bytes({0x5A,0x59,0x3C,0xFF,0x74,0});size_t invalid=b.code.size()-1;
 b.bytes({0x84,0xDB,0x75,0});size_t own=b.code.size()-1;b.bytes({0x8A,0xD8});b.branch(own,b.code.size());
 b.bytes({0x88,0x87});b.word(buffer);b.bytes({0x47,0x0F,0xB6,0xC9,0xB0,0x01});b.jump(resume);
 b.branch(invalid,b.code.size());b.bytes({0x0F,0xB6,0xC9,0x32,0xC0});b.jump(resume);return std::move(b.code);
}
inline std::vector<unsigned char> buildArrayFormBridge(uint32_t address,uint32_t callback,uint32_t resume){
 ArrayBridgeBytes b(address);b.bytes({0x52,0x50});b.call(callback);b.bytes({0x5A,0x8B,0xC8});b.jump(resume);return std::move(b.code);
}
}
