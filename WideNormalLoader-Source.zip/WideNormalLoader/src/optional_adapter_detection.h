#pragma once
#include "module_sha256.h"
#include "jip_build_profile.h"
#include <cstdio>
#include <string>

namespace wide {
inline std::string& skippedOptionalAdapters(){static std::string names;return names;}
// Select by loaded DLL name, then identify the audited build before any writes.
// A display version alone cannot establish a private structure or hook ABI.
inline bool optionalAdapterSupported(const char* name,const char* expected,FILE* log,const char* alternative=nullptr) {
    HMODULE module=GetModuleHandleA(name);
    if(!module){fprintf(log,"OPTIONAL_ADAPTER dll=%s status=absent patches=0\n",name);return false;}
    wchar_t path[32768]{};std::array<unsigned char,32> digest{};
    DWORD length=GetModuleFileNameW(module,path,32768);
    bool read=length && length<32768 && fileSha256(path,digest);
    char hash[65]{};
    if(read)for(unsigned i=0;i<32;++i)snprintf(hash+i*2,3,"%02x",digest[i]);
    bool supported=read && (sha256Matches(digest,expected) || (alternative && sha256Matches(digest,alternative)));
    if(supported && !lstrcmpiA(name,"jip_nvse.dll")){
        jipBuild=sha256Matches(digest,jipPPHash)?JipBuild::PPLN:JipBuild::Original;
        fprintf(log,"JIP_ADAPTER_PROFILE build=%s address_profile=audited_per_build\n",jipBuildName());
    }
    fprintf(log,"OPTIONAL_ADAPTER dll=%s status=%s sha256=%s patches=%s\n",name,
            supported?"supported":(read?"unsupported_build":"unreadable_build"),
            read?hash:"unavailable",supported?"pending_signature_checks":"0");
    if(!supported){
        fprintf(log,"OPTIONAL_ADAPTER_WARNING dll=%s adapter_skipped=1 extended_plugin_features_unverified=1\n",name);
        skippedOptionalAdapters()+=std::string("\n - ")+name;
    }
    fflush(log);return supported;
}
inline void showOptionalAdapterWarnings(){
    if(skippedOptionalAdapters().empty())return;
    std::string message="WideNormalLoader found unsupported optional DLL builds:"+skippedOptionalAdapters()+
        "\n\nTheir adapters were skipped. These mods may not handle plugins in extended slots correctly. "
        "Startup can continue, but gameplay and save compatibility are unverified.\n\n"
        "Run the WideNormalLoader preflight checker for the detected builds and winning files. "
        "See the loader log for fingerprints. This warning does not mean those mods were disabled.";
    MessageBoxA(nullptr,message.c_str(),"WideNormalLoader: optional adapters skipped",MB_OK|MB_ICONWARNING|MB_SETFOREGROUND);
    skippedOptionalAdapters().clear();
}
} // namespace wide
