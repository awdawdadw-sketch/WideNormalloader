#pragma once
#include <stdint.h>
namespace wide {
// Stable common script namespace, distinct from SUP's session token pool.
class PluginOwnerScope {
    inline static thread_local PluginOwnerScope* active=nullptr;
    PluginOwnerScope* previous;uint32_t owner;
public:
    explicit PluginOwnerScope(uint32_t value):previous(active),owner(value){active=this;}
    ~PluginOwnerScope(){active=previous;}
    PluginOwnerScope(const PluginOwnerScope&)=delete;
    static bool valid(uint32_t value){return value<253 || value==255 || (value>=256 && value<=1026);}
    static uint32_t currentOrByte(uint32_t fallback){return active?active->owner:fallback&255;}
};
}
