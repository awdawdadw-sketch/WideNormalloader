#pragma once
#include <cstring>
#include "save_identity_codec.h"
#include "array_content_types.h"
namespace wide {
struct ArrayGate {SaveIdentities identities;std::vector<uint32_t> opaqueIds,opaqueElements;std::vector<ArrayContent> contents;uint32_t arrays=0,opaqueRefs=0,opaqueForms=0,manifestCrc=0;};
inline bool validateFixedOrderArraySave(const unsigned char* bytes,size_t size,const std::vector<std::string>& current,ArrayGate& output){
 if(!bytes || size<20 || size>maxIdentityBytes || memcmp(bytes,"NVSE",4))return false;
 auto u32=[&](size_t p){return uint32_t(bytes[p])|uint32_t(bytes[p+1])<<8|uint32_t(bytes[p+2])<<16|uint32_t(bytes[p+3])<<24;};
 if(u32(4)!=1 || u32(16)>65536)return false;
 ArrayGate result;size_t pos=20;bool manifest=false,saw=false,active=false,closed=false;std::unordered_set<uint32_t> ids;
 for(uint32_t block=0;block<u32(16);++block){
  if(size-pos<12)return false;uint32_t opcode=u32(pos),records=u32(pos+4),length=u32(pos+8);pos+=12;
  if(length>size-pos || records>length/12)return false;size_t end=pos+length;
  for(uint32_t record=0;record<records;++record){
   if(end-pos<12)return false;uint32_t tag=u32(pos),version=u32(pos+4),n=u32(pos+8);pos+=12;if(n>end-pos)return false;
   if(tag==saveIdentityRecord){
    if(manifest || version!=saveIdentityVersion || !decodeIdentities(bytes+pos,n,result.identities) || result.identities.plugins.size()!=current.size())return false;
    for(size_t i=0;i<current.size();++i)if(normalizedPlugin(current[i])!=normalizedPlugin(result.identities.plugins[i]))return false;
    manifest=true;result.manifestCrc=identityCrc(bytes+pos,n-4);
   }
   if(opcode==0x1400){
    if(tag==0x41525653){if(saw || version>2 || n)return false;saw=active=true;}
    else if(tag==0x41525645){if(!active || version>2 || n)return false;active=false;closed=true;}
    else if(tag==0x41525652){
     if(!active || version>2 || n<11)return false;size_t p=pos,limit=pos+n;
     auto word=[&](unsigned width,uint32_t& value){if(width>limit-p)return false;value=0;for(unsigned j=0;j<width;++j)value|=uint32_t(bytes[p++])<<(8*j);return true;};
     auto text=[&](std::string& value){uint32_t len;if(!word(2,len) || len>=0x4000 || len>limit-p || memchr(bytes+p,0,len))return false;value.assign((const char*)bytes+p,len);p+=len;return true;};
     auto bits=[&](uint64_t& value){uint32_t lo,hi;if(!word(4,lo) || !word(4,hi))return false;value=lo|(uint64_t(hi)<<32);return true;};
     uint32_t owner,id,key,packed,refs=0,count;
     if(!word(1,owner) || !word(4,id) || !word(1,key) || !word(1,packed) || !id || !ids.insert(id).second || (key!=1 && key!=3) || packed>1 || (key==3 && packed))return false;
     if(version>=1){if(!word(4,refs) || refs>=0x4000 || refs>limit-p)return false;for(uint32_t j=0;j<refs;++j){uint32_t ref;if(!word(1,ref))return false;if(ref==253 || ref==254)++result.opaqueRefs;}}
     else if(owner==253 || owner==254)++result.opaqueRefs;
     if(!word(4,count) || count>1048576)return false;
     ArrayContent content;content.id=id;content.owner=owner;content.key=key;content.packed=packed;bool opaqueForm=false;
     for(uint32_t j=0;j<count;++j){
      ArrayContentElement element;
      if(key==3){if(!text(element.keyText))return false;}
      else if(!packed || version<2){if(!bits(element.keyBits))return false;}
      else {double value=j;memcpy(&element.keyBits,&value,8);}
      uint32_t type,value;if(!word(1,type))return false;
      element.type=type;
      if(type==1){if(!bits(element.bits))return false;}
      else if(type==3){if(!text(element.text))return false;}
      else if(type==2 || type==4){if(!word(4,value))return false;element.bits=value;if(type==2 && (value>>24==253 || value>>24==254)){++result.opaqueForms;opaqueForm=true;}}
      else return false;
      content.elements.push_back(std::move(element));
     }
     if(p!=limit)return false;++result.arrays;if(owner==253 || owner==254){result.opaqueIds.push_back(id);result.opaqueElements.push_back(count);}
     if(owner!=255 && (owner==253 || owner==254 || opaqueForm))result.contents.push_back(std::move(content));
    }else if(active)return false;
   }
   pos+=n;
  }
  if(pos!=end)return false;
 }
 if(pos!=size || !manifest || !saw || !closed || active)return false;output=std::move(result);return true;
}
}
