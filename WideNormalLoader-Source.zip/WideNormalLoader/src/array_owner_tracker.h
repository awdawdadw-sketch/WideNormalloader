#pragma once
#include <stdint.h>
#include <unordered_map>
namespace wide {
struct TrackedArrayOwner {uint32_t object,slot;uint8_t nativeByte;};
struct ArrayAllocationOrigin {uint32_t object,caller;uint8_t nativeByte;};
class ArrayOwnerTracker {
    std::unordered_map<uint32_t,TrackedArrayOwner> owners;
    std::unordered_map<uint32_t,ArrayAllocationOrigin> origins;
public:
    void clear(){owners.clear();origins.clear();}
    // Every observed native allocation invalidates the former ID, even when
    // no full script context can be proved for the new allocation.
    void allocated(uint32_t id,uint32_t object=0,uint8_t nativeByte=0,uint32_t caller=0){
        owners.erase(id);origins.erase(id);
        if(id && object)origins[id]={object,caller,nativeByte};
    }
    bool origin(uint32_t id,uint32_t object,uint8_t nativeByte,ArrayAllocationOrigin& out)const{
        auto it=origins.find(id);
        if(it==origins.end() || it->second.object!=object || it->second.nativeByte!=nativeByte)return false;
        out=it->second;return true;
    }
    bool created(uint32_t id,uint32_t object,uint32_t slot,uint8_t nativeByte){
        if(!id || !object || slot>=1024 || (nativeByte<253?slot!=nativeByte:slot<253 || nativeByte==255))return false;
        owners[id]={object,slot,nativeByte};return true;
    }
    bool get(uint32_t id,uint32_t object,uint8_t nativeByte,TrackedArrayOwner& out)const{
        auto it=owners.find(id);
        if(it==owners.end() || it->second.object!=object || it->second.nativeByte!=nativeByte)return false;
        out=it->second;return true;
    }
};
}
