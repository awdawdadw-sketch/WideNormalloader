#pragma once
#include <array>
#include <cstdint>

namespace wide {
struct LegacyFileNode { void* file;LegacyFileNode* next; };
// SUP's legacy callers use byte counts/indices. Give them a bounded pointer
// table; full plugin enumeration remains a separate registry interface.
class BoundedLegacyFileCache {
    std::array<void*,256> files{};
    uint32_t length=0;
public:
    void* const* rebuild(const LegacyFileNode* node) {
        files.fill(nullptr);length=0;
        while(node && length<253) {
            files[length++]=node->file;node=node->next;
        }
        return files.data();
    }
    uint32_t count() const {return length;}
};
} // namespace wide
