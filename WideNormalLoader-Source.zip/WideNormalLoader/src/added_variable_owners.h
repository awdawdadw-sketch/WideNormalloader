#pragma once
#include "plugin_owner_scope.h"
#include <unordered_map>
namespace wide {
class AddedVariableOwners {
    struct Entry {uint32_t owner;uint8_t nativeByte;};
    std::unordered_map<uint32_t,Entry> entries;
public:
    void clear(){entries.clear();}
    void assigned(uint32_t variable,uint8_t byte,uint32_t owner){
        if(!variable)return;
        if(PluginOwnerScope::valid(owner) && ((owner>=256 && (byte==253 || byte==254)) || owner==byte))entries[variable]={owner,byte};
        else entries.erase(variable);
    }
    bool matches(uint32_t variable,uint8_t byte,uint32_t owner)const{
        if(!variable || !PluginOwnerScope::valid(owner))return false;
        auto it=entries.find(variable);
        if(it!=entries.end())return it->second.nativeByte==byte && it->second.owner==owner;
        // A byte cannot identify an extended author without observed metadata.
        return byte<253 || byte==255 ? owner==byte : false;
    }
    bool get(uint32_t variable,uint8_t byte,uint32_t& owner)const{
        if(!variable)return false;auto it=entries.find(variable);
        if(it!=entries.end()){if(it->second.nativeByte!=byte)return false;owner=it->second.owner;return true;}
        if(byte<253 || byte==255){owner=byte;return true;}return false;
    }
};
}
