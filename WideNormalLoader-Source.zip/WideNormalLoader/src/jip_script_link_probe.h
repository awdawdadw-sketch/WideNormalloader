#pragma once
// One existing console command queues the batch; compilation runs outside the
// console's declaration hooks on a subsequent game-loop notification.
struct JipScriptLinkProbeState{bool queued=false;uint32_t requested=0;};
static JipScriptLinkProbeState& jipScriptLinkProbeState(){static JipScriptLinkProbeState s;return s;}
static bool checkJipScriptLinkFixtures(bool restored){
    wide::ScriptLinkSave snapshot;bool passed=jipScriptLinkRuntime().snapshot(loadedCount,snapshot);
    uint32_t a=saveFixtureSlot(0),b=saveFixtureSlot(1),subject=fixtureFormHandle(a,0xd10),refs[2]{};
    const char* names[]={"WidePersistNumberA","WidePersistNumberB","WidePersistFormA","WidePersistFormB","WidePersistLinkA","WidePersistLinkB"};
    uint64_t expected[6]{};double numbers[]={111.25,222.5};memcpy(&expected[0],&numbers[0],8);memcpy(&expected[1],&numbers[1],8);
    expected[2]=fixtureFormHandle(b,0xd10);expected[3]=subject;
    if(restored)passed=passed && saveIdentityState().scriptLinksRestored;
    for(unsigned i=0;i<6;++i){const wide::SavedScriptVariable* found=nullptr;
        for(auto& v:snapshot.variables)if(v.subject==subject && v.name==names[i]){if(found){passed=false;break;}found=&v;}
        uint32_t author=(i&1)?b:a;bool ok=found && found->author==author;
        if(i<4)ok=ok && found->bits==expected[i];
        else if(found){refs[i-4]=uint32_t(found->bits);ok=ok && !(found->bits>>32) && (refs[i-4]>>24)==255 && lookup(refs[i-4]);}
        passed=passed && ok;
        fprintf(logFile,"WIDE_JIP_SCRIPT_LINK_VARIABLE name=%s expected_author=%u actual_author=%u bits=%016llX passed=%u\n",names[i],author,found?found->author:UINT32_MAX,(unsigned long long)(found?found->bits:0),ok);fflush(logFile);
    }
    for(unsigned i=0;i<2;++i){const wide::SavedLinkedReference* found=nullptr;
        for(auto& link:snapshot.links)if(link.subject==refs[i])found=&link;
        SupProbeElement output{};void* actual=nullptr;bool called=refs[i] && combinedExpression(i?b:a,"GetLinkedRef",lookup(refs[i]),output);
        if(called && output.type==2)memcpy(&actual,&output.number,4);
        bool ok=found && found->author==(i?b:a) && found->target==refs[1-i] && refs[0]!=refs[1] && called && actual==lookup(refs[1-i]);
        passed=passed && ok;fprintf(logFile,"WIDE_JIP_SCRIPT_LINK_REFERENCE index=%u subject=%08X target=%08X author=%u passed=%u\n",i,refs[i],refs[1-i],found?found->author:UINT32_MAX,ok);fflush(logFile);
    }
    fprintf(logFile,"WIDE_JIP_SCRIPT_LINK_CHECK phase=%s passed=%u comparisons=8 restored_record=%u\n",restored?"restore":"seed",passed,saveIdentityState().scriptLinksRestored);fflush(logFile);return passed;
}
static bool seedJipScriptLinkFixtures(){
    uint32_t a=saveFixtureSlot(0),b=saveFixtureSlot(1);if(a>=loadedCount || b>=loadedCount || a==b)return false;
    void* refs[2]{};uint32_t ids[2]{};
    for(unsigned i=0;i<2;++i){SupProbeElement output{};bool called=combinedExpression(i?b:a,"PlaceAtMe (GetFormFromMod \"FalloutNV.esm\" \"00000F\") 1",*(void**)0x11dea3c,output);
        if(called && output.type==2)memcpy(&refs[i],&output.number,4);SIZE_T got=0;uint8_t type=0;
        if(!refs[i] || !ReadProcessMemory(GetCurrentProcess(),(char*)refs[i]+0xc,&ids[i],4,&got) || got!=4 || ids[i]>>24!=255 || lookup(ids[i])!=refs[i] ||
           !ReadProcessMemory(GetCurrentProcess(),(char*)refs[i]+4,&type,1,&got) || got!=1 || type!=0x3a)return false;
    }
    if(ids[0]==ids[1])return false;
    wide::ScriptLinkSave values;uint32_t subject=fixtureFormHandle(a,0xd10);
    const char* names[]={"WidePersistNumberA","WidePersistNumberB","WidePersistFormA","WidePersistFormB","WidePersistLinkA","WidePersistLinkB"};
    uint64_t bits[6]{};double numbers[]={111.25,222.5};memcpy(&bits[0],&numbers[0],8);memcpy(&bits[1],&numbers[1],8);
    bits[2]=fixtureFormHandle(b,0xd10);bits[3]=subject;bits[4]=ids[0];bits[5]=ids[1];
    for(unsigned i=0;i<6;++i)values.variables.push_back({subject,uint16_t(i&1?b:a),names[i],bits[i]});
    values.links={{ids[0],ids[1],uint16_t(a)},{ids[1],ids[0],uint16_t(b)}};
    bool ok=jipScriptLinkRuntime().restore(values,loadedCount);
    fprintf(logFile,"WIDE_JIP_SCRIPT_LINK_SEEDED passed=%u test_refs=%08X,%08X persistent=1\n",ok,ids[0],ids[1]);fflush(logFile);
    return ok && checkJipScriptLinkFixtures(false);
}
static bool removeJipScriptLinkFixtures(){
    if(!checkJipScriptLinkFixtures(true))return false;
    wide::ScriptLinkSave before;if(!jipScriptLinkRuntime().snapshot(loadedCount,before))return false;
    uint32_t a=saveFixtureSlot(0),b=saveFixtureSlot(1),subject=fixtureFormHandle(a,0xd10),refs[2]{};
    for(auto& v:before.variables)if(v.subject==subject){if(v.name=="WidePersistLinkA")refs[0]=uint32_t(v.bits);if(v.name=="WidePersistLinkB")refs[1]=uint32_t(v.bits);}
    const char* expression="RemoveAllAddedVariables (GetFormFromMod \"NativeProbe_0689.esp\" \"000D10\")";
    SupProbeElement output{};bool passed=combinedExpression(a,expression,*(void**)0x11dea3c,output);
    wide::ScriptLinkSave after;passed=jipScriptLinkRuntime().snapshot(loadedCount,after) && passed;
    for(auto& v:before.variables)if(v.subject==subject && v.name.rfind("WidePersist",0)==0){
        const wide::SavedScriptVariable* found=nullptr;for(auto& candidate:after.variables)if(candidate.subject==subject && candidate.name==v.name)found=&candidate;
        bool keep=v.author==b,ok=keep?(found && found->author==v.author && found->bits==v.bits):!found;
        passed=passed && ok;fprintf(logFile,"WIDE_JIP_SCRIPT_LINK_REMOVE_CASE name=%s original_author=%u expected_present=%u actual_present=%u passed=%u\n",v.name.c_str(),v.author,keep,found!=nullptr,ok);fflush(logFile);
    }
    bool linksPreserved=true;
    for(auto& saved:before.links)if(saved.subject==refs[0] || saved.subject==refs[1]){
        bool found=false;for(auto& candidate:after.links)if(candidate.subject==saved.subject && candidate.target==saved.target && candidate.author==saved.author)found=true;
        linksPreserved=linksPreserved && found;}
    passed=passed && linksPreserved;fprintf(logFile,"WIDE_JIP_SCRIPT_LINK_REMOVE_LINKS preserved=%u\n",linksPreserved);fflush(logFile);
    bool removedB=combinedExpression(b,expression,*(void**)0x11dea3c,output);wide::ScriptLinkSave cleaned;
    removedB=jipScriptLinkRuntime().snapshot(loadedCount,cleaned) && removedB;
    for(auto& v:cleaned.variables)if(v.subject==subject && v.name.rfind("WidePersist",0)==0)removedB=false;
    passed=passed && removedB;fprintf(logFile,"WIDE_JIP_SCRIPT_LINK_REMOVE_REMAINING passed=%u\n",removedB);fflush(logFile);
    for(unsigned i=0;i<2;++i){void* ref=lookup(refs[i]);bool ok=ref && refs[i]>>24==255;
        if(ok){ok=combinedExpression(i?b:a,"SetLinkedReference",ref,output) && output.type==1 && output.number==1;
            ok=combinedExpression(i?b:a,"Disable",ref,output) && ok;ok=combinedExpression(i?b:a,"MarkForDelete",ref,output) && ok;}
        passed=passed && ok;fprintf(logFile,"WIDE_JIP_SCRIPT_LINK_CLEANUP index=%u passed=%u\n",i,ok);fflush(logFile);}
    if(!jipScriptLinkRuntime().snapshot(loadedCount,cleaned))passed=false;
    for(auto& link:cleaned.links)if(link.subject==refs[0] || link.subject==refs[1])passed=false;
    fprintf(logFile,"WIDE_JIP_SCRIPT_LINK_REMOVE_COMPLETE passed=%u scope=restored_owner_filtered_removal_and_test_reference_cleanup\n",passed);fflush(logFile);return passed;
}
static void advanceJipScriptLinkProbe(){
    auto& s=jipScriptLinkProbeState();if(!s.queued || GetTickCount()-s.requested<1000)return;s.queued=false;
    bool passed=false;try{passed=jipScriptLinkProbeMode==1?seedJipScriptLinkFixtures():jipScriptLinkProbeMode==3?removeJipScriptLinkFixtures():checkJipScriptLinkFixtures(true);}catch(...){fputs("WIDE_JIP_SCRIPT_LINK_PROBE_EXCEPTION\n",logFile);}
    fprintf(logFile,"WIDE_JIP_SCRIPT_LINK_PROBE_COMPLETE mode=%u passed=%u action=%s\n",jipScriptLinkProbeMode,passed,jipScriptLinkProbeMode==1?"manual_save_in_new_slot":jipScriptLinkProbeMode==3?"test_values_cleaned_no_save_required":"read_only_restore_check");fflush(logFile);
}
