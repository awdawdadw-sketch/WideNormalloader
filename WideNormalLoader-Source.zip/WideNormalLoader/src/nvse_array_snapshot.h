#pragma once
#include <windows.h>
#include "module_sha256.h"
#include "save_identity_codec.h"
#include "array_content_types.h"
namespace wide {
struct NvseArrayState {uint32_t id,elements;uint8_t owner,keyType,packed,temporary;std::vector<uint8_t> refs;std::vector<ArrayContentElement> contents;uint32_t objectAddress=0;};
class NvseArraySnapshot {
 uint32_t base=0;uint32_t(__cdecl* sizeApi)(void*)=nullptr;void*(__cdecl* lookupApi)(uint32_t)=nullptr;
 template<class T> static T read(uint32_t p){T value{};SIZE_T n=0;if(!p || !ReadProcessMemory(GetCurrentProcess(),(void*)p,&value,sizeof(value),&n) || n!=sizeof(value))throw "array_snapshot_unreadable";return value;}
 static std::string text(uint32_t p){std::string value;if(!p)return value;for(uint32_t i=0;i<0x4000;++i){char c=read<char>(p+i);if(!c)return value;value.push_back(c);}throw "array_snapshot_unterminated_text";}
 struct Lock {
  uint32_t base,address;
  Lock(uint32_t b,uint32_t a):base(b),address(a){((void(__thiscall*)(void*))(base+0x3D10))((void*)address);}
  ~Lock(){auto* count=(volatile uint32_t*)(address+4);if(--*count==0)*(volatile uint32_t*)address=0;}
 };
 struct TryLock {
  uint32_t address;
  explicit TryLock(uint32_t a):address(a){
   auto* owner=(volatile LONG*)address;DWORD thread=GetCurrentThreadId();
   if(*owner==(LONG)thread)++*(volatile uint32_t*)(address+4);
   else {if(InterlockedCompareExchange(owner,(LONG)thread,0)!=0)throw "array_snapshot_busy";*(volatile uint32_t*)(address+4)=1;}
  }
  ~TryLock(){auto* count=(volatile uint32_t*)(address+4);if(--*count==0)*(volatile uint32_t*)address=0;}
 };
public:
 bool bind(HMODULE module,void* create,uint32_t(__cdecl* size)(void*),void*(__cdecl* lookup)(uint32_t)){
  if(!moduleMatchesSha256(module,"e82c5d348bac255a8ff4cf477df2e48149304b18f02b42b2a835c3cba71f3dfb"))return false;
  uint32_t b=(uint32_t)module;if((uint32_t)create!=b+0x8F40 || (uint32_t)size!=b+0x9150 || (uint32_t)lookup!=b+0x91B0)return false;
  base=b;sizeApi=size;lookupApi=lookup;return true;
 }
 bool snapshot(std::vector<NvseArrayState>& output,const std::unordered_set<uint32_t>* contents=nullptr,bool permanentContents=false){
  if(!base || !sizeApi || !lookupApi)return false;
  try{
   Lock mapLock(base,base+0x13C168);
   uint32_t buckets=read<uint32_t>(base+0x13C130),capacity=read<uint32_t>(base+0x13C134),count=read<uint32_t>(base+0x13C138);
   if(!capacity || (capacity&(capacity-1)) || capacity>1048576 || count>1048576 || (count && !buckets))return false;
   uint32_t tempData=read<uint32_t>(base+0x13C148),tempCount=read<uint32_t>(base+0x13C14C),tempCapacity=read<uint32_t>(base+0x13C150);
   if(tempCount>tempCapacity || tempCount>1048576 || (tempCount && !tempData))return false;
   std::unordered_set<uint32_t> temporary,nodes,ids;
   for(uint32_t i=0;i<tempCount;++i)if(!temporary.insert(read<uint32_t>(tempData+i*4)).second)return false;
   std::vector<NvseArrayState> values;
   if(buckets)for(uint32_t i=0;i<capacity;++i){uint32_t node=read<uint32_t>(buckets+i*4);
    while(node){
     if(nodes.size()>=count || !nodes.insert(node).second)return false;
     uint32_t next=read<uint32_t>(node),id=read<uint32_t>(node+4),object=node+8;
     if(!id || !ids.insert(id).second || read<uint32_t>(object+0x10)!=id || (uint32_t)lookupApi(id)!=id)return false;
     // Other native paths can lock an array before the global map. Never
     // wait for that array while holding the map; reject a busy snapshot.
     TryLock arrayLock(object+0x24);
     uint32_t elements=read<uint32_t>(object+8),refsData=read<uint32_t>(object+0x18),refsCount=read<uint32_t>(object+0x1C),refsCapacity=read<uint32_t>(object+0x20);
     uint8_t owner=read<uint8_t>(object+0x14),key=read<uint8_t>(object+0x15),packed=read<uint8_t>(object+0x16);
     if(elements>1048576 || sizeApi((void*)id)!=elements || refsCount>refsCapacity || refsCount>1048576 || (refsCount && !refsData) || (key!=1 && key!=3) || packed>1 || (key==3 && packed))return false;
     NvseArrayState value{id,elements,owner,key,packed,(uint8_t)temporary.count(id),{}};value.refs.resize(refsCount);SIZE_T got=0;
     value.objectAddress=object;
     if(refsCount && (!ReadProcessMemory(GetCurrentProcess(),(void*)refsData,value.refs.data(),refsCount,&got) || got!=refsCount))return false;
     if((contents && contents->count(id)) || (permanentContents && !value.temporary && !value.refs.empty())){
      uint32_t container=read<uint32_t>(object),data=read<uint32_t>(object+4),capacity=read<uint32_t>(object+0xC);
      if(container>2 || elements>capacity || (elements && !data) || (packed?container!=0:container!=(key==3?2:1)))return false;
      for(uint32_t j=0;j<elements;++j){
       ArrayContentElement elem;uint32_t at=0;
       if(container==0){double index=j;memcpy(&elem.keyBits,&index,8);at=data+j*24;}
       else if(container==1){elem.keyBits=read<uint64_t>(data+j*16);at=read<uint32_t>(data+j*16+8);}
       else {elem.keyText=text(read<uint32_t>(data+j*8));at=read<uint32_t>(data+j*8+4);}
       if(!at || read<uint32_t>(at+0xC)!=id)return false;
       elem.type=read<uint8_t>(at+8);
       if(elem.type==1)elem.bits=read<uint64_t>(at+0x10);
       else if(elem.type==2 || elem.type==4)elem.bits=read<uint32_t>(at+0x10);
       else if(elem.type==3)elem.text=text(read<uint32_t>(at+0x10));
       else return false;
       value.contents.push_back(std::move(elem));
      }
     }
     values.push_back(std::move(value));node=next;
    }
   }
   if(nodes.size()!=count)return false;output=std::move(values);return true;
  }catch(...){return false;}
 }
};
}
