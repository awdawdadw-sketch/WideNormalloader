#pragma once
#include "wide_registry.h"
struct MasterBinding { bool wide; uint32_t owner; };
struct WideFileIdentity {
    uint32_t owner=0, masterCount=0;
    MasterBinding masters[255]{};
};
// Disk selectors remain eight bits; total runtime owners are independent.
// Invalid selectors fail instead of silently using the current file.
template<class Registry>
static inline bool resolveDiskForm(Registry& registry,const WideFileIdentity& file,
                                   uint32_t disk,bool (*occupied)(uint32_t),uint32_t& handle) {
    uint32_t local=disk&0xFFFFFF, selector=disk>>24;
    if(!disk) { handle=0; return true; }
    if(file.masterCount>255 || selector>file.masterCount) return false;
    if(local<0x800) { handle=local; return true; }
    MasterBinding binding=selector==file.masterCount ? MasterBinding{true,file.owner} : file.masters[selector];
    if(!binding.wide) {
        if(binding.owner>254) return false;
        handle=(binding.owner<<24)|local; return true;
    }
    auto* entry=registry.intern({binding.owner,local},occupied);
    if(!entry) return false;
    handle=entry->handle; return true;
}
template<class Registry>
static inline bool encodeDiskForm(Registry& registry,const WideFileIdentity& file,uint32_t handle,uint32_t& disk) {
    if(file.masterCount>255) return false;
    if(handle<0x800) { disk=handle; return true; }
    auto* entry=registry.reverse(handle);
    if(entry && entry->key.plugin==file.owner) { disk=(file.masterCount<<24)|entry->key.local; return true; }
    for(uint32_t i=0;i<file.masterCount;i++) {
        auto m=file.masters[i];
        if(entry && m.wide && m.owner==entry->key.plugin) { disk=(i<<24)|entry->key.local; return true; }
        if(!entry && !m.wide && m.owner==(handle>>24) && (handle>>24)!=255) { disk=(i<<24)|(handle&0xFFFFFF); return true; }
    }
    return false;
}
