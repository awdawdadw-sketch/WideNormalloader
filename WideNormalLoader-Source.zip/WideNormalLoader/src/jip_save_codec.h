#pragma once
#include "save_identity_codec.h"
#include <cstring>
namespace wide {
// Authoritative permanent-map snapshot; public namespace has no plugin owner.
constexpr uint32_t jipSaveRecord=0x574A4950,jipSaveVersion=1;
constexpr uint16_t jipPublicSlot=0xFFFF;
struct JipSavedValue {uint8_t type=0;uint64_t bits=0;std::string text;};
struct JipSavedAux {std::string name;std::vector<JipSavedValue> values;};
struct JipSavedSubject {uint32_t ref;std::vector<JipSavedAux> variables;};
struct JipSavedRef {uint32_t ref;JipSavedValue value;};
struct JipSavedMap {std::string name;std::vector<JipSavedRef> values;};
struct JipSavedOwner {uint16_t slot;std::vector<JipSavedSubject> subjects;std::vector<JipSavedMap> maps;};
struct JipSave {std::vector<JipSavedOwner> aux,refs;};
inline bool validJipText(const std::string& s,bool name=false){return s.size()<=0x1FFF && (!name || !s.empty()) && s.find('\0')==std::string::npos;}
inline bool validJipValue(const JipSavedValue& v){return (v.type==0 || v.type==1 || v.type==2 || v.type==4) && (v.type!=2 || v.bits<=UINT32_MAX) && (v.type!=4 || validJipText(v.text));}
inline bool validateJipSave(const JipSave& in,uint32_t pluginCount){
    if(!pluginCount || pluginCount>1024)return false;
    for(unsigned kind=0;kind<2;++kind){
        const auto& owners=kind?in.refs:in.aux;std::unordered_set<uint16_t> slots;
        if(owners.size()>1025)return false;
        for(const auto& owner:owners){
            if((owner.slot!=jipPublicSlot && owner.slot>=pluginCount) || !slots.insert(owner.slot).second)return false;
            if(kind){
                if(!owner.subjects.empty())return false;std::unordered_set<std::string> names;
                for(const auto& map:owner.maps){
                    if(!validJipText(map.name,true) || !names.insert(map.name).second)return false;
                    std::unordered_set<uint32_t> keys;
                    for(const auto& v:map.values)if(!keys.insert(v.ref).second || !validJipValue(v.value))return false;
                }
            }else{
                if(!owner.maps.empty())return false;std::unordered_set<uint32_t> keys;
                for(const auto& subject:owner.subjects){
                    if(!keys.insert(subject.ref).second)return false;std::unordered_set<std::string> names;
                    for(const auto& variable:subject.variables){
                        if(!validJipText(variable.name,true) || !names.insert(variable.name).second)return false;
                        for(const auto& v:variable.values)if(!validJipValue(v))return false;
                    }
                }
            }
        }
    }return true;
}
inline bool encodeJipSave(const JipSave& in,uint32_t pluginCount,std::vector<unsigned char>& output){
    if(!validateJipSave(in,pluginCount))return false;std::vector<unsigned char> out;
    auto word=[&](uint32_t v,unsigned n=4){identityPut(out,v,n);if(out.size()>maxIdentityBytes-4)throw 1;};
    auto text=[&](const std::string& s){word((uint32_t)s.size(),2);out.insert(out.end(),s.begin(),s.end());if(out.size()>maxIdentityBytes-4)throw 1;};
    auto value=[&](const JipSavedValue& v){word(v.type,1);if(v.type==1){word((uint32_t)v.bits);word((uint32_t)(v.bits>>32));}else if(v.type==2)word((uint32_t)v.bits);else if(v.type==4)text(v.text);};
    try{
        word(jipSaveVersion);word(pluginCount);
        for(unsigned kind=0;kind<2;++kind){const auto& owners=kind?in.refs:in.aux;word((uint32_t)owners.size());
            for(const auto& owner:owners){word(owner.slot,2);
                if(kind){word((uint32_t)owner.maps.size());for(const auto& map:owner.maps){text(map.name);word((uint32_t)map.values.size());for(const auto& v:map.values){word(v.ref);value(v.value);}}}
                else{word((uint32_t)owner.subjects.size());for(const auto& subject:owner.subjects){word(subject.ref);word((uint32_t)subject.variables.size());for(const auto& variable:subject.variables){text(variable.name);word((uint32_t)variable.values.size());for(const auto& v:variable.values)value(v);}}}
            }
        }
        word(identityCrc(out.data(),out.size()));output=std::move(out);return true;
    }catch(...){return false;}
}
inline bool decodeJipSave(const unsigned char* data,size_t size,uint32_t pluginCount,JipSave& output){
    if(!data || size<20 || size>maxIdentityBytes)return false;size_t pos=0,end=size-4;
    auto word=[&](unsigned n=4)->uint32_t{if(n>end-pos)throw 1;uint32_t v=0;for(unsigned i=0;i<n;++i)v|=uint32_t(data[pos++])<<(8*i);return v;};
    auto count=[&](unsigned minimum)->uint32_t{uint32_t n=word();if(n>(end-pos)/minimum || n>1048576)throw 1;return n;};
    auto text=[&](){uint32_t n=word(2);if(n>0x1FFF || n>end-pos)throw 1;std::string s((const char*)data+pos,n);pos+=n;return s;};
    auto value=[&](){JipSavedValue v;v.type=(uint8_t)word(1);if(v.type==1){v.bits=word();v.bits|=uint64_t(word())<<32;}else if(v.type==2)v.bits=word();else if(v.type==4)v.text=text();else if(v.type)throw 1;return v;};
    uint32_t crc=uint32_t(data[end])|uint32_t(data[end+1])<<8|uint32_t(data[end+2])<<16|uint32_t(data[end+3])<<24;
    if(identityCrc(data,end)!=crc)return false;
    try{
        if(word()!=jipSaveVersion || word()!=pluginCount)return false;JipSave parsed;
        for(unsigned kind=0;kind<2;++kind){auto& owners=kind?parsed.refs:parsed.aux;uint32_t n=count(6);if(n>1025)return false;
            while(n--){JipSavedOwner owner;owner.slot=(uint16_t)word(2);
                if(kind){uint32_t m=count(6);while(m--){JipSavedMap map;map.name=text();uint32_t k=count(5);while(k--){JipSavedRef v;v.ref=word();v.value=value();map.values.push_back(std::move(v));}owner.maps.push_back(std::move(map));}}
                else{uint32_t m=count(8);while(m--){JipSavedSubject subject;subject.ref=word();uint32_t k=count(6);while(k--){JipSavedAux variable;variable.name=text();uint32_t c=count(1);while(c--)variable.values.push_back(value());subject.variables.push_back(std::move(variable));}owner.subjects.push_back(std::move(subject));}}
                owners.push_back(std::move(owner));
            }
        }
        if(pos!=end || !validateJipSave(parsed,pluginCount))return false;output=std::move(parsed);return true;
    }catch(...){return false;}
}
}
