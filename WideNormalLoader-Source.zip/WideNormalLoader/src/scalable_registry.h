#pragma once
#include "wide_registry.h"
#include <deque>
#include <unordered_map>
#include <mutex>
#include <vector>

// The normal loader reserves FD/FE for opaque handles, retaining legacy slots
// 00..FC. A canonical key always contains the original 24-bit local ID.
// Deque storage keeps returned entry pointers stable as the registry grows.
class ScalableWideRegistry {
    std::unordered_map<uint64_t, WideEntry*> forward;
    std::unordered_map<uint32_t, WideEntry*> backward;
    std::recursive_mutex lock;
public:
    using Occupied = bool (*)(uint32_t);
    static constexpr uint32_t capacity = 0x02000000 - 0x800;
    std::deque<WideEntry> entries;
    uint32_t count=0, next=0xFD000800;
    std::vector<WideEntry> snapshot() {
        std::lock_guard<std::recursive_mutex> guard(lock);
        return {entries.begin(),entries.end()};
    }
    WideEntry* find(CanonicalKey k) {
        std::lock_guard<std::recursive_mutex> guard(lock);
        auto it=forward.find((uint64_t(k.plugin)<<24)|k.local);
        return it==forward.end()?nullptr:it->second;
    }
    WideEntry* reverse(uint32_t id) {
        std::lock_guard<std::recursive_mutex> guard(lock);
        auto it=backward.find(id);return it==backward.end()?nullptr:it->second;
    }
    WideEntry* intern(CanonicalKey k,Occupied occupied) {
        std::lock_guard<std::recursive_mutex> guard(lock);
        if(k.plugin>=1024 || k.local<0x800 || k.local>0xFFFFFF)return nullptr;
        if(auto* e=find(k))return e;
        while(next<0xFF000000 && occupied && occupied(next))++next;
        if(next>=0xFF000000)return nullptr;
        uint64_t key=(uint64_t(k.plugin)<<24)|k.local;
        entries.push_back({k,next,nullptr});auto* e=&entries.back();
        try {
            forward.emplace(key,e);
            try { backward.emplace(next,e); }
            catch(...) { forward.erase(key);throw; }
        }catch(...) { entries.pop_back();throw; }
        ++next;++count;return e;
    }
};
