#pragma once
#include <windows.h>
#include <wincrypt.h>
#include <array>
#include <cstdint>
#include <cstring>

namespace wide {
inline bool moduleHasImageRange(HMODULE module,uint32_t endRva) {
    if(!module)return false;
    auto* base=reinterpret_cast<const unsigned char*>(module);
    auto* dos=reinterpret_cast<const IMAGE_DOS_HEADER*>(base);
    if(dos->e_magic!=IMAGE_DOS_SIGNATURE || dos->e_lfanew<sizeof(IMAGE_DOS_HEADER) || dos->e_lfanew>4096)return false;
    auto* nt=reinterpret_cast<const IMAGE_NT_HEADERS*>(base+dos->e_lfanew);
    return nt->Signature==IMAGE_NT_SIGNATURE && nt->OptionalHeader.Magic==IMAGE_NT_OPTIONAL_HDR32_MAGIC &&
           endRva<=nt->OptionalHeader.SizeOfImage;
}
inline bool fileSha256(const wchar_t* path,std::array<unsigned char,32>& digest) {
    if (!path || !*path) return false;
    struct File {
        HANDLE handle=INVALID_HANDLE_VALUE;
        ~File(){if(handle!=INVALID_HANDLE_VALUE)CloseHandle(handle);}
    } file;
    file.handle=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,
                            nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);
    if(file.handle==INVALID_HANDLE_VALUE)return false;
    struct Crypto {
        HCRYPTPROV provider=0;HCRYPTHASH hash=0;
        ~Crypto(){if(hash)CryptDestroyHash(hash);if(provider)CryptReleaseContext(provider,0);}
    } crypto;
    if(!CryptAcquireContextW(&crypto.provider,nullptr,nullptr,PROV_RSA_AES,CRYPT_VERIFYCONTEXT) ||
       !CryptCreateHash(crypto.provider,CALG_SHA_256,0,0,&crypto.hash))return false;
    unsigned char buffer[8192];DWORD read=0;
    for(;;) {
        if(!ReadFile(file.handle,buffer,sizeof(buffer),&read,nullptr))return false;
        if(!read)break;
        if(!CryptHashData(crypto.hash,buffer,read,0))return false;
    }
    std::array<unsigned char,32> result{};DWORD size=uint32_t(result.size());
    if(!CryptGetHashParam(crypto.hash,HP_HASHVAL,result.data(),&size,0) || size!=result.size())return false;
    digest=result;return true;
}
inline bool sha256Matches(const std::array<unsigned char,32>& digest,const char* expected) {
    if(!expected || std::strlen(expected)!=64)return false;
    auto hex=[](char c)->int {
        if(c>='0' && c<='9')return c-'0';
        if(c>='a' && c<='f')return c-'a'+10;
        if(c>='A' && c<='F')return c-'A'+10;
        return -1;
    };
    for(size_t i=0;i<digest.size();++i) {
        int hi=hex(expected[i*2]),lo=hex(expected[i*2+1]);
        if(hi<0 || lo<0 || digest[i]!=((hi<<4)|lo))return false;
    }
    return true;
}
inline bool moduleMatchesSha256(HMODULE module,const char* expected) {
    if(!module)return false;
    wchar_t path[32768]{};
    DWORD length=GetModuleFileNameW(module,path,32768);
    if(!length || length>=32768)return false;
    std::array<unsigned char,32> digest{};
    return fileSha256(path,digest) && sha256Matches(digest,expected);
}
} // namespace wide
