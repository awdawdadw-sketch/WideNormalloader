#pragma once
#include "jip_build_profile.h"
#include "added_variable_owners.h"
#include "module_sha256.h"
#include "runtime_patch.h"
namespace wide {
class JipAddedVariablesRuntime {
    using Resolver=bool(*)(void*,uint32_t&);
    inline static JipAddedVariablesRuntime* active=nullptr;
    Resolver resolver=nullptr;CommandExecute originalCommand=nullptr;
    RuntimePatch createHook,comparePatch,commandPatch;void* code=nullptr;
    AddedVariableOwners owners;
    static bool __cdecl command(WIDE_COMMAND_ARGS){
        uint32_t owner=UINT32_MAX;
        if(active->resolver(scriptObj,owner) && PluginOwnerScope::valid(owner)){
            PluginOwnerScope scope(owner);return active->originalCommand(WIDE_PASS_ARGS);
        }
        if(result)*result=0;return true;
    }
    static void* __fastcall created(void* script,void*,char* name,void* locals,uint32_t subject,uint8_t byte){
        auto call=(void*(__thiscall*)(void*,char*,void*,uint32_t,uint8_t))active->createHook.trampoline;
        void* variable=call(script,name,locals,subject,byte);
        if(variable && name && name[0]!='*')active->owners.assigned(uint32_t(variable),byte,PluginOwnerScope::currentOrByte(byte));
        return variable;
    }
    static bool __cdecl match(uint32_t entry,void* script){
        uint32_t owner=UINT32_MAX;
        if(!active || !active->resolver(script,owner))return false;
        return active->owners.matches(*(uint32_t*)(entry+0xc),*(uint8_t*)(entry+0x10),owner);
    }
    void rollback(){commandPatch.restore();comparePatch.restore();createHook.restore();
        if(createHook.trampoline){VirtualFree(createHook.trampoline,0,MEM_RELEASE);createHook.trampoline=nullptr;}
        if(code){VirtualFree(code,0,MEM_RELEASE);code=nullptr;}if(active==this)active=nullptr;}
public:
    void clear(){owners.clear();}
    bool variableOwner(uint32_t variable,uint8_t byte,uint32_t& owner)const{return owners.get(variable,byte,owner);}
    void* restoreVariable(void* script,void* locals,uint32_t subject,const std::string& name,uint32_t author){
        if(active!=this || !script || !locals || name.empty() || name[0]=='*' || !PluginOwnerScope::valid(author))return nullptr;
        PluginOwnerScope scope(author);uint8_t byte=author>=256?253:uint8_t(author);
        return created(script,nullptr,const_cast<char*>(name.c_str()),locals,subject,byte);
    }
    void* temporaryVariable(void* script,void* locals,uint32_t subject,char* name){
        if(active!=this || !script || !locals || !name || name[0]!='*')return nullptr;
        return ((void*(__thiscall*)(void*,char*,void*,uint32_t,uint8_t))createHook.trampoline)(script,name,locals,subject,255);
    }
    static std::vector<unsigned char> compareStub(uint32_t address,uint32_t matched,uint32_t unmatched,uint32_t callback){
        std::vector<unsigned char> out;auto b=[&](std::initializer_list<unsigned char> bytes){out.insert(out.end(),bytes);};
        auto w=[&](uint32_t v){auto* p=(unsigned char*)&v;out.insert(out.end(),p,p+4);};
        b({0x9c,0x60,0x89,0xe3,0x81,0xec});w(0x220);
        b({0x83,0xe4,0xf0,0x0f,0xae,0x04,0x24,0x83,0xec,0x08,0x8b,0x43,0x08,0xff,0x70,0x18,0xff,0x33,0xb8});w(callback);
        // x86 bool returns define AL only; upper EAX bits may be nonzero on false.
        b({0xff,0xd0,0x83,0xc4,0x10,0x83,0x63,0x20,0xbf,0x84,0xc0,0x74,0x04,0x83,0x4b,0x20,0x40});
        b({0x0f,0xae,0x0c,0x24,0x89,0xdc,0x61,0x9d,0x0f,0x85});w(unmatched-address-uint32_t(out.size())-4);
        b({0xe9});w(matched-address-uint32_t(out.size())-4);return out;
    }
    bool install(HMODULE module,WideCommandTable* table,Resolver resolve){
        if(active || !table || !resolve || !moduleHasImageRange(module,jipRva(0x6a2e0)))return false;
        const uint32_t base=uint32_t(module);auto* add=table->getName("AddScriptVariable");auto* remove=table->getName("RemoveAllAddedVariables");
        const unsigned char entry[]={0x55,0x8b,0xec,0x83,0xec,0x0c},compare[]={0x38,0x4f,0x10,0x75,0x40};
        const unsigned char addEntry[]={0xb1,0x01,0xe9,0x69,0xfd,0xff,0xff};
        if(!add || !remove || uint32_t(add->execute)!=base+jipRva(0x34d70) || uint32_t(remove->execute)!=base+jipRva(0x34d90) ||
           memcmp((void*)(base+jipRva(0x34d70)),addEntry,7) || memcmp((void*)(base+jipRva(0x20b0)),entry,6) || memcmp((void*)(base+jipRva(0x34e31)),compare,5) || *(uint32_t*)(base+jipRva(0x6a2dc)))return false;
        resolver=resolve;originalCommand=add->execute;
        code=VirtualAlloc(nullptr,128,MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);if(!code)return false;
        auto bytes=compareStub(uint32_t(code),base+jipRva(0x34e36),base+jipRva(0x34e76),uint32_t(match));
        memcpy(code,bytes.data(),bytes.size());FlushInstructionCache(GetCurrentProcess(),code,bytes.size());active=this;
        unsigned char jump[5]={0xe9};*(uint32_t*)(jump+1)=uint32_t(code)-(base+jipRva(0x34e31)+5);CommandExecute replacement=command;
        if(!createHook.hook(base+jipRva(0x20b0),entry,6,(void*)created) || !comparePatch.replace(base+jipRva(0x34e31),compare,jump,5) ||
           !commandPatch.replace(uint32_t(&add->execute),(const unsigned char*)&originalCommand,(const unsigned char*)&replacement,4)){rollback();return false;}
        return true;
    }
};
}
