#pragma once
#include "module_sha256.h"
#include "runtime_patch.h"
#include "timer_save_codec.h"
#include "timer_patch_manifest.h"
#include <cstdio>
namespace wide {
struct TimerNativeMap {uint32_t buckets=0,capacity=8,count=0;};
struct TimerNativeInfo {uint32_t ref,owner;const char* name;bool permanent;unsigned char pad[3];};
struct TimerNativeValue {double countdown,remaining;uint32_t flags,pad;};
static_assert(sizeof(TimerNativeMap)==12 && sizeof(TimerNativeInfo)==16 && sizeof(TimerNativeValue)==24,"Pinned timer layouts");
class ShowOffTimerRuntime {
public: using Resolver=bool(*)(void*,uint32_t&);
private:
    inline static ShowOffTimerRuntime* active=nullptr;
    uint32_t base=0,pluginCount=0;Resolver resolver=nullptr;FILE* log=nullptr;
    std::vector<RuntimePatch> patches;std::vector<void*> executable;
    struct Lock {uint32_t token=0,base;explicit Lock(uint32_t b):base(b){((void(__thiscall*)(void*,void*))(b+0x54b0))(&token,(void*)(b+0x104a58));}
        ~Lock(){((void(__thiscall*)(void*))(base+0x5520))(&token);}};
    static uint32_t __cdecl owner(void* script){uint32_t out=UINT32_MAX;return active && active->resolver(script,out)?out:UINT32_MAX;}
    static uint32_t __cdecl matches(void* script,uint32_t full){return full!=UINT32_MAX && owner(script)==full;}
    static uint32_t __cdecl clearOwner(void* script,uint32_t mode){return mode==2?255:owner(script);}
    static void __cdecl legacyWriter(){if(!active->writeLegacy() && active->log){fputs("WIDE_TIMER_LEGACY_WRITE_FAILED\n",active->log);fflush(active->log);}}
    template<class T> static T read(uint32_t at){T out{};SIZE_T got=0;if(!at || !ReadProcessMemory(GetCurrentProcess(),(void*)at,&out,sizeof(out),&got) || got!=sizeof(out))throw "timer_memory_unreadable";return out;}
    template<class Visitor> static void walk(TimerNativeMap map,bool textKey,Visitor visit){
        if(!map.capacity || (map.capacity&(map.capacity-1)) || map.capacity>0x40000 || map.count>1048576 || (map.count && !map.buckets))throw "timer_map_invalid";
        if(!map.buckets)return;std::unordered_set<uint32_t> seen;
        for(uint32_t bucket=0;bucket<map.capacity;++bucket){uint32_t node=read<uint32_t>(map.buckets+bucket*4);
            while(node){if(seen.size()>=map.count || !seen.insert(node).second)throw "timer_map_chain_invalid";
                uint32_t next=read<uint32_t>(node);visit(read<uint32_t>(node+(textKey?8:4)),node+(textKey?16:8));node=next;}}
        if(seen.size()!=map.count)throw "timer_map_count_invalid";
    }
    static std::string name(uint32_t at){std::string out;for(unsigned i=0;i<=255;++i){char c=read<char>(at+i);if(!c)return out;out.push_back(c);}throw "timer_name_too_long";}
    static uint16_t slot(uint32_t key,uint32_t count){if(key==255)return timerPublicSlot;uint32_t s=key<253?key:key>=256?key-3:UINT32_MAX;if(s>=count)throw "timer_owner_unknown";return uint16_t(s);}
    static uint32_t key(uint16_t s){return s==timerPublicSlot?255:s<253?s:s+3;}
    TimerSave snapshotUnlocked(){TimerSave out;
        walk(read<TimerNativeMap>(base+0xf7e50),false,[&](uint32_t own,uint32_t subjects){SavedTimerOwner o;o.slot=slot(own,pluginCount);
            walk(read<TimerNativeMap>(subjects),false,[&](uint32_t ref,uint32_t timers){SavedTimerSubject s;s.ref=ref;
                walk(read<TimerNativeMap>(timers),true,[&](uint32_t text,uint32_t value){auto v=read<TimerNativeValue>(value);if(v.flags&0x80000000u)return;
                    s.timers.push_back({name(text),v.countdown,v.remaining,v.flags});});if(!s.timers.empty())o.subjects.push_back(std::move(s));});
            if(!o.subjects.empty())out.owners.push_back(std::move(o));});
        if(!validateTimerSave(out,pluginCount))throw "timer_snapshot_invalid";return out;
    }
    void* insert(TimerNativeMap& map,uint32_t k,bool text=false){void* value=nullptr;
        if(!((bool(__thiscall*)(void*,uint32_t,void**))(base+(text?0x76a30:0x76990)))(&map,k,&value) || !value)throw "timer_insert_failed";return value;}
    void destroy(TimerNativeMap& map){((void(__thiscall*)(void*))(base+0x76880))(&map);
        if(map.buckets)((void(__fastcall*)(void*,uint32_t))(base+0x78020))((void*)map.buckets,map.capacity*4);map=TimerNativeMap{};}
    void build(const TimerSave& saved,TimerNativeMap& map){
        for(const auto& o:saved.owners){auto* subjects=(TimerNativeMap*)insert(map,key(o.slot));*subjects=TimerNativeMap{};
            for(const auto& s:o.subjects){auto* timers=(TimerNativeMap*)insert(*subjects,s.ref);*timers=TimerNativeMap{};
                for(const auto& t:s.timers){auto* v=(TimerNativeValue*)insert(*timers,uint32_t(t.name.c_str()),true);*v={t.countdown,t.remaining,t.flags,0};}}}
    }
    bool writeLegacy(){try{Lock lock(base);auto saved=snapshotUnlocked();std::vector<unsigned char> bytes;std::vector<const SavedTimerOwner*> included;
        for(const auto& o:saved.owners)if(o.slot<253 || o.slot==timerPublicSlot)included.push_back(&o);
        auto put=[&](uint32_t v,unsigned n){identityPut(bytes,v,n);};put(uint32_t(included.size()),2);
        for(auto* o:included){if(o->subjects.size()>65535)return false;put(key(o->slot),1);put(uint32_t(o->subjects.size()),2);
            for(const auto& s:o->subjects){if(s.timers.size()>65535)return false;put(s.ref,4);put(uint32_t(s.timers.size()),2);
                for(const auto& t:s.timers){put(uint32_t(t.name.size()),1);bytes.insert(bytes.end(),t.name.begin(),t.name.end());
                    uint64_t bits;memcpy(&bits,&t.countdown,8);put(uint32_t(bits),4);put(uint32_t(bits>>32),4);memcpy(&bits,&t.remaining,8);put(uint32_t(bits),4);put(uint32_t(bits>>32),4);put(t.flags,4);}}}
        auto write=(bool(__cdecl*)(uint32_t,uint32_t,const void*,uint32_t))read<uint32_t>(base+0x102688);
        return write && write(0x54414f53,1,bytes.data(),uint32_t(bytes.size()));
    }catch(...){return false;}}
    void rollback(){for(auto p=patches.rbegin();p!=patches.rend();++p)p->restore();for(auto* p:executable)VirtualFree(p,0,MEM_RELEASE);patches.clear();executable.clear();if(active==this)active=nullptr;}
public:
    static std::vector<unsigned char> expected(const TimerBridgeSite& site,uint32_t module){
        std::vector<unsigned char> bytes(site.bytes,site.bytes+site.end-site.begin);
        for(uint32_t i=0;i<site.relocationCount;++i){uint32_t value;memcpy(&value,bytes.data()+site.relocations[i],4);value+=module-0x10000000u;memcpy(bytes.data()+site.relocations[i],&value,4);}
        return bytes;
    }
    // All bridge callbacks preserve integer/flags and x87/SSE state. Only the
    // requested destination or scheduler ZF changes; no copied relative calls.
    static std::vector<unsigned char> stub(const TimerBridgeSite& site,uint32_t address,uint32_t module,uint32_t getOwner,uint32_t match,uint32_t getClear,uint32_t write){
        std::vector<unsigned char> out;auto b=[&](std::initializer_list<unsigned char> v){out.insert(out.end(),v);};auto w=[&](uint32_t v){auto* p=(unsigned char*)&v;out.insert(out.end(),p,p+4);};
        b({0x9c,0x60,0x89,0xe3,0x81,0xec});w(0x220);b({0x83,0xe4,0xf0,0x0f,0xae,0x04,0x24});
        if(site.kind==2){b({0x83,0xec,0x08,0x8b,0x43,0x08,0x8b,0x40,0xec,0xff,0x70,0x04,0x8b,0x43,0x10,0xff,0x70,0x04,0xb8});w(match);}
        else if(site.kind==3){b({0x83,0xec,0x08,0xff,0x73,0x18,0x8b,0x43,0x08,0xff,0x70,0x18,0xb8});w(getClear);}
        else if(site.kind==4){b({0xb8});w(write);}
        else {b({0x83,0xec,0x0c,0x8b,0x43,(unsigned char)(site.kind==1?0:8),0xff,0x70,(unsigned char)(site.kind==1?4:0x18),0xb8});w(getOwner);}
        b({0xff,0xd0});if(site.kind!=4)b({0x83,0xc4,0x10});
        if(site.kind==2)b({0x83,0x63,0x20,0xbf,0x85,0xc0,0x74,0x04,0x83,0x4b,0x20,0x40});
        else if(site.kind!=4)b({0x89,0x43,(unsigned char)site.target});
        b({0x0f,0xae,0x0c,0x24,0x89,0xdc,0x61,0x9d});
        if(site.kind==2){b({0x0f,0x85});w(module+site.target-address-uint32_t(out.size())-4);}
        b({0xe9});w(module+(site.kind==4?site.target:site.end)-address-uint32_t(out.size())-4);return out;
    }
    bool snapshot(TimerSave& out){if(active!=this)return false;try{Lock lock(base);auto saved=snapshotUnlocked();out=std::move(saved);return true;}catch(...){return false;}}
    bool replace(const TimerSave& saved){if(active!=this || !validateTimerSave(saved,pluginCount))return false;TimerNativeMap staged;
        try{Lock lock(base);auto* live=(TimerNativeMap*)(base+0xf7e50);
            // Structural checks precede any destruction. Legacy opaque owner
            // metadata may be ambiguous, but a valid WTMR replaces it completely.
            walk(*live,false,[&](uint32_t,uint32_t subjects){walk(read<TimerNativeMap>(subjects),false,[&](uint32_t,uint32_t timers){walk(read<TimerNativeMap>(timers),true,[&](uint32_t,uint32_t value){(void)read<TimerNativeValue>(value);});});});
            build(saved,staged);std::swap(*live,staged);destroy(staged);
            __atomic_fetch_or((unsigned char*)(base+0x102656),2,__ATOMIC_SEQ_CST);return true;
        }catch(...){if(staged.buckets){try{Lock lock(base);destroy(staged);}catch(...){}}return false;}}
    bool install(HMODULE module,Resolver resolve,uint32_t count,FILE* output){
        if(!moduleHasImageRange(module,0x102691)){if(output){fputs("WIDE_TIMER_INSTALL_FAILED reason=module_range\n",output);fflush(output);}return false;}
        return installVerified(uint32_t(module),resolve,count,output);
    }
#ifdef WIDE_TIMER_RUNTIME_TEST
    bool installSynthetic(uint32_t module,Resolver resolve,uint32_t count){return installVerified(module,resolve,count,nullptr);}
    void uninstallSynthetic(){rollback();}
    bool writeLegacySynthetic(){return writeLegacy();}
#endif
private:
    bool installVerified(uint32_t module,Resolver resolve,uint32_t count,FILE* output){
        auto fail=[&](const char* reason,uint32_t rva=0,uint32_t value=0){if(output){fprintf(output,"WIDE_TIMER_INSTALL_FAILED reason=%s rva=%08X value=%08X count=%u active=%u\n",reason,rva,value,count,active!=nullptr);fflush(output);}return false;};
        auto mismatch=[&](const char* reason,uint32_t rva,const unsigned char* expected,uint32_t size){if(output){fprintf(output,"WIDE_TIMER_SIGNATURE_DETAIL reason=%s rva=%08X expected=",reason,rva);for(uint32_t i=0;i<size;++i)fprintf(output,"%02X",expected[i]);fputs(" actual=",output);for(uint32_t i=0;i<size;++i)fprintf(output,"%02X",*(unsigned char*)(module+rva+i));fputc('\n',output);fflush(output);}return fail(reason,rva,size);};
        if(active || !module || !resolve || !count || count>1024)return fail("invalid_install_state");
        for(uint32_t rva:{0xf7e4cu,0xf7e58u})if(*(uint32_t*)(module+rva))return fail("native_timer_state_not_empty",rva,*(uint32_t*)(module+rva));
        for(auto& s:timerWidthSites)if(memcmp((void*)(module+s.rva),s.before,s.size))return mismatch("width_signature",s.rva,s.before,s.size);
        for(auto& s:timerBridgeSites){auto bytes=expected(s,module);if(memcmp((void*)(module+s.begin),bytes.data(),bytes.size())){
            if(output){fprintf(output,"WIDE_TIMER_PREFLIGHT_MISMATCH rva=%08X bytes=%u relocations=%u\n",s.begin,uint32_t(bytes.size()),s.relocationCount);fflush(output);}return mismatch("bridge_signature",s.begin,bytes.data(),uint32_t(bytes.size()));}}
        const unsigned char oldCall[]={0xe8,0x39,0x14,0,0};if(memcmp((void*)(module+0x754A2),oldCall,5))return mismatch("legacy_writer_call_signature",0x754A2,oldCall,5);
        base=module;resolver=resolve;pluginCount=count;log=output;
        try{patches.reserve(29);executable.reserve(13);
            for(auto& s:timerBridgeSites){auto* code=VirtualAlloc(nullptr,256,MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);if(!code){rollback();return fail("bridge_allocation",s.begin,GetLastError());}executable.push_back(code);
                auto bytes=stub(s,uint32_t(code),base,uint32_t(owner),uint32_t(matches),uint32_t(clearOwner),uint32_t(legacyWriter));if(bytes.size()>256){rollback();return fail("bridge_capacity",s.begin,uint32_t(bytes.size()));}
                memcpy(code,bytes.data(),bytes.size());FlushInstructionCache(GetCurrentProcess(),code,bytes.size());}
            active=this;
            for(auto& s:timerWidthSites){patches.emplace_back();if(!patches.back().replace(base+s.rva,s.before,s.after,s.size)){rollback();return fail("width_patch_write",s.rva);}}
            unsigned char call[]={0xe8,0,0,0,0};*(uint32_t*)(call+1)=0x76990-0x754A7;patches.emplace_back();
            if(!patches.back().replace(base+0x754A2,oldCall,call,5)){rollback();return fail("legacy_writer_patch_write",0x754A2);}
            for(size_t i=0;i<executable.size();++i){auto& s=timerBridgeSites[i];std::vector<unsigned char> jump(s.end-s.begin,0x90);jump[0]=0xe9;*(uint32_t*)(jump.data()+1)=uint32_t(executable[i])-(base+s.begin+5);
                auto before=expected(s,base);patches.emplace_back();if(!patches.back().replace(base+s.begin,before.data(),jump.data(),uint32_t(jump.size()))){rollback();return fail("bridge_patch_write",s.begin);}}
            return true;
        }catch(...){rollback();return fail("installation_exception");}
    }
};
}
