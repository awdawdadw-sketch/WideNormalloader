#pragma once
#include "save_identity_codec.h"
namespace wide {
constexpr uint32_t jipScriptLinkRecord=0x574A534C,jipScriptLinkVersion=1;
constexpr uint16_t jipScriptLinkPublic=0xffff;
struct SavedScriptVariable {uint32_t subject=0;uint16_t author=0;std::string name;uint64_t bits=0;};
struct SavedLinkedReference {uint32_t subject=0,target=0;uint16_t author=0;};
struct ScriptLinkSave {std::vector<SavedScriptVariable> variables;std::vector<SavedLinkedReference> links;};
inline bool validateScriptLinkSave(const ScriptLinkSave& in,uint32_t plugins){
    if(!plugins || plugins>1024 || in.variables.size()>1048576 || in.links.size()>1048576)return false;
    auto owner=[&](uint16_t slot){return slot==jipScriptLinkPublic || slot<plugins;};
    std::unordered_map<uint32_t,std::unordered_set<std::string>> names;
    for(auto& v:in.variables)if(!v.subject || !owner(v.author) || v.name.empty() || v.name.size()>255 || v.name[0]=='*' || v.name.find('\0')!=std::string::npos || !names[v.subject].insert(v.name).second)return false;
    std::unordered_set<uint32_t> subjects;
    for(auto& v:in.links)if(!v.subject || !v.target || !owner(v.author) || !subjects.insert(v.subject).second)return false;
    return true;
}
inline bool encodeScriptLinkSave(const ScriptLinkSave& in,uint32_t plugins,std::vector<unsigned char>& output){
    if(!validateScriptLinkSave(in,plugins))return false;std::vector<unsigned char> out;
    auto word=[&](uint32_t v,unsigned n=4){identityPut(out,v,n);if(out.size()>maxIdentityBytes-4)throw 1;};
    try{word(jipScriptLinkVersion);word(plugins);word(uint32_t(in.variables.size()));word(uint32_t(in.links.size()));
        for(auto& v:in.variables){word(v.subject);word(v.author,2);word(uint32_t(v.name.size()),1);out.insert(out.end(),v.name.begin(),v.name.end());word(uint32_t(v.bits));word(uint32_t(v.bits>>32));}
        for(auto& v:in.links){word(v.subject);word(v.target);word(v.author,2);}
        word(identityCrc(out.data(),out.size()));output=std::move(out);return true;
    }catch(...){return false;}
}
inline bool decodeScriptLinkSave(const unsigned char* data,size_t size,uint32_t plugins,ScriptLinkSave& output){
    if(!data || size<20 || size>maxIdentityBytes)return false;size_t pos=0,end=size-4;
    auto word=[&](unsigned n=4){if(n>end-pos)throw 1;uint32_t v=0;for(unsigned i=0;i<n;++i)v|=uint32_t(data[pos++])<<(i*8);return v;};
    try{if(word()!=jipScriptLinkVersion || word()!=plugins)return false;uint32_t nv=word(),nl=word();
        if(nv>1048576 || nl>1048576 || uint64_t(nv)*16+uint64_t(nl)*10>end-pos)return false;
        ScriptLinkSave parsed;
        for(uint32_t i=0;i<nv;++i){SavedScriptVariable v;v.subject=word();v.author=uint16_t(word(2));unsigned n=word(1);if(!n || n>end-pos)throw 1;v.name.assign((const char*)data+pos,n);pos+=n;v.bits=word();v.bits|=uint64_t(word())<<32;parsed.variables.push_back(std::move(v));}
        for(uint32_t i=0;i<nl;++i){SavedLinkedReference v;v.subject=word();v.target=word();v.author=uint16_t(word(2));parsed.links.push_back(v);}
        uint32_t crc=0;for(unsigned i=0;i<4;++i)crc|=uint32_t(data[end+i])<<(i*8);
        if(pos!=end || crc!=identityCrc(data,end) || !validateScriptLinkSave(parsed,plugins))return false;
        output=std::move(parsed);return true;
    }catch(...){return false;}
}
template<class Resolve> bool remapScriptLinkSave(const ScriptLinkSave& in,const std::vector<uint32_t>& slots,uint32_t plugins,Resolve resolve,ScriptLinkSave& output){
    if(!validateScriptLinkSave(in,uint32_t(slots.size())))return false;
    auto author=[&](uint16_t& slot){if(slot==jipScriptLinkPublic)return true;if(slots[slot]>=plugins)return false;slot=uint16_t(slots[slot]);return true;};
    try{ScriptLinkSave mapped=in;
        for(auto& v:mapped.variables){uint32_t ref=0;if(!author(v.author) || !resolve(v.subject,ref) || !ref)return false;v.subject=ref;
            // Preserve JIP's existing VarData predicate: low DWORD nonzero and
            // high DWORD zero denotes a form value, all other bits are numeric.
            if(uint32_t(v.bits) && !(v.bits>>32)){if(!resolve(uint32_t(v.bits),ref) || !ref)return false;v.bits=ref;}}
        for(auto& v:mapped.links){uint32_t subject=0,target=0;if(!author(v.author) || !resolve(v.subject,subject) || !resolve(v.target,target))return false;v.subject=subject;v.target=target;}
        if(!validateScriptLinkSave(mapped,plugins))return false;output=std::move(mapped);return true;
    }catch(...){return false;}
}
}
