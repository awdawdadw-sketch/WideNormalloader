#pragma once
#include "save_identity_codec.h"
#include <cmath>
#include <cstring>
namespace wide {
// Proposed authoritative permanent timer record. This codec is not installed
// until native map widening, callbacks and load/save integration are complete.
constexpr uint32_t timerSaveRecord=0x57544D52, timerSaveVersion=1;
constexpr uint16_t timerPublicSlot=0xFFFF;
struct SavedTimer {std::string name;double countdown=0,remaining=0;uint32_t flags=0;};
struct SavedTimerSubject {uint32_t ref=0;std::vector<SavedTimer> timers;};
struct SavedTimerOwner {uint16_t slot=0;std::vector<SavedTimerSubject> subjects;};
struct TimerSave {std::vector<SavedTimerOwner> owners;};
inline bool validateTimerSave(const TimerSave& in,uint32_t pluginCount){
    if(!pluginCount || pluginCount>1024 || in.owners.size()>1025)return false;
    std::unordered_set<uint16_t> owners;size_t total=0;
    for(const auto& owner:in.owners){
        if((owner.slot!=timerPublicSlot && owner.slot>=pluginCount) || !owners.insert(owner.slot).second)return false;
        std::unordered_set<uint32_t> subjects;
        for(const auto& subject:owner.subjects){
            if(!subject.ref || !subjects.insert(subject.ref).second)return false;
            std::unordered_set<std::string> names;
            for(const auto& timer:subject.timers){
                if(++total>1048576 || timer.name.empty() || timer.name.size()>255 || timer.name[0]=='*' ||
                   timer.name.find('\0')!=std::string::npos || !names.insert(timer.name).second ||
                   ((timer.name[0]=='_')!=(owner.slot==timerPublicSlot)) ||
                   !std::isfinite(timer.countdown) || !std::isfinite(timer.remaining) || (timer.flags&0x80000000u))return false;
            }
        }
    }return true;
}
inline bool encodeTimerSave(const TimerSave& in,uint32_t pluginCount,std::vector<unsigned char>& output){
    if(!validateTimerSave(in,pluginCount))return false;
    std::vector<unsigned char> out;
    auto word=[&](uint32_t v,unsigned n=4){identityPut(out,v,n);if(out.size()>maxIdentityBytes-4)throw 1;};
    auto number=[&](double value){uint64_t bits;memcpy(&bits,&value,8);word(uint32_t(bits));word(uint32_t(bits>>32));};
    try{
        word(timerSaveVersion);word(pluginCount);word(uint32_t(in.owners.size()));
        for(const auto& owner:in.owners){word(owner.slot,2);word(uint32_t(owner.subjects.size()));
            for(const auto& subject:owner.subjects){word(subject.ref);word(uint32_t(subject.timers.size()));
                for(const auto& timer:subject.timers){word(uint32_t(timer.name.size()),1);out.insert(out.end(),timer.name.begin(),timer.name.end());
                    number(timer.countdown);number(timer.remaining);word(timer.flags);}
            }
        }
        word(identityCrc(out.data(),out.size()));output=std::move(out);return true;
    }catch(...){return false;}
}
inline bool decodeTimerSave(const unsigned char* data,size_t size,uint32_t pluginCount,TimerSave& output){
    if(!data || size<16 || size>maxIdentityBytes)return false;
    size_t pos=0,end=size-4;
    auto word=[&](unsigned n=4){if(n>end-pos)throw 1;uint32_t v=0;for(unsigned i=0;i<n;++i)v|=uint32_t(data[pos++])<<(8*i);return v;};
    auto count=[&](unsigned minimum){uint32_t n=word();if(n>1048576 || n>(end-pos)/minimum)throw 1;return n;};
    auto number=[&](){uint64_t bits=word();bits|=uint64_t(word())<<32;double value;memcpy(&value,&bits,8);return value;};
    try{
        if(word()!=timerSaveVersion || word()!=pluginCount)return false;
        TimerSave parsed;uint32_t owners=count(6);if(owners>1025)return false;
        for(uint32_t i=0;i<owners;++i){SavedTimerOwner owner;owner.slot=uint16_t(word(2));uint32_t subjects=count(8);
            for(uint32_t j=0;j<subjects;++j){SavedTimerSubject subject;subject.ref=word();uint32_t timers=count(22);
                for(uint32_t k=0;k<timers;++k){SavedTimer timer;uint32_t length=word(1);if(!length || length>end-pos)throw 1;
                    timer.name.assign((const char*)data+pos,length);pos+=length;
                    timer.countdown=number();timer.remaining=number();timer.flags=word();subject.timers.push_back(std::move(timer));}
                owner.subjects.push_back(std::move(subject));
            }parsed.owners.push_back(std::move(owner));
        }
        if(pos!=end || !validateTimerSave(parsed,pluginCount))return false;
        uint32_t crc=0;for(unsigned i=0;i<4;++i)crc|=uint32_t(data[end+i])<<(8*i);
        if(crc!=identityCrc(data,end))return false;
        output=std::move(parsed);return true;
    }catch(...){return false;}
}
template<class Resolver> bool remapTimerSave(const TimerSave& saved,const std::vector<uint32_t>& slots,uint32_t currentCount,Resolver resolve,TimerSave& output){
    if(!validateTimerSave(saved,uint32_t(slots.size())))return false;
    try{
        TimerSave mapped=saved;
        for(auto& owner:mapped.owners){
            if(owner.slot!=timerPublicSlot){if(slots[owner.slot]>=currentCount)return false;owner.slot=uint16_t(slots[owner.slot]);}
            for(auto& subject:owner.subjects){uint32_t current=0;if(!resolve(subject.ref,current))return false;subject.ref=current;}
        }
        if(!validateTimerSave(mapped,currentCount))return false;
        output=std::move(mapped);return true;
    }catch(...){return false;}
}
}
