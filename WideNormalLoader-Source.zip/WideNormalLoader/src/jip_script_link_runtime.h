#pragma once
#include "jip_build_profile.h"
#include <windows.h>
#include <array>
#include <memory>
#include "runtime_patch.h"
#include "module_sha256.h"
#include "jip_script_link_codec.h"
namespace wide {
// Run only from the main-thread serialization callbacks. JIP owns all native
// allocations; this adapter never substitutes STL containers for JIP maps.
class JipScriptLinkRuntime {
public:
    using Lookup=void*(*)(uint32_t);
    using VariableOwner=bool(*)(uint32_t,uint8_t,uint32_t&);
    using LinkOwner=bool(*)(uint32_t,uint32_t,uint8_t,uint32_t&);
    using AddVariable=void*(*)(void*,void*,uint32_t,const std::string&,uint32_t);
    using SetLink=bool(*)(void*,void*,uint32_t);
    using SaveCallback=void(__cdecl*)(void*);
private:
    struct Map{uint32_t buckets,capacity,count;};
    uint32_t base=0;Lookup lookup=nullptr;VariableOwner variableOwner=nullptr;
    LinkOwner linkOwner=nullptr;AddVariable addVariable=nullptr;SetLink setLink=nullptr;
    RuntimePatch saveHook;inline static JipScriptLinkRuntime* active=nullptr;void(*failure)()=nullptr;
    static void __cdecl saved(void* context){
        if(!active->filteredSave((SaveCallback)active->saveHook.trampoline,context) && active->failure)active->failure();
    }
    template<class T> static T read(uint32_t address){T out{};SIZE_T got=0;
        if(!address || !ReadProcessMemory(GetCurrentProcess(),(void*)address,&out,sizeof(out),&got) || got!=sizeof(out))throw "unreadable_script_link_object";return out;}
    static std::string name(uint32_t address){std::string out;for(unsigned i=0;i<=255;++i){char c=read<char>(address+i);if(!c)return out;out.push_back(c);}throw "oversize_script_variable_name";}
    template<class Visitor> static void walk(Map map,bool strings,Visitor visit){
        if(!map.capacity || (map.capacity&(map.capacity-1)) || map.capacity>1048576 || map.count>1048576 || (map.count && !map.buckets))throw "invalid_script_link_map";
        if(!map.buckets)return;std::unordered_set<uint32_t> visited;
        for(uint32_t i=0;i<map.capacity;++i){uint32_t p=read<uint32_t>(map.buckets+i*4);
            while(p){if(visited.size()>=map.count || !visited.insert(p).second)throw "invalid_script_link_chain";
                uint32_t next=read<uint32_t>(p);visit(read<uint32_t>(p+(strings?8:4)),p+(strings?12:8));p=next;}}
        if(visited.size()!=map.count)throw "script_link_count_mismatch";
    }
    static uint16_t slot(uint32_t author,uint32_t count){
        if(author==255)return jipScriptLinkPublic;uint32_t s=author<253?author:author>=256?author-3:UINT32_MAX;
        if(s>=count)throw "unknown_script_link_author";return uint16_t(s);
    }
    static uint32_t owner(uint16_t slot){return slot==jipScriptLinkPublic?255:slot<253?slot:slot+3;}
    bool reference(void* form){return form && read<uint32_t>(read<uint32_t>(uint32_t(form))+0xf0)==0x8d0360;}
    bool scriptLocals(void* form,void*& script,void*& locals){
        script=locals=nullptr;if(!form)return false;uint32_t p=uint32_t(form);
        if(reference(form)){
            auto get=(void*(__thiscall*)(void*,uint32_t))(base+jipRva(0x573d0));
            void* extra=get((void*)(p+0x44),0xd);if(!extra)return false;
            script=read<void*>(uint32_t(extra)+0xc);locals=read<void*>(uint32_t(extra)+0x10);
        }else if(read<uint8_t>(p+4)==0x47){script=read<void*>(p+0x1c);locals=read<void*>(p+0x5c);}
        return script && locals;
    }
    static bool contains(void* locals,void* variable){
        uint32_t node=read<uint32_t>(uint32_t(locals)+0xc);std::unordered_set<uint32_t> seen;
        while(node){if(seen.size()>=1048576 || !seen.insert(node).second)return false;
            if(read<void*>(node)==variable)return true;node=read<uint32_t>(node+4);}return false;
    }
public:
#ifdef WIDE_JIP_SCRIPT_LINK_TEST
    void bindSynthetic(uint32_t b,Lookup l,VariableOwner v,LinkOwner o,AddVariable a,SetLink s){base=b;lookup=l;variableOwner=v;linkOwner=o;addVariable=a;setLink=s;}
#endif
    bool bind(HMODULE module,Lookup l,VariableOwner v,LinkOwner o,AddVariable a,SetLink s){
        if(!l || !v || !o || !a || !s || !moduleHasImageRange(module,jipRva(0x7637b)))return false;
        base=uint32_t(module);lookup=l;variableOwner=v;linkOwner=o;addVariable=a;setLink=s;return true;
    }
    bool installSaveFilter(void(*onFailure)()){
        const unsigned char expected[]={0x55,0x8b,0xec,0x83,0xe4,0xf8};
        if(!base || active || !onFailure || memcmp((void*)(base+jipRva(0x160d0)),expected,6))return false;
        active=this;failure=onFailure;
        if(!saveHook.hook(base+jipRva(0x160d0),expected,6,(void*)saved)){active=nullptr;return false;}return true;
    }
    bool filteredSave(SaveCallback callback,void* context){
        // Native byte-author records contain only legacy/public authors. The
        // full WJSL record remains authoritative for extended authors. Borrowed
        // iterator views exist only while the original read-only writer runs.
        struct Child{uint32_t bucket=0;std::vector<std::array<uint32_t,5>> nodes;};
        try{Map originalVars=read<Map>(base+jipRva(0x6a2d4)),originalLinks=read<Map>(base+jipRva(0x6a31c));
            std::vector<std::unique_ptr<Child>> children;std::vector<std::array<uint32_t,5>> vars;
            std::vector<std::array<uint32_t,4>> links;vars.reserve(originalVars.count);links.reserve(originalLinks.count);
            walk(originalVars,false,[&](uint32_t subject,uint32_t address){auto child=std::make_unique<Child>();
                walk(read<Map>(address),true,[&](uint32_t key,uint32_t value){uint32_t v=read<uint32_t>(value),author=UINT32_MAX;uint8_t byte=read<uint8_t>(value+4);
                    if(!variableOwner(v,byte,author))throw "unknown_native_save_variable_author";
                    if(author<253 || author==255)child->nodes.push_back({0,read<uint32_t>(value-8),key,v,byte});});
                if(child->nodes.empty())return;if(child->nodes.size()>65535)throw "native_variable_count_overflow";
                for(size_t i=0;i<child->nodes.size();++i)child->nodes[i][0]=i+1<child->nodes.size()?uint32_t(child->nodes[i+1].data()):0;
                child->bucket=uint32_t(child->nodes[0].data());vars.push_back({0,subject,uint32_t(&child->bucket),1,uint32_t(child->nodes.size())});children.push_back(std::move(child));});
            walk(originalLinks,false,[&](uint32_t subject,uint32_t value){uint32_t target=read<uint32_t>(value),author=UINT32_MAX;uint8_t byte=read<uint8_t>(value+4);
                if(!linkOwner(subject,target,byte,author))throw "unknown_native_save_link_author";
                if(author<253 || author==255)links.push_back({0,subject,target,byte});});
            if(vars.size()>65535 || links.size()>65535)return false;
            for(size_t i=0;i<vars.size();++i)vars[i][0]=i+1<vars.size()?uint32_t(vars[i+1].data()):0;
            for(size_t i=0;i<links.size();++i)links[i][0]=i+1<links.size()?uint32_t(links[i+1].data()):0;
            uint32_t varBucket=vars.empty()?0:uint32_t(vars[0].data()),linkBucket=links.empty()?0:uint32_t(links[0].data());
            auto* varRoot=(Map*)(base+jipRva(0x6a2d4));auto* linkRoot=(Map*)(base+jipRva(0x6a31c));
            struct Restore{Map* v;Map* l;Map oldV,oldL;~Restore(){*v=oldV;*l=oldL;}} restore{varRoot,linkRoot,originalVars,originalLinks};
            *varRoot={uint32_t(&varBucket),1,uint32_t(vars.size())};*linkRoot={uint32_t(&linkBucket),1,uint32_t(links.size())};
            callback(context);return true;
        }catch(...){return false;}
    }
    bool snapshot(uint32_t count,ScriptLinkSave& output){if(!base)return false;try{ScriptLinkSave out;
        walk(read<Map>(base+jipRva(0x6a2d4)),false,[&](uint32_t subject,uint32_t vars){
            walk(read<Map>(vars),true,[&](uint32_t key,uint32_t value){
                uint32_t variable=read<uint32_t>(value),author=UINT32_MAX;uint8_t byte=read<uint8_t>(value+4);
                if(!variableOwner(variable,byte,author))throw "unknown_added_variable_author";
                out.variables.push_back({subject,slot(author,count),name(key),read<uint64_t>(variable+8)});});});
        walk(read<Map>(base+jipRva(0x6a31c)),false,[&](uint32_t subject,uint32_t value){
            uint32_t target=read<uint32_t>(value),author=UINT32_MAX;uint8_t byte=read<uint8_t>(value+4);
            if(!linkOwner(subject,target,byte,author))throw "unknown_linked_reference_author";
            out.links.push_back({subject,target,slot(author,count)});});
        if(!validateScriptLinkSave(out,count))return false;output=std::move(out);return true;
    }catch(...){return false;}}
    bool restore(const ScriptLinkSave& in,uint32_t count){
        if(!base || !validateScriptLinkSave(in,count))return false;
        struct Var{void* script;void* locals;const SavedScriptVariable* saved;};
        struct Link{void* subject;void* target;const SavedLinkedReference* saved;};
        try{std::vector<Var> vars;std::vector<Link> links;
            // Preflight every subject, native script/local pair, and target.
            // Native allocation failures after this point are not transactional.
            for(auto& v:in.variables){void* script=nullptr;void* locals=nullptr;
                if(!scriptLocals(lookup(v.subject),script,locals))return false;
                if(uint32_t(v.bits) && !(v.bits>>32) && !lookup(uint32_t(v.bits)))return false;
                vars.push_back({script,locals,&v});}
            for(auto& v:in.links){void* from=lookup(v.subject);void* to=lookup(v.target);
                if(!reference(from) || !reference(to))return false;links.push_back({from,to,&v});}
            for(auto& v:vars){void* variable=addVariable(v.script,v.locals,v.saved->subject,v.saved->name,owner(v.saved->author));
                if(!variable || !contains(v.locals,variable))return false;
                memcpy((char*)variable+8,&v.saved->bits,8);}
            for(auto& v:links)if(!setLink(v.subject,v.target,owner(v.saved->author)))return false;
            return true;
        }catch(...){return false;}
    }
};
}
