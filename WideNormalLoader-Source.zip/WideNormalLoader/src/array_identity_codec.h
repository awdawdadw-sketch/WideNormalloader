#pragma once
#include <algorithm>
#include "save_identity_codec.h"
namespace wide {
// Experimental WARR metadata; runtime reader is not enabled. Slots refer to the
// accompanying WIDM order. FFFF means generated context, never plugin 255.
constexpr uint32_t arrayIdentityRecord=0x57415252,arrayIdentityVersion=1;
constexpr uint16_t arrayGeneratedContext=0xFFFF;
struct ArraySavedReference {uint16_t slot;uint8_t nativeByte;uint32_t count;};
struct ArraySavedIdentity {
    uint32_t id,coreRecordCrc;uint16_t creator;uint8_t nativeOwner;
    std::vector<ArraySavedReference> refs;
};
struct ArrayIdentitySave {uint32_t plugins=0,manifestCrc=0;std::vector<ArraySavedIdentity> arrays;};
struct ArrayCoreIdentity {uint32_t recordCrc;uint8_t owner;std::vector<uint8_t> refs;uint32_t version=2;};
inline bool validArraySlot(uint16_t slot,uint8_t byte,uint32_t plugins){
    if(slot==arrayGeneratedContext)return byte==255;
    if(slot>=plugins)return false;
    return byte<253?slot==byte:(byte==253 || byte==254) && slot>=253;
}
inline bool validateArrayIdentitySave(const ArrayIdentitySave& value){
    if(!value.plugins || value.plugins>1024 || value.arrays.size()>1048576)return false;
    uint64_t bytes=20;std::unordered_set<uint32_t> ids;
    for(const auto& a:value.arrays){
        if(!a.id || !ids.insert(a.id).second || !validArraySlot(a.creator,a.nativeOwner,value.plugins) || a.refs.empty() || a.refs.size()>=0x4000)return false;
        uint32_t count=0;std::unordered_set<uint32_t> groups;
        for(const auto& ref:a.refs){
            if(!validArraySlot(ref.slot,ref.nativeByte,value.plugins) || !ref.count || ref.count>=0x4000 || !groups.insert((uint32_t(ref.slot)<<8)|ref.nativeByte).second)return false;
            count+=ref.count;if(count>=0x4000)return false;
        }
        bytes+=16+uint64_t(a.refs.size())*7;if(bytes>maxIdentityBytes)return false;
    }
    return true;
}
inline bool encodeArrayIdentities(const ArrayIdentitySave& value,std::vector<unsigned char>& output){
    if(!validateArrayIdentitySave(value))return false;
    auto sorted=value.arrays;std::sort(sorted.begin(),sorted.end(),[](const auto& a,const auto& b){return a.id<b.id;});
    std::vector<unsigned char> bytes;
    identityPut(bytes,arrayIdentityVersion,4);identityPut(bytes,value.plugins,4);identityPut(bytes,value.manifestCrc,4);identityPut(bytes,(uint32_t)sorted.size(),4);
    for(auto& a:sorted){
        std::sort(a.refs.begin(),a.refs.end(),[](const auto& x,const auto& y){return x.slot!=y.slot?x.slot<y.slot:x.nativeByte<y.nativeByte;});
        identityPut(bytes,a.id,4);identityPut(bytes,a.coreRecordCrc,4);identityPut(bytes,a.creator,2);identityPut(bytes,a.nativeOwner,1);identityPut(bytes,0,1);identityPut(bytes,(uint32_t)a.refs.size(),4);
        for(auto ref:a.refs){identityPut(bytes,ref.slot,2);identityPut(bytes,ref.nativeByte,1);identityPut(bytes,ref.count,4);}
    }
    identityPut(bytes,identityCrc(bytes.data(),bytes.size()),4);output=std::move(bytes);return true;
}
inline bool decodeArrayIdentities(const unsigned char* bytes,size_t length,uint32_t plugins,uint32_t manifestCrc,ArrayIdentitySave& output){
    if(!bytes || length<20 || length>maxIdentityBytes)return false;
    size_t pos=0,end=length-4;
    uint32_t crc=uint32_t(bytes[end])|uint32_t(bytes[end+1])<<8|uint32_t(bytes[end+2])<<16|uint32_t(bytes[end+3])<<24;
    if(identityCrc(bytes,end)!=crc)return false;
    auto word=[&](unsigned width,uint32_t& v){if(width>end-pos)return false;v=0;for(unsigned i=0;i<width;++i)v|=uint32_t(bytes[pos++])<<(8*i);return true;};
    uint32_t version,n,p,m;
    if(!word(4,version) || version!=arrayIdentityVersion || !word(4,p) || p!=plugins || !word(4,m) || m!=manifestCrc || !word(4,n) || n>1048576 || n>(end-pos)/23)return false;
    ArrayIdentitySave value;value.plugins=p;value.manifestCrc=m;value.arrays.reserve(n);
    for(uint32_t i=0;i<n;++i){
        ArraySavedIdentity a{};uint32_t slot,byte,reserved,groups;
        if(!word(4,a.id) || !word(4,a.coreRecordCrc) || !word(2,slot) || !word(1,byte) || !word(1,reserved) || reserved || !word(4,groups) || !groups || groups>=0x4000 || groups>(end-pos)/7)return false;
        a.creator=(uint16_t)slot;a.nativeOwner=(uint8_t)byte;a.refs.reserve(groups);
        for(uint32_t j=0;j<groups;++j){uint32_t count;if(!word(2,slot) || !word(1,byte) || !word(4,count))return false;a.refs.push_back({(uint16_t)slot,(uint8_t)byte,count});}
        value.arrays.push_back(std::move(a));
    }
    if(pos!=end || !validateArrayIdentitySave(value))return false;
    output=std::move(value);return true;
}
inline bool matchArrayCoreIdentities(const ArrayIdentitySave& saved,const std::unordered_map<uint32_t,ArrayCoreIdentity>& core){
    if(!validateArrayIdentitySave(saved) || core.size()!=saved.arrays.size())return false;
    for(const auto& a:saved.arrays){
        auto it=core.find(a.id);if(it==core.end() || it->second.version!=2 || it->second.recordCrc!=a.coreRecordCrc || it->second.owner!=a.nativeOwner)return false;
        uint32_t expected[256]{},actual[256]{};
        for(auto ref:a.refs)expected[ref.nativeByte]+=ref.count;
        if(it->second.refs.size()>=0x4000)return false;
        for(auto byte:it->second.refs)++actual[byte];
        for(uint32_t byte=0;byte<256;++byte)if(expected[byte]!=actual[byte])return false;
    }
    return true;
}
// The core catalog must describe the original ARVR payloads, before any
// FormID or owner remapping. Array IDs and nested IDs are unchanged.
inline bool remapArrayIdentities(const ArrayIdentitySave& saved,const std::unordered_map<uint32_t,ArrayCoreIdentity>& core,const std::vector<uint32_t>& slots,uint32_t currentPlugins,uint32_t currentManifestCrc,ArrayIdentitySave& output){
    if(!matchArrayCoreIdentities(saved,core) || slots.size()!=saved.plugins || !currentPlugins || currentPlugins>1024)return false;
    std::unordered_set<uint32_t> used;
    for(auto slot:slots)if(slot!=UINT32_MAX && (slot>=currentPlugins || !used.insert(slot).second))return false;
    ArrayIdentitySave value=saved;value.plugins=currentPlugins;value.manifestCrc=currentManifestCrc;
    auto map=[&](uint16_t& slot,uint8_t& byte){
        if(slot==arrayGeneratedContext)return true;
        auto current=slots[slot];if(current==UINT32_MAX)return false;
        slot=(uint16_t)current;byte=current<253?(uint8_t)current:253;return true;
    };
    for(auto& a:value.arrays){if(!map(a.creator,a.nativeOwner))return false;for(auto& ref:a.refs)if(!map(ref.slot,ref.nativeByte))return false;}
    // Two old byte groups of the same plugin can project to one byte.
    for(auto& a:value.arrays){
        std::vector<ArraySavedReference> merged;
        for(auto ref:a.refs){auto it=std::find_if(merged.begin(),merged.end(),[&](const auto& old){return old.slot==ref.slot && old.nativeByte==ref.nativeByte;});if(it==merged.end())merged.push_back(ref);else it->count+=ref.count;}
        a.refs=std::move(merged);
    }
    if(!validateArrayIdentitySave(value))return false;output=std::move(value);return true;
}
}
