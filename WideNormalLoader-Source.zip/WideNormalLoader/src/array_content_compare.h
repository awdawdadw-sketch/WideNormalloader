#pragma once
#include "array_content_types.h"
namespace wide {
struct ArrayContentComparison {bool passed=true;uint32_t checked=0,numeric=0,strings=0,forms=0,extendedForms=0,nested=0;uint32_t firstFailure=UINT32_MAX;const char* reason="none";};
template<class Remap> ArrayContentComparison compareArrayContents(const ArrayContent& saved,const ArrayContent& actual,Remap remap){
 ArrayContentComparison result;
 if(saved.id!=actual.id || saved.owner!=actual.owner || saved.key!=actual.key || saved.packed!=actual.packed || saved.elements.size()!=actual.elements.size()){result.passed=false;result.reason="array_metadata";return result;}
 for(uint32_t i=0;i<saved.elements.size();++i){auto& a=saved.elements[i];auto& b=actual.elements[i];const char* failure=nullptr;++result.checked;
  if(saved.key==3?a.keyText!=b.keyText:a.keyBits!=b.keyBits)failure="key";
  else if(a.type!=b.type)failure="type";
  else if(a.type==1){++result.numeric;if(a.bits!=b.bits)failure="numeric_bits";}
  else if(a.type==3){++result.strings;if(a.text!=b.text)failure="string_bytes";}
  else if(a.type==4){++result.nested;if(a.bits!=b.bits)failure="nested_array_ID";}
  else if(a.type==2){++result.forms;uint32_t expected=0;if(a.bits>>24==253 || a.bits>>24==254)++result.extendedForms;if(!remap((uint32_t)a.bits,expected))failure="unresolved_saved_form";else if(b.bits!=expected)failure="mapped_form_ID";}
  else failure="unsupported_type";
  if(failure){result.passed=false;if(result.firstFailure==UINT32_MAX){result.firstFailure=i;result.reason=failure;}}
 }
 return result;
}
}
