#pragma once
#include <stdint.h>
#include <string.h>
namespace wide {
inline void buildStewieSavedRefBridge(unsigned char (&code)[22],uint32_t address,uint32_t callback,uint32_t resume){
    const unsigned char bytes[]={0x51,0x8B,0xD6,0x8B,0x4C,0x24,0x18,0xB8,0,0,0,0,0xFF,0xD0,0x8B,0xF0,0x59,0xE9,0,0,0,0};
    memcpy(code,bytes,sizeof(bytes));memcpy(code+8,&callback,4);
    uint32_t delta=resume-(address+sizeof(bytes));memcpy(code+18,&delta,4);
}
// Native FOS table entries are DWORD FormIDs. Compact three-byte references
// retain their ordinal encoding; only FD/FE opaque table entries need WIDM.
template<class Map,class Legacy>
uint32_t remapNativeSavedRef(uint32_t saved,bool manifestValid,const Map& identities,Legacy legacy,bool& intercepted){
    intercepted=false;
    uint32_t owner=saved>>24;
    if(!manifestValid || (owner!=253 && owner!=254))return legacy(saved);
    intercepted=true;
    auto entry=identities.find(saved);
    return entry==identities.end()?0:entry->second;
}
}
