#pragma once
#include <stdint.h>
struct SupHudProbeCase {uint32_t slot;const char* operation;const char* tail;double expected;};
inline constexpr SupHudProbeCase supHudProbeCases[]={
    {997,"HudBarCreate"," 100 100 0",1},{998,"HudBarCreate"," 300 100 0",1},
    {997,"HudBarExists","",1},{998,"HudBarExists","",1},
    {997,"HudBarSetBarTrait"," 2 0.25",1},{998,"HudBarSetBarTrait"," 2 0.5",1},
    {997,"HudBarGetBarTrait"," 2",0.25},{998,"HudBarGetBarTrait"," 2",0.5},
    {997,"HudBarGetBarTrait"," 2 1001",0.5},{998,"HudBarGetBarTrait"," 2 1000",0.25},
    {997,"HudBarSetBarTrait"," 2 0.75",1},
    {997,"HudBarGetBarTrait"," 2",0.75},{998,"HudBarGetBarTrait"," 2",0.5},
    {997,"HudBarSetVisible"," 0 0",1},{998,"HudBarSetVisible"," 0 1",1},
    {997,"HudBarGetVisible"," 0",0},{998,"HudBarGetVisible"," 0",1},
    {997,"HudBarGetVisible"," 0 1001",1},{998,"HudBarGetVisible"," 0 1000",0},
    {997,"HudBarGetVisible"," 0 100",0},{998,"HudBarGetVisible"," 0 100",1},
    {997,"HudBarDestroy","",1},{997,"HudBarExists","",0},{998,"HudBarExists","",1},
    {997,"HudBarGetBarTrait"," 2",-1},{998,"HudBarGetBarTrait"," 2",0.5},
    {997,"HudBarGetVisible"," 0",-1},{998,"HudBarGetVisible"," 0",1},
    {998,"HudBarDestroy","",1},{998,"HudBarExists","",0}
};
