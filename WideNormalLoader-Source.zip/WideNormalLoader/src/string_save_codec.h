#pragma once
#include "save_identity_codec.h"
namespace wide {
constexpr uint32_t stringSaveRecord=0x57535456,stringSaveVersion=1; // WSTV
struct StringSaveOwner {uint32_t id;uint16_t slot,length;uint32_t textCrc;};
struct StringSave {uint32_t plugins=0;std::vector<StringSaveOwner> owners;};
inline bool validateStringSave(const StringSave& value){
    if(!value.plugins || value.plugins>1024 || value.owners.size()>1048576)return false;
    std::unordered_set<uint32_t> ids;
    for(auto entry:value.owners)if(!entry.id || entry.slot>=value.plugins || entry.length>=0x4000 || !ids.insert(entry.id).second)return false;
    return true;
}
inline bool encodeStringSave(const StringSave& value,std::vector<unsigned char>& output){
    if(!validateStringSave(value))return false;
    std::vector<unsigned char> bytes;identityPut(bytes,1,4);identityPut(bytes,value.plugins,4);identityPut(bytes,(uint32_t)value.owners.size(),4);
    for(auto entry:value.owners){identityPut(bytes,entry.id,4);identityPut(bytes,entry.slot,2);identityPut(bytes,entry.length,2);identityPut(bytes,entry.textCrc,4);}
    identityPut(bytes,identityCrc(bytes.data(),bytes.size()),4);output=std::move(bytes);return true;
}
inline bool decodeStringSave(const unsigned char* bytes,size_t length,uint32_t plugins,StringSave& output){
    if(!bytes || length<16 || length>maxIdentityBytes)return false;
    auto read=[&](size_t pos,unsigned width){uint32_t n=0;for(unsigned i=0;i<width;++i)n|=uint32_t(bytes[pos+i])<<(8*i);return n;};
    if(read(0,4)!=1 || read(4,4)!=plugins || read(length-4,4)!=identityCrc(bytes,length-4))return false;
    uint32_t count=read(8,4);if(count>1048576 || count!=(length-16)/12 || length!=16+size_t(count)*12)return false;
    StringSave value;value.plugins=plugins;value.owners.reserve(count);
    for(size_t p=12;p<length-4;p+=12)value.owners.push_back({read(p,4),(uint16_t)read(p+4,2),(uint16_t)read(p+6,2),read(p+8,4)});
    if(!validateStringSave(value))return false;output=std::move(value);return true;
}
}
