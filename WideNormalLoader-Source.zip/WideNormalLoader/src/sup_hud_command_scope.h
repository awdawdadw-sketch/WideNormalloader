#pragma once
#include <cstdint>
#include <cassert>

namespace wide {
class SupHudBridge;
// Per-invocation ownership, independent of SUP's packed stack locals. A native
// callback does not change this scope; a nested script command gets a new one.
class SupHudCommandScope {
    friend class SupHudBridge;
    inline static thread_local SupHudCommandScope* active=nullptr;
    SupHudCommandScope* previous;
    uint32_t token;
    explicit SupHudCommandScope(uint32_t validatedToken)
        : previous(active),token(validatedToken) { active=this; }
    ~SupHudCommandScope() {
        assert(active==this);active=previous;
    }
    SupHudCommandScope(const SupHudCommandScope&)=delete;
    SupHudCommandScope& operator=(const SupHudCommandScope&)=delete;
public:
    static bool currentToken(uint32_t& value) {
        if (!active) return false;
        value=active->token;return true;
    }
};
} // namespace wide
