#pragma once
#include <stdint.h>
struct WideSerialization {
    using Callback=void(*)(void*);
    uint32_t version;
    void(*setSave)(uint32_t,Callback);void(*setLoad)(uint32_t,Callback);void(*setNewGame)(uint32_t,Callback);
    bool(*writeRecord)(uint32_t,uint32_t,const void*,uint32_t);
    bool(*openRecord)(uint32_t,uint32_t);bool(*writeData)(const void*,uint32_t);
    bool(*nextRecord)(uint32_t*,uint32_t*,uint32_t*);uint32_t(*readData)(void*,uint32_t);
    bool(*resolveRef)(uint32_t,uint32_t*);
    void(*setPreLoad)(uint32_t,Callback);const char*(*savePath)();
};
