#pragma once
#include "array_identity_codec.h"
#include "array_core_payload.h"
namespace wide {
struct ArrayLoadEntry {uint32_t id;uint8_t savedOwner,currentOwner;std::vector<uint8_t> savedRefs,currentRefs;};
struct ArrayRestoreCatalog {
    ArrayIdentitySave owners;
    std::vector<std::string> savedPlugins;
    std::vector<uint32_t> slots;
    uint32_t movedCreators=0,movedRefs=0;
    uint32_t nativeOwnersChanged=0,nativeRefsChanged=0;
    std::vector<ArrayLoadEntry> stream;
    std::unordered_map<uint32_t,ArrayContent> contents;
    uint32_t generatedRows=0;
};
inline bool buildArrayRestoreCatalog(const unsigned char* bytes,size_t size,const std::vector<std::string>& current,ArrayRestoreCatalog& output,bool allowOpaqueReorder=false,bool allowBoundary=false){
    if(!bytes || size<20 || size>maxIdentityBytes || memcmp(bytes,"NVSE",4))return false;
    auto u32=[&](size_t p){return uint32_t(bytes[p])|uint32_t(bytes[p+1])<<8|uint32_t(bytes[p+2])<<16|uint32_t(bytes[p+3])<<24;};
    if(u32(4)!=1 || u32(16)>65536)return false;
    size_t pos=20;bool manifestSeen=false,ownersSeen=false,start=false,active=false,closed=false;
    SaveIdentities manifest;uint32_t manifestCrc=0,manifestOpcode=0,ownerOpcode=0;const unsigned char* ownerBytes=nullptr;size_t ownerLength=0;
    std::unordered_map<uint32_t,ArrayCoreIdentity> core;ArrayRestoreCatalog result;
    for(uint32_t b=0;b<u32(16);++b){
        if(size-pos<12)return false;auto opcode=u32(pos),records=u32(pos+4),length=u32(pos+8);pos+=12;
        if(length>size-pos || records>length/12)return false;auto end=pos+length;
        for(uint32_t r=0;r<records;++r){
            if(end-pos<12)return false;auto tag=u32(pos),version=u32(pos+4),n=u32(pos+8);pos+=12;if(n>end-pos)return false;
            if(tag==saveIdentityRecord){
                if(manifestSeen || version!=saveIdentityVersion || !decodeIdentities(bytes+pos,n,manifest) || manifest.plugins.size()>current.size())return false;
                if(!allowOpaqueReorder)for(size_t j=0;j<manifest.plugins.size();++j)if(normalizedPlugin(manifest.plugins[j])!=normalizedPlugin(current[j]))return false;
                manifestSeen=true;manifestOpcode=opcode;manifestCrc=identityCrc(bytes+pos,n-4);
            }
            if(tag==arrayIdentityRecord){if(ownersSeen || version!=arrayIdentityVersion)return false;ownersSeen=true;ownerOpcode=opcode;ownerBytes=bytes+pos;ownerLength=n;}
            if(opcode==0x1400){
                if(tag==0x41525653){if(start || version!=2 || n)return false;start=active=true;}
                else if(tag==0x41525645){if(!active || version!=2 || n)return false;active=false;closed=true;}
                else if(tag==0x41525652){
                    ArrayContent a;std::vector<uint8_t> refs;
                    if(!active || version!=2 || !decodeArrayCorePayload(bytes+pos,n,a,refs) || !core.emplace(a.id,ArrayCoreIdentity{identityCrc(bytes+pos,n),a.owner,std::move(refs),version}).second)return false;
                    result.contents.emplace(a.id,std::move(a));
                    const auto& original=core.at(a.id);
                    result.stream.push_back({a.id,original.owner,original.owner,original.refs,original.refs});
                }else if(active)return false;
            }
            pos+=n;
        }if(pos!=end)return false;
    }
    if(pos!=size || !manifestSeen || !ownersSeen || manifestOpcode!=ownerOpcode || !start || !closed || active || !decodeArrayIdentities(ownerBytes,ownerLength,(uint32_t)manifest.plugins.size(),manifestCrc,result.owners) || !matchArrayCoreIdentities(result.owners,core))return false;
    uint32_t missing=0;
    if(!identitySlotMap(manifest.plugins,current,result.slots,missing) || missing)return false;
    // This first reorder reader preserves every native owner/reference byte.
    // Legacy slots stay fixed; opaque slots may permute within their class.
    if(!allowBoundary)for(uint32_t j=0;j<result.slots.size();++j)
        if(j<253 ? result.slots[j]!=j : result.slots[j]<253)return false;
    if(allowOpaqueReorder || allowBoundary){
        ArrayIdentitySave mapped;
        if(!remapArrayIdentities(result.owners,core,result.slots,(uint32_t)current.size(),manifestCrc,mapped))return false;
        for(size_t j=0;j<mapped.arrays.size();++j){
            const auto& old=result.owners.arrays[j];const auto& now=mapped.arrays[j];
            if(!allowBoundary && (old.nativeOwner!=now.nativeOwner || old.refs.size()!=now.refs.size()))return false;
            if(old.creator!=arrayGeneratedContext && old.creator!=0 && now.creator==0)return false;
            if(old.creator!=now.creator)++result.movedCreators;
            for(size_t k=0;k<old.refs.size();++k)
                {if(!allowBoundary && (old.refs[k].nativeByte!=now.refs[k].nativeByte || old.refs[k].count!=now.refs[k].count))return false;
                if(old.refs[k].slot!=arrayGeneratedContext && result.slots[old.refs[k].slot]!=old.refs[k].slot)result.movedRefs+=old.refs[k].count;}
        }
        if(allowBoundary){
            std::unordered_map<uint32_t,const ArraySavedIdentity*> originals,targets;
            for(const auto& a:result.owners.arrays)originals.emplace(a.id,&a);
            for(const auto& a:mapped.arrays)targets.emplace(a.id,&a);
            for(auto& entry:result.stream){
                const auto& old=*originals.at(entry.id);const auto& now=*targets.at(entry.id);
                entry.currentOwner=now.nativeOwner;
                if(entry.currentOwner!=entry.savedOwner)++result.nativeOwnersChanged;
                // Native ref bytes are an unordered multiset. Distribute
                // mapped full-slot groups over occurrences of the old byte;
                // no serialized holder address or positional identity exists.
                std::vector<uint8_t> queues[256];uint32_t used[256]{};
                for(const auto& ref:old.refs){auto slot=ref.slot==arrayGeneratedContext?arrayGeneratedContext:result.slots[ref.slot];
                    uint8_t byte=slot==arrayGeneratedContext?255:slot<253?(uint8_t)slot:253;
                    queues[ref.nativeByte].insert(queues[ref.nativeByte].end(),ref.count,byte);}
                for(size_t k=0;k<entry.savedRefs.size();++k){auto b=entry.savedRefs[k];if(used[b]>=queues[b].size())return false;entry.currentRefs[k]=queues[b][used[b]++];if(entry.currentRefs[k]!=b)++result.nativeRefsChanged;}
                result.contents.at(entry.id).owner=now.nativeOwner;
            }
        }
        result.owners=std::move(mapped);
    }
    result.savedPlugins=manifest.plugins;
    for(const auto& a:result.owners.arrays)if(a.creator==arrayGeneratedContext)++result.generatedRows;
    output=std::move(result);return true;
}
}
