#pragma once
#include <string>
#include <vector>
#include <stdint.h>
namespace wide {
struct CombinedProbeCase {const char* area;uint32_t owner;std::string expression;double expected;bool compare=true;};
// Owner selectors: 0/1 are the two fixture files; 2 is legacy slot 252.
// Tests use reserved names and the fixture quest, never a real mod's variables.
inline std::vector<CombinedProbeCase> combinedProbeCases(){
    const std::string q=" (GetFormFromMod \"NativeProbe_0689.esp\" \"000D10\")";
    return {
        {"variables",0,"AddScriptVariable \"WideBatchVarA\""+q,1},
        {"variables",1,"AddScriptVariable \"WideBatchVarB\""+q,1},
        {"variables",0,"SetVariable \"WideBatchVarA\" 123.25"+q,0,false},
        {"variables",1,"SetVariable \"WideBatchVarB\" 456.5"+q,0,false},
        {"variables",0,"GetVariable \"WideBatchVarA\""+q,123.25},
        {"variables",1,"GetVariable \"WideBatchVarB\""+q,456.5},
        {"variables",0,"HasVariableAdded \"WideBatchVarA\""+q,1},
        {"variables",1,"HasVariableAdded \"WideBatchVarB\""+q,1},
        {"variables",0,"RemoveAllAddedVariables"+q,0,false},
        {"variables",0,"HasVariableAdded \"WideBatchVarA\""+q,0},
        {"variables",1,"HasVariableAdded \"WideBatchVarB\""+q,1},
        {"variables",1,"RemoveScriptVariable \"WideBatchVarB\""+q,0,false},
        {"variables",0,"RemoveScriptVariable \"WideBatchVarA\""+q,0,false},
        {"variables",1,"HasVariableAdded \"WideBatchVarB\""+q,0},
        {"timers",0,"AuxTimerStart \"*WideBatchTimer\" 111 39",1},
        {"timers",1,"AuxTimerStart \"*WideBatchTimer\" 222 39",1},
        {"timers",0,"AuxTimerTimeToCountdown \"*WideBatchTimer\"",111},
        {"timers",1,"AuxTimerTimeToCountdown \"*WideBatchTimer\"",222},
        {"timers",0,"AuxTimerPaused \"*WideBatchTimer\"",1},
        {"timers",1,"AuxTimerTimeLeft \"*WideBatchTimer\"",222},
        {"timers",0,"AuxTimerStart \"*WideBatchTimer\" 333 39",1},
        {"timers",0,"AuxTimerTimeLeft \"*WideBatchTimer\"",333},
        {"timers",1,"AuxTimerTimeLeft \"*WideBatchTimer\"",222},
        {"timers",2,"AuxTimerStart \"*WideBatchTimer\" 777 39",1},
        {"timers",2,"AuxTimerTimeLeft \"*WideBatchTimer\"",777},
        {"timers",0,"AuxTimerTimeLeft \"*WideBatchTimer\"",333},
        {"timers",0,"AuxTimerStart \"*_WideBatchTimerPublic\" 888 39",1},
        {"timers",1,"AuxTimerTimeLeft \"*_WideBatchTimerPublic\"",888},
        {"timers",2,"AuxTimerTimeLeft \"*_WideBatchTimerPublic\"",888},
        {"timers",0,"AuxTimerStop \"*WideBatchTimer\"",0,false},
        {"timers",1,"AuxTimerStop \"*WideBatchTimer\"",0,false},
        {"timers",2,"AuxTimerStop \"*WideBatchTimer\"",0,false},
        {"timers",0,"AuxTimerStop \"*_WideBatchTimerPublic\"",0,false}
    };
}
}
