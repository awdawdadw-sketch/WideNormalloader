#pragma once
#include "sup_owner_namespace.h"
#include "sup_hud_command_scope.h"
#include <cstring>
#include <mutex>

// ABI of the pinned installed SUP DLL, corroborated in sup-hud-native-abi.json.
// This code forwards to supplied original functions; it installs no hooks.
// C++ objects and synchronization remain inside our DLL, never cross into SUP.
namespace wide {
struct SupHudExports {
    bool (__cdecl* addNewElement)(char*,float,float,int32_t,int32_t) = nullptr;
    int32_t (__cdecl* destroy)(char*,int32_t) = nullptr;
    int32_t (__cdecl* getKey)(char*,int32_t) = nullptr;
    float (__cdecl* getVisible)(char*,int32_t,int32_t) = nullptr;
    int32_t (__cdecl* setAutoPos)(char*,int32_t,int32_t) = nullptr;
    int32_t (__cdecl* setBarValue)(int32_t,float) = nullptr;
    int32_t (__cdecl* setIndent)(char*,int32_t,float,int32_t) = nullptr;
    int32_t (__cdecl* setMeterTrait)(char*,int32_t,float,int32_t) = nullptr;
    int32_t (__cdecl* setPos)(char*,int32_t,float,float,int32_t) = nullptr;
    int32_t (__cdecl* setSize)(char*,int32_t,float,float,int32_t) = nullptr;
    int32_t (__cdecl* setSizeAlt)(char*,int32_t,float,float,int32_t) = nullptr;
    int32_t (__cdecl* setTextString)(char*,int32_t,char*,int32_t) = nullptr;
    int32_t (__cdecl* setTexture)(char*,int32_t,char*,int32_t,int32_t) = nullptr;
    int32_t (__cdecl* showBar)(char*,int32_t,int32_t) = nullptr;
    float (__cdecl* setForceHide)(char*,int32_t,int32_t) = nullptr;
};

enum class SupCallOrigin { NativeApi, ScriptApi, InternalToken };

class SupHudBridge {
    SupOwnerNamespace owners;
    SupHudExports originals;
    // A callback may reenter from a different origin. A recursive lock protects
    // namespace allocation without a depth flag that misclassifies callbacks.
    std::recursive_mutex mutex;
    bool translate(SupCallOrigin origin, uint32_t raw, uint32_t& token) {
        if (origin == SupCallOrigin::InternalToken) {
            SupOwnerKey key{};
            if (!owners.identity(raw,key)) return false;
            token=raw; return true;
        }
        try {
            if (origin == SupCallOrigin::NativeApi) return owners.nativeOwner(raw,token);
            if (origin == SupCallOrigin::ScriptApi) return owners.scriptOwner(raw,token);
            return false;
        } catch (...) { return false; } // No allocation exception through C ABI.
    }
    template<class R, class F, class... A>
    bool forward(SupCallOrigin origin,uint32_t raw,R& result,F target,A... args) {
        std::lock_guard<std::recursive_mutex> guard(mutex);
        if (!target) return false;
        uint32_t token=0;
        if (!translate(origin,raw,token)) return false;
        // Preserve all owner bits in SUP's signed 32-bit argument representation.
        int32_t signedToken; std::memcpy(&signedToken,&token,4);
        result=target(args...,signedToken); return true;
    }
public:
    explicit SupHudBridge(SupHudExports endpoints,uint32_t capacity=1024-253)
        : owners(capacity),originals(endpoints) {}
    bool resolve(SupCallOrigin origin,uint32_t raw,uint32_t& token) {
        std::lock_guard<std::recursive_mutex> guard(mutex);
        return translate(origin,raw,token);
    }
    bool identity(uint32_t token,SupOwnerKey& key) {
        std::lock_guard<std::recursive_mutex> guard(mutex);
        return owners.identity(token,key);
    }
    // The runtime wrapper must resolve the script's last overriding TESFile
    // before calling this. Keep its common owner separate from native IDs.
    // No scope is created when ownership is invalid; the original is not run.
    template<class R,class F,class... A>
    bool scriptCommand(uint32_t commonOwner,R& result,F target,A... args) {
        if (!target) return false;
        uint32_t token=0;
        if (!resolve(SupCallOrigin::ScriptApi,commonOwner,token)) return false;
        SupHudCommandScope scope(token);
        result=target(args...);return true;
    }
    // GetAllBars(1) reports an integer converted to a script double. Return the
    // original public value, never the pooled internal token. Keep native raw
    // IDs signed as in installed MOVD/CVTDQ2PD, and expose kind to the adapter.
    bool reportedOwner(uint32_t token,int32_t& value,SupOwnerKind& kind) {
        std::lock_guard<std::recursive_mutex> guard(mutex);
        SupOwnerKey identity{};
        if (!owners.identity(token,identity)) return false;
        uint32_t raw=identity.value;
        if (identity.kind==SupOwnerKind::ExtendedPlugin) raw+=256;
        if (identity.kind==SupOwnerKind::Console) raw=255;
        int32_t signedRaw; std::memcpy(&signedRaw,&raw,4);
        value=signedRaw;kind=identity.kind;return true;
    }
    // Installed GetBarTrait selects its third argument when argument count>2.
    // The explicit value belongs to the script API, not our internal pool.
    bool barTraitOwner(uint32_t defaultToken,uint8_t argumentCount,uint32_t explicitOwner,uint32_t& token) {
        std::lock_guard<std::recursive_mutex> guard(mutex);
        return argumentCount>2 ? translate(SupCallOrigin::ScriptApi,explicitOwner,token)
                               : translate(SupCallOrigin::InternalToken,defaultToken,token);
    }
    // Installed GetVisible initializes explicit owner to 100 and uses 100 as
    // its default sentinel, even when explicitly supplied. Preserve that rule.
    bool visibleOwner(uint32_t defaultToken,uint32_t explicitOwner,uint32_t& token) {
        std::lock_guard<std::recursive_mutex> guard(mutex);
        return explicitOwner==100 ? translate(SupCallOrigin::InternalToken,defaultToken,token)
                                  : translate(SupCallOrigin::ScriptApi,explicitOwner,token);
    }
    bool addNewElement(SupCallOrigin o,uint32_t owner,bool& r,char* name,float x,float y,int32_t meter) {
        return forward(o,owner,r,originals.addNewElement,name,x,y,meter);
    }
    bool destroy(SupCallOrigin o,uint32_t owner,int32_t& r,char* name) {
        return forward(o,owner,r,originals.destroy,name);
    }
    bool getKey(SupCallOrigin o,uint32_t owner,int32_t& r,char* name) {
        return forward(o,owner,r,originals.getKey,name);
    }
    bool getVisible(SupCallOrigin o,uint32_t owner,float& r,char* name,int32_t element) {
        return forward(o,owner,r,originals.getVisible,name,element);
    }
    bool setAutoPos(SupCallOrigin o,uint32_t owner,int32_t& r,char* name,int32_t value) {
        return forward(o,owner,r,originals.setAutoPos,name,value);
    }
    bool setIndent(SupCallOrigin o,uint32_t owner,int32_t& r,char* name,int32_t element,float value) {
        return forward(o,owner,r,originals.setIndent,name,element,value);
    }
    bool setMeterTrait(SupCallOrigin o,uint32_t owner,int32_t& r,char* name,int32_t trait,float value) {
        return forward(o,owner,r,originals.setMeterTrait,name,trait,value);
    }
    bool setPos(SupCallOrigin o,uint32_t owner,int32_t& r,char* name,int32_t element,float x,float y) {
        return forward(o,owner,r,originals.setPos,name,element,x,y);
    }
    bool setSize(SupCallOrigin o,uint32_t owner,int32_t& r,char* name,int32_t element,float w,float h) {
        return forward(o,owner,r,originals.setSize,name,element,w,h);
    }
    bool setSizeAlt(SupCallOrigin o,uint32_t owner,int32_t& r,char* name,int32_t element,float w,float h) {
        return forward(o,owner,r,originals.setSizeAlt,name,element,w,h);
    }
    bool setTextString(SupCallOrigin o,uint32_t owner,int32_t& r,char* name,int32_t element,char* text) {
        return forward(o,owner,r,originals.setTextString,name,element,text);
    }
    bool setTexture(SupCallOrigin o,uint32_t owner,int32_t& r,char* name,int32_t element,char* path,int32_t autoSize) {
        return forward(o,owner,r,originals.setTexture,name,element,path,autoSize);
    }
    bool showBar(SupCallOrigin o,uint32_t owner,int32_t& r,char* name,int32_t value) {
        return forward(o,owner,r,originals.showBar,name,value);
    }
    bool setForceHide(SupCallOrigin o,uint32_t owner,float& r,char* name,int32_t value) {
        return forward(o,owner,r,originals.setForceHide,name,value);
    }
    // This export uses a vector key, not a plugin owner. Do not translate it.
    bool setBarValue(int32_t& r,int32_t key,float value) {
        std::lock_guard<std::recursive_mutex> guard(mutex);
        if (!originals.setBarValue) return false;
        r=originals.setBarValue(key,value); return true;
    }
};
} // namespace wide
