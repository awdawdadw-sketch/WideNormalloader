#pragma once
#include <stdint.h>
#include <unordered_map>
namespace wide {
struct TrackedStringOwner {uint32_t slot;uint8_t nativeByte;};
class StringOwnerTracker {
    std::unordered_map<uint32_t,TrackedStringOwner> owners;
public:
    void clear(){owners.clear();}
    void allocated(uint32_t id){owners.erase(id);} // Native string IDs are reused.
    void created(uint32_t id,uint32_t slot,uint8_t nativeByte){if(id)owners[id]={slot,nativeByte};}
    void assigned(uint32_t id,bool existed,bool moved,uint32_t slot,uint8_t nativeByte){
        // Ordinary Set(text) preserves the original owner. Moving a command
        // result explicitly changes it to the assignment's script owner.
        if(!existed || moved)created(id,slot,nativeByte);
    }
    bool get(uint32_t id,uint8_t nativeByte,TrackedStringOwner& owner)const{
        auto it=owners.find(id);if(it==owners.end() || it->second.nativeByte!=nativeByte)return false;
        owner=it->second;return true;
    }
};
}
