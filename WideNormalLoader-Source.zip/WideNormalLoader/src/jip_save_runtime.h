#pragma once
#include "jip_build_profile.h"
#include <windows.h>
#include <algorithm>
#include "module_sha256.h"
#include "jip_save_codec.h"
namespace wide {
struct JipNativeMap {uint32_t buckets=0,capacity=8,count=0;};
struct JipNativeVector {uint32_t data=0,count=0,capacity=2;};
struct JipNativeValue {uint8_t type,pad[3];uint16_t allocation,length;uint64_t bits;};
static_assert(sizeof(JipNativeMap)==12 && sizeof(JipNativeVector)==12 && sizeof(JipNativeValue)==16,"Installed x86 JIP layouts");
// All allocations, key copies, string assignments, and destruction stay in JIP.
// No standard-library container crosses the DLL boundary.
class JipSaveRuntime {
    uint32_t base=0;
    using Insert=bool(__thiscall*)(void*,uint32_t,void**);
    using Assign=void(__thiscall*)(void*,const char*);
    using Alloc=void*(__fastcall*)(uint32_t);
    using Free=void(__fastcall*)(void*,uint32_t);
    using Destroy=void*(__thiscall*)(void*,uint32_t);
    struct Lock {
        uint32_t base;
        explicit Lock(uint32_t b):base(b){
            auto enter=(void(__thiscall*)(void*))(base+jipRva(0x5540));
            enter((void*)(base+jipRva(0x764F0)));enter((void*)(base+jipRva(0x76390)));
        }
        ~Lock(){InterlockedExchange((LONG*)(base+jipRva(0x76390)),0);InterlockedExchange((LONG*)(base+jipRva(0x764F0)),0);}
    };
    template<class T> static T read(uint32_t address){
        T result{};SIZE_T got=0;if(!address || !ReadProcessMemory(GetCurrentProcess(),(void*)address,&result,sizeof(result),&got) || got!=sizeof(result))throw "unreadable_JIP_object";return result;
    }
    static std::string text(uint32_t address,uint32_t length=UINT32_MAX){
        if(length!=UINT32_MAX){if(length>0x1FFF)throw "oversize_JIP_string";std::string out(length,'\0');SIZE_T got=0;
            if(length && (!address || !ReadProcessMemory(GetCurrentProcess(),(void*)address,&out[0],length,&got) || got!=length))throw "unreadable_JIP_string";
            if(out.find('\0')!=std::string::npos)throw "embedded_JIP_string_null";return out;}
        std::string out;for(uint32_t i=0;i<=0x1FFF;++i){char c=read<char>(address+i);if(!c)return out;out.push_back(c);}throw "unterminated_JIP_name";
    }
    template<class Visitor> static void walk(JipNativeMap map,bool stringKey,Visitor visit){
        if(!map.capacity || (map.capacity&(map.capacity-1)) || map.capacity>1048576 || map.count>1048576 || (map.count && !map.buckets))throw "invalid_JIP_map_header";
        if(!map.buckets){if(map.count)throw "missing_JIP_buckets";return;}
        std::unordered_set<uint32_t> entries;
        for(uint32_t i=0;i<map.capacity;++i){uint32_t entry=read<uint32_t>(map.buckets+i*4);
            while(entry){if(entries.size()>=map.count || !entries.insert(entry).second)throw "invalid_JIP_map_chain";
                uint32_t next=read<uint32_t>(entry),key=read<uint32_t>(entry+(stringKey?8:4));visit(key,entry+(stringKey?12:8));entry=next;}
        }
        if(entries.size()!=map.count)throw "JIP_map_count_mismatch";
    }
    static uint16_t slot(uint32_t owner,uint32_t count){
        if(owner==255)return jipPublicSlot;
        uint32_t s=owner<253?owner:owner>=256?owner-3:UINT32_MAX;
        if(s>=count)throw "invalid_JIP_full_owner";return (uint16_t)s;
    }
    static uint32_t owner(uint16_t s){return s==jipPublicSlot?255:s<253?s:s+3;}
    static JipSavedValue value(uint32_t address){
        auto raw=read<JipNativeValue>(address);JipSavedValue out;out.type=raw.type;
        if(raw.type==1)out.bits=raw.bits;
        else if(raw.type==2)out.bits=(uint32_t)raw.bits;
        else if(raw.type==4){if(raw.length && (!raw.allocation || raw.length>=raw.allocation))throw "invalid_JIP_string_allocation";out.text=text((uint32_t)raw.bits,raw.length);}
        else if(raw.type)throw "invalid_JIP_value_type";
        return out;
    }
    JipSave snapshotUnlocked(uint32_t count){
        JipSave out;
        walk(read<JipNativeMap>(base+jipRva(0x6A34C)),false,[&](uint32_t key,uint32_t address){
            JipSavedOwner o;o.slot=slot(key,count);
            walk(read<JipNativeMap>(address),false,[&](uint32_t ref,uint32_t vars){
                JipSavedSubject subject;subject.ref=ref;
                walk(read<JipNativeMap>(vars),true,[&](uint32_t name,uint32_t vector){
                    JipSavedAux variable;variable.name=text(name);auto v=read<JipNativeVector>(vector);
                    if(v.count>1048576 || v.count>v.capacity || (v.count && !v.data))throw "invalid_JIP_vector";
                    for(uint32_t i=0;i<v.count;++i)variable.values.push_back(value(v.data+i*16));
                    subject.variables.push_back(std::move(variable));});o.subjects.push_back(std::move(subject));});out.aux.push_back(std::move(o));});
        walk(read<JipNativeMap>(base+jipRva(0x6A304)),false,[&](uint32_t key,uint32_t address){
            JipSavedOwner o;o.slot=slot(key,count);
            walk(read<JipNativeMap>(address),true,[&](uint32_t name,uint32_t refs){
                JipSavedMap map;map.name=text(name);walk(read<JipNativeMap>(refs),false,[&](uint32_t ref,uint32_t val){map.values.push_back({ref,value(val)});});o.maps.push_back(std::move(map));});out.refs.push_back(std::move(o));});
        if(!validateJipSave(out,count))throw "invalid_JIP_snapshot";return out;
    }
    void destroy(JipNativeMap& map,bool refs){
        // Root entry destructor frees nested maps/strings/vectors, but not self.
        auto destruct=(Destroy)(base+jipRva(refs?0x50D30:0x50C10));auto free=(Free)(base+jipRva(0x3D80));
        if(map.buckets){auto* buckets=(uint32_t*)map.buckets;for(uint32_t i=0;i<map.capacity;++i){uint32_t p=buckets[i];while(p){uint32_t next=*(uint32_t*)p;destruct((void*)p,0);free((void*)p,32);p=next;}}free((void*)map.buckets,map.capacity*4);}
        map=JipNativeMap{};
    }
    void* insert(JipNativeMap& map,uint32_t key,bool stringKey){
        void* out=nullptr;bool added=((Insert)(base+jipRva(stringKey?0x50A10:0x50950)))(&map,key,&out);
        if(!added || !out)throw "JIP_duplicate_or_hash_collision";return out;
    }
    JipNativeMap& child(JipNativeMap& map,uint32_t key,bool stringKey,uint32_t capacity){
        auto* out=(JipNativeMap*)insert(map,key,stringKey);*out=JipNativeMap{};out->capacity=capacity;return *out;
    }
    void assign(JipNativeValue& out,const JipSavedValue& in){
        memset(&out,0,sizeof(out));out.type=in.type;
        if(in.type==4)((Assign)(base+jipRva(0x7810)))(&out,in.text.c_str());else out.bits=in.bits;
    }
    void build(const JipSave& in,JipNativeMap& aux,JipNativeMap& refs){
        for(const auto& o:in.aux){auto& subjects=child(aux,owner(o.slot),false,8);
            for(const auto& s:o.subjects){auto& vars=child(subjects,s.ref,false,4);
                for(const auto& v:s.variables){auto* vector=(JipNativeVector*)insert(vars,(uint32_t)v.name.c_str(),true);*vector=JipNativeVector{};
                    if(!v.values.empty()){vector->capacity=(uint32_t)std::max(size_t(2),v.values.size());vector->data=(uint32_t)((Alloc)(base+jipRva(0x3C80)))(vector->capacity*16);if(!vector->data)throw "JIP_vector_allocation_failed";
                        memset((void*)vector->data,0,vector->capacity*16);
                        for(const auto& val:v.values){assign(((JipNativeValue*)vector->data)[vector->count],val);++vector->count;}}
                }
            }
        }
        for(const auto& o:in.refs){auto& vars=child(refs,owner(o.slot),false,4);
            for(const auto& map:o.maps){auto& values=child(vars,(uint32_t)map.name.c_str(),true,4);
                for(const auto& v:map.values)assign(*(JipNativeValue*)insert(values,v.ref,false),v.value);}
        }
    }
public:
#ifdef WIDE_JIP_SAVE_TEST
    void bindSynthetic(uint32_t module){base=module;}
#endif
    bool bind(HMODULE module){
        if(!moduleHasImageRange(module,jipRva(0x77224)))return false;
        base=(uint32_t)module;return true;
    }
    bool snapshot(uint32_t count,JipSave& output){if(!base)return false;try{Lock guard(base);output=snapshotUnlocked(count);return true;}catch(...){return false;}}
    bool replace(const JipSave& in,uint32_t count){
        if(!base || !validateJipSave(in,count))return false;
        JipNativeMap aux,refs;
        try{
            Lock guard(base);
            // Validate old roots before committing or destroying any native data.
            (void)snapshotUnlocked(count);build(in,aux,refs);
            auto* oldAux=(JipNativeMap*)(base+jipRva(0x6A34C));auto* oldRefs=(JipNativeMap*)(base+jipRva(0x6A304));
            std::swap(*oldAux,aux);std::swap(*oldRefs,refs);
            // RefMap iteration retains table/bucket/entry pointers across calls.
            memset((void*)(base+jipRva(0x77218)),0,12);
            // JIP conditionally clears/reloads permanent maps on later loads.
            *(uint8_t*)(base+jipRva(0x7637A))|=3; // kChangedFlag_AuxVars | RefMaps
            destroy(aux,false);destroy(refs,true);return true;
        }catch(...){
            // Staging roots are not visible to commands until both are complete.
            if(aux.buckets || refs.buckets){Lock guard(base);destroy(aux,false);destroy(refs,true);}return false;
        }
    }
};
}
