#pragma once
#include "jip_build_profile.h"
#include <unordered_map>
#include "plugin_owner_scope.h"
#include "module_sha256.h"
#include "runtime_patch.h"
namespace wide {
class JipLinkOwnersRuntime {
    struct Entry{uint32_t target,owner;uint8_t byte;};
    std::unordered_map<uint32_t,Entry> owners;
    using Resolver=bool(*)(void*,uint32_t&);
    inline static JipLinkOwnersRuntime* active=nullptr;
    Resolver resolver=nullptr;CommandExecute originalCommand=nullptr;
    RuntimePatch commandPatch,methodHook;uint32_t base=0;
    static bool __cdecl command(WIDE_COMMAND_ARGS){uint32_t owner=UINT32_MAX;
        if(active->resolver(scriptObj,owner) && PluginOwnerScope::valid(owner)){PluginOwnerScope scope(owner);return active->originalCommand(WIDE_PASS_ARGS);}
        if(result)*result=0;return true;
    }
    static bool __fastcall changed(void* subject,void*,void* target,uint8_t byte){
        auto& s=*active;uint32_t id=*(uint32_t*)((char*)subject+0xc);
        bool ok=((bool(__thiscall*)(void*,void*,uint8_t))s.methodHook.trampoline)(subject,target,byte);
        if(ok){uint32_t author=PluginOwnerScope::currentOrByte(byte);
            if(target && PluginOwnerScope::valid(author) && (author==byte || (author>=256 && (byte==253 || byte==254))))s.owners[id]={*(uint32_t*)((char*)target+0xc),author,byte};
            else s.owners.erase(id);}
        return ok;
    }
    void rollback(){commandPatch.restore();methodHook.restore();if(methodHook.trampoline){VirtualFree(methodHook.trampoline,0,MEM_RELEASE);methodHook.trampoline=nullptr;}if(active==this)active=nullptr;}
public:
#ifdef WIDE_JIP_LINK_TEST
    void bindSynthetic(uint32_t b,void* original){base=b;methodHook.trampoline=original;active=this;}
#endif
    void clear(){owners.clear();}
    bool owner(uint32_t subject,uint32_t target,uint8_t byte,uint32_t& result)const{
        auto it=owners.find(subject);if(it!=owners.end()){if(it->second.target!=target || it->second.byte!=byte)return false;result=it->second.owner;return true;}
        if(byte<253 || byte==255){result=byte;return true;}return false;
    }
    bool restore(void* subject,void* target,uint32_t author){
        if(active!=this || !subject || !target || !PluginOwnerScope::valid(author))return false;
        uint32_t id=*(uint32_t*)((char*)subject+0xc),targetId=*(uint32_t*)((char*)target+0xc);
        uint8_t byte=author>=256?253:uint8_t(author);bool ok=false;
        // Avoid calling SetLinkedRef a second time for an already restored link:
        // that would replace JIP's saved default with the modified target.
        auto* root=(uint32_t*)(base+jipRva(0x6a31c));
        if(!root[1] || (root[1]&(root[1]-1)) || root[1]>1048576 || root[2]>1048576)return false;
        for(uint32_t i=0;root[0] && i<root[1];++i){uint32_t entry=((uint32_t*)root[0])[i],seen=0;
            while(entry){if(++seen>root[2])return false;
                if(*(uint32_t*)(entry+4)==id){if(*(uint32_t*)(entry+8)!=targetId)return false;
                    *(uint8_t*)(entry+12)=byte;owners[id]={targetId,author,byte};ok=true;break;}
                entry=*(uint32_t*)entry;}if(ok)break;}
        if(!ok){PluginOwnerScope scope(author);ok=changed(subject,nullptr,target,byte);}
        if(ok){
            // Native LoadGameCallback uses this exact UInt32-map operator[] to
            // retain restored links through post-load RestoreLinkedRefs.
            auto insert=(uint32_t*(__thiscall*)(void*,uint32_t))(base+jipRva(0x3610));
            uint32_t* value=insert((void*)(base+jipRva(0x6a2f8)),id);if(!value)return false;*value=targetId;
            *(uint8_t*)(base+jipRva(0x7637a))|=0x08;
        }return ok;
    }
    bool install(HMODULE module,WideCommandTable* table,Resolver resolve){
        if(active || !table || !resolve || !moduleHasImageRange(module,jipRva(0x6a328)))return false;
        base=uint32_t(module);auto* info=table->getName("SetLinkedReference");
        const unsigned char expected[]={0x55,0x8b,0xec,0x83,0xec,0x08};
        const unsigned char tempInsert[]={0x55,0x8b,0xec,0x51,0x53,0x8b,0xd9};
        if(!info || uint32_t(info->execute)!=base+jipRva(0x28dd0) || memcmp((void*)(base+jipRva(0x2530)),expected,6) || memcmp((void*)(base+jipRva(0x3610)),tempInsert,7) || *(uint32_t*)(base+jipRva(0x6a324)))return false;
        resolver=resolve;originalCommand=info->execute;active=this;CommandExecute replace=command;
        if(!methodHook.hook(base+jipRva(0x2530),expected,6,(void*)changed) || !commandPatch.replace(uint32_t(&info->execute),(unsigned char*)&originalCommand,(unsigned char*)&replace,4)){rollback();return false;}return true;
    }
};
}
