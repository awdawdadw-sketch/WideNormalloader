#pragma once
#include <windows.h>
#include <shlobj.h>
#include <tlhelp32.h>
#include <cstdio>
#include <string>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include "module_sha256.h"
#include "jip_build_profile.h"

namespace wide { namespace startup {
inline std::wstring widen(const std::string& s){
    int n=MultiByteToWideChar(CP_ACP,0,s.data(),int(s.size()),nullptr,0);
    std::wstring w(n,L'\0');if(n)MultiByteToWideChar(CP_ACP,0,s.data(),int(s.size()),&w[0],n);return w;
}
inline std::string utf8(const std::wstring& w){
    int n=WideCharToMultiByte(CP_UTF8,0,w.data(),int(w.size()),nullptr,0,nullptr,nullptr);
    std::string s(n,'\0');if(n)WideCharToMultiByte(CP_UTF8,0,w.data(),int(w.size()),&s[0],n,nullptr,nullptr);return s;
}
inline std::wstring parent(const std::wstring& w){auto i=w.find_last_of(L"\\/");return i==w.npos?L"":w.substr(0,i);}
inline std::string lower(std::string s){if(!s.empty())CharLowerBuffA(&s[0],DWORD(s.size()));return s;}
inline bool exists(const std::wstring& p){auto a=GetFileAttributesW(p.c_str());return a!=INVALID_FILE_ATTRIBUTES && !(a&FILE_ATTRIBUTE_DIRECTORY);}
struct File {
    HANDLE h=INVALID_HANDLE_VALUE;
    explicit File(const std::wstring& p){h=CreateFileW(p.c_str(),GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);}
    ~File(){if(h!=INVALID_HANDLE_VALUE)CloseHandle(h);}
    bool read(void* p,DWORD n){DWORD got=0;return ReadFile(h,p,n,&got,nullptr) && got==n;}
    std::wstring resolved(){
        wchar_t p[32768]{};DWORD n=GetFinalPathNameByHandleW(h,p,32768,FILE_NAME_NORMALIZED);
        return n && n<32768?std::wstring(p):L"";
    }
};
inline bool text(const std::wstring& path,std::string& out,std::wstring* resolved=nullptr){
    File f(path);LARGE_INTEGER size{};
    if(f.h==INVALID_HANDLE_VALUE || !GetFileSizeEx(f.h,&size) || size.QuadPart<0 || size.QuadPart>4*1024*1024)return false;
    out.resize(size_t(size.QuadPart));if(!out.empty() && !f.read(&out[0],DWORD(out.size())))return false;
    if(resolved)*resolved=f.resolved();return true;
}
inline std::string trim(std::string s){auto a=s.find_first_not_of(" \t\r\n");if(a==s.npos)return "";auto b=s.find_last_not_of(" \t\r\n");return s.substr(a,b-a+1);}
inline bool safeName(const std::string& s){return !s.empty() && s.size()<260 && s.find_first_of("\\/:*?\"<>|\r\n") == s.npos && s!="." && s!=".." && s.back()!='.' && s.back()!=' ' && std::none_of(s.begin(),s.end(),[](unsigned char c){return c<32;});}
inline bool lines(const std::string& input,std::vector<std::string>& out,bool active=false){
    out.clear();
    std::string s=input;if(s.compare(0,3,"\xef\xbb\xbf")==0)s.erase(0,3);
    bool stars=false;size_t pos=0;
    while(pos<s.size()){
        size_t end=s.find('\n',pos);auto line=trim(s.substr(pos,end==s.npos?s.npos:end-pos));pos=end==s.npos?s.size():end+1;
        if(line.empty() || line[0]=='#')continue;
        if(line[0]=='*')stars=true;out.push_back(line);
        if(out.size()>4096)return false;
    }
    std::vector<std::string> selected;
    for(auto line:out){if(active && stars && line[0]!='*')continue;if(line[0]=='*')line.erase(0,1);if(!safeName(line))return false;selected.push_back(line);}
    out.swap(selected);return true;
}
inline std::vector<std::string> normalized(const std::vector<std::string>& v){std::vector<std::string> r;for(auto& s:v)r.push_back(lower(s));return r;}
struct Difference {std::vector<std::string> missing,wideOnly;bool reordered=false;};
inline Difference compare(const std::vector<std::string>& active,const std::vector<std::string>& order,const std::vector<std::string>& wide){
    Difference d;auto a=normalized(active),o=normalized(order),w=normalized(wide);std::vector<std::string> commonMO,commonWide;
    auto has=[](const auto& list,const auto& s){return std::find(list.begin(),list.end(),s)!=list.end();};
    for(size_t i=0;i<a.size();++i)if(!has(w,a[i]))d.missing.push_back(active[i]);
    for(size_t i=0;i<w.size();++i)if(!has(a,w[i]))d.wideOnly.push_back(wide[i]);
    for(auto& s:o)if(has(a,s)&&has(w,s))commonMO.push_back(s);
    for(auto& s:a)if(has(w,s)&&!has(commonMO,s))commonMO.push_back(s);
    for(auto& s:w)if(has(a,s))commonWide.push_back(s);
    d.reordered=commonMO!=commonWide;return d;
}
inline uint32_t u32(const unsigned char* p){uint32_t v;memcpy(&v,p,4);return v;}
inline uint16_t u16(const unsigned char* p){uint16_t v;memcpy(&v,p,2);return v;}
inline bool header(const unsigned char* h,const std::vector<unsigned char>& body,std::vector<std::string>& masters,std::string& error){
    auto reject=[&](const char* e){error=e;return false;};
    if(memcmp(h,"TES4",4) || (u32(h+8)&0x40000) || u32(h+4)!=body.size())return reject("unsupported or malformed TES4 header");
    size_t p=0;bool hedr=false,extended=false;uint32_t extendedSize=0;
    while(p<body.size()){
        if(body.size()-p<6)return reject("truncated subrecord");
        auto tag=&body[p];uint32_t n=u16(tag+4);p+=6;
        if(!memcmp(tag,"XXXX",4)){
            if(n!=4 || extended || body.size()-p<4)return reject("invalid XXXX size marker");
            extended=true;extendedSize=u32(&body[p]);p+=4;continue;
        }
        if(extended){n=extendedSize;extended=false;}
        if(n>body.size()-p)return reject("subrecord exceeds header");
        if(!memcmp(tag,"HEDR",4)){if(hedr || n<12)return reject("invalid HEDR");hedr=true;}
        if(!memcmp(tag,"MAST",4)){
            if(!n || body[p+n-1] || memchr(&body[p],0,n-1))return reject("invalid master filename");
            std::string name((const char*)&body[p],n-1);if(!safeName(name))return reject("unsafe master filename");
            for(auto& m:masters)if(lower(m)==lower(name))return reject("duplicate master");
            masters.push_back(name);if(masters.size()>255)return reject("more than 255 masters in one plugin");
        }
        p+=n;
    }
    return hedr && !extended?true:reject("missing HEDR or unfinished XXXX");
}
inline std::wstring modulePath(HMODULE m){wchar_t p[32768]{};DWORD n=GetModuleFileNameW(m,p,32768);return n && n<32768?std::wstring(p):L"";}
inline std::string fileHash(const std::wstring& p){std::array<unsigned char,32> digest{};if(!fileSha256(p.c_str(),digest))return "unreadable";char s[65]{};for(unsigned i=0;i<32;++i)snprintf(s+2*i,3,"%02x",digest[i]);return s;}
inline std::wstring profileFromVirtualPlugins(std::wstring& effective){
    wchar_t local[32768]{};if(FAILED(SHGetFolderPathW(nullptr,CSIDL_LOCAL_APPDATA,nullptr,SHGFP_TYPE_CURRENT,local)))return L"";
    std::string bytes;std::wstring resolved;
    if(!text(std::wstring(local)+L"\\FalloutNV\\plugins.txt",bytes,&resolved))return L"";
    effective=std::wstring(local)+L"\\FalloutNV\\plugins.txt";
    auto folder=parent(resolved);return exists(folder+L"\\modlist.txt") && exists(folder+L"\\plugins.txt")?folder:L"";
}
inline std::wstring chooseProfile(){
    BROWSEINFOW browse{};browse.lpszTitle=L"WideNormalLoader: select the ACTIVE MO2 profile folder containing plugins.txt and modlist.txt";
    browse.ulFlags=BIF_RETURNONLYFSDIRS|BIF_NEWDIALOGSTYLE;
    HRESULT init=CoInitializeEx(nullptr,COINIT_APARTMENTTHREADED);
    auto item=SHBrowseForFolderW(&browse);wchar_t path[MAX_PATH]{};
    if(item){SHGetPathFromIDListW(item,path);CoTaskMemFree(item);}
    if(SUCCEEDED(init))CoUninitialize();return path;
}
inline bool writeAtomic(const std::wstring& path,const std::string& bytes){
    auto tmp=path+L".tmp-"+std::to_wstring(GetCurrentProcessId())+L"-"+std::to_wstring(GetTickCount());
    HANDLE h=CreateFileW(tmp.c_str(),GENERIC_WRITE,0,nullptr,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,nullptr);if(h==INVALID_HANDLE_VALUE)return false;
    DWORD n=0;bool ok=WriteFile(h,bytes.data(),DWORD(bytes.size()),&n,nullptr) && n==bytes.size() && FlushFileBuffers(h);CloseHandle(h);
    if(ok)ok=MoveFileExW(tmp.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)!=0;
    if(!ok)DeleteFileW(tmp.c_str());return ok;
}
inline void section(std::string& s,const char* name,const std::vector<std::string>& values){s+='[';s+=name;s+="]\n";for(auto& v:values)s+=lower(v)+'\n';}
inline bool validBaseline(const std::string& s){return s.rfind("WideNormalLoader baseline v1\n",0)==0;}
inline std::vector<std::string> changedSections(const std::string& before,const std::string& after){
    std::vector<std::string> changed;
    for(auto name:{"MO2Active","MO2Order","WideOrder","PluginFiles","NativeDLLs","Settings"}){
        auto block=[&](const std::string& s){std::string key=std::string("[")+name+"]\n";auto p=s.find(key);if(p==s.npos)return std::string();auto e=s.find("\n[",p+1);return s.substr(p,e==s.npos?s.npos:e+1-p);};
        if(block(before)!=block(after))changed.push_back(name);
    }
    return changed;
}
inline std::vector<std::string> sectionValues(const std::string& text,const std::string& name){
    std::vector<std::string> values;auto key="["+name+"]\n";auto p=text.find(key);if(p==text.npos)return values;p+=key.size();
    while(p<text.size() && text[p]!='['){auto e=text.find('\n',p);auto line=text.substr(p,e==text.npos?text.npos:e-p);if(!line.empty())values.push_back(line);p=e==text.npos?text.size():e+1;}
    return values;
}

inline bool run(HMODULE self,const std::wstring& ini,const std::string& explicitOrder,const std::string& extraDirectory,FILE* loaderLog){
    const auto game=modulePath(nullptr),root=parent(game);
    auto reportPath=root+L"\\WideNormalLoader-preflight.txt";
    FILE* report=_wfopen(reportPath.c_str(),L"wb");
    if(!report){
        wchar_t local[32768]{};
        if(SUCCEEDED(SHGetFolderPathW(nullptr,CSIDL_LOCAL_APPDATA,nullptr,SHGFP_TYPE_CURRENT,local))){
            auto dir=std::wstring(local)+L"\\WideNormalLoader";CreateDirectoryW(dir.c_str(),nullptr);
            reportPath=dir+L"\\preflight-"+std::to_wstring(GetCurrentProcessId())+L".txt";report=_wfopen(reportPath.c_str(),L"wb");
        }
    }
    if(!report){MessageBoxW(nullptr,L"Could not write the startup report beside FalloutNV.exe or in Local AppData. Check folder permissions.",L"WideNormalLoader preflight stopped",MB_OK|MB_ICONERROR);return false;}
    struct Close {FILE* f;~Close(){fclose(f);}} close{report};
    unsigned errors=0,warnings=0;std::string firstError;
    auto problem=[&](const std::string& s){++errors;if(firstError.empty())firstError=s;fprintf(report,"ERROR: %s\n",s.c_str());};
    auto warn=[&](const std::string& s){++warnings;fprintf(report,"WARNING: %s\n",s.c_str());};
    auto winning=[&](const char* name,const std::wstring& p){File f(p);fprintf(report,"WINNING %s requested=%s resolved=%s\n",name,utf8(p).c_str(),utf8(f.resolved()).c_str());};
    fprintf(report,"WideNormalLoader built-in startup report\nChecks precede engine plugin loading. Successful checks do not certify gameplay or save migration.\n");
    winning("loader DLL",modulePath(self));winning("loader INI",ini);
    auto checkRuntime=[&](const char* name,HMODULE module,const char* expected){auto p=modulePath(module);auto sha=module?fileHash(p):"absent";fprintf(report,"RUNTIME %s path=%s sha256=%s\n",name,utf8(p).c_str(),sha.c_str());if(!module || sha!=expected)problem(std::string(name)+" does not match this loader's supported build.");};
    checkRuntime("FalloutNV.exe",GetModuleHandleW(nullptr),"518c87f58a6c4d9826e9ef8fbb7f4213882fa70822675610d45aea2464502a57");
    checkRuntime("xNVSE",GetModuleHandleW(L"nvse_1_4.dll"),"e82c5d348bac255a8ff4cf477df2e48149304b18f02b42b2a835c3cba71f3dfb");
    auto cache=root+L"\\Data\\NVSE\\nvse_config.ini";winning("xNVSE config",cache);
    if(GetPrivateProfileIntW(L"Release",L"bNoScriptRunnerCaching",0,cache.c_str())!=1)problem("Set [Release] bNoScriptRunnerCaching = 1 in the winning Data\\NVSE\\nvse_config.ini.");
    auto orderPath=widen(explicitOrder);std::string orderBytes;std::vector<std::string> wide;
    winning("wide load order",orderPath);
    if(explicitOrder.empty() || !text(orderPath,orderBytes) || !lines(orderBytes,wide) || wide.empty() || wide.size()>1024)problem("The wide order is unreadable, malformed, empty or exceeds 1,024 plugins.");
    std::unordered_map<std::string,size_t> slots;
    for(size_t i=0;i<wide.size();++i){if(!slots.emplace(lower(wide[i]),i).second)problem("Duplicate wide plugin: "+wide[i]);}
    std::vector<std::string> pluginStates;
    for(size_t i=0;i<wide.size();++i){
        auto path=root+L"\\Data\\"+widen(wide[i]);if(!exists(path) && !extraDirectory.empty())path=widen(extraDirectory)+L"\\"+widen(wide[i]);
        File f(path);if(f.h==INVALID_HANDLE_VALUE){problem("Plugin file missing: "+wide[i]);continue;}
        BY_HANDLE_FILE_INFORMATION info{};if(!GetFileInformationByHandle(f.h,&info)){problem("Cannot inspect plugin file: "+wide[i]);continue;}
        pluginStates.push_back(wide[i]+"|"+std::to_string(info.nFileSizeHigh)+":"+std::to_string(info.nFileSizeLow)+"|"+std::to_string(info.ftLastWriteTime.dwHighDateTime)+":"+std::to_string(info.ftLastWriteTime.dwLowDateTime));
        unsigned char h[24]{};if(!f.read(h,24) || u32(h+4)>16*1024*1024){problem("Invalid plugin header: "+wide[i]);continue;}
        std::vector<unsigned char> body(u32(h+4));std::vector<std::string> masters;std::string reason;
        if((!body.empty() && !f.read(body.data(),DWORD(body.size()))) || !header(h,body,masters,reason)){problem("Invalid plugin "+wide[i]+": "+reason);continue;}
        fprintf(report,"PLUGIN slot=%zu name=%s path=%s masters=%zu\n",i,wide[i].c_str(),utf8(f.resolved()).c_str(),masters.size());
        for(auto& master:masters){auto it=slots.find(lower(master));if(it==slots.end())problem(wide[i]+" requires missing selected master "+master);else if(it->second>=i)problem(master+" must load before "+wide[i]);}
    }
    std::vector<std::string> nativeStates;
    HANDLE snap=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE,GetCurrentProcessId());MODULEENTRY32W entry{};entry.dwSize=sizeof(entry);
    if(snap==INVALID_HANDLE_VALUE)problem("Cannot enumerate loaded native DLLs.");
    else{
        if(Module32FirstW(snap,&entry))do{
            std::string path=lower(utf8(entry.szExePath)),name=lower(utf8(entry.szModule));
            if(path.find("nvse\\plugins\\")==path.npos && entry.hModule!=self)continue;
            auto hash=fileHash(entry.szExePath);nativeStates.push_back(name+"|"+hash);
            const char* supported=nullptr;
            if(name=="jip_nvse.dll")supported=wide::jipSupportedHash(hash.c_str())?hash.c_str():wide::jipOriginalHash;
            if(name=="supnvse.dll")supported="61b0f1760a643ee749c785bf989f22b18f7b445891d2595f55445281c8a22e6c";
            if(name=="showoffnvse.dll")supported="37cb22c5288fedd0d57196c8c2f6bbaba5a1dafd9ce58f14dac9410dbee7ef3e";
            if(name=="nvse_stewie_tweaks.dll")supported="c19007b47f39df2ce07cfc1add1a27090302cf35e1673ba35bee61cb5800db95";
            fprintf(report,"NATIVE name=%s path=%s sha256=%s adapter=%s\n",name.c_str(),utf8(entry.szExePath).c_str(),hash.c_str(),supported?(hash==supported?"supported_build_pending_hook_checks":"unsupported_build_skipped"):"no_adapter");
            if(supported && hash!=supported)warn(name+": adapter will be skipped; extended-plugin features are unverified.");
            if(name=="knvse.dll" || name=="sound_extender.dll" || name=="yui.dll" || name=="johnnyguitar.dll" || name=="hnvse.dll" || name=="race_menu_presets.dll")warn(name+": known plugin identity consumers remain outside these adapters.");
        }while(Module32NextW(snap,&entry));CloseHandle(snap);
    }
    std::sort(nativeStates.begin(),nativeStates.end());
    std::wstring effective,profile=profileFromVirtualPlugins(effective);
    bool mo2=GetModuleHandleW(L"usvfs_x86.dll") || GetModuleHandleW(L"usvfs.dll") || !profile.empty();
    wchar_t configured[32768]{};GetPrivateProfileStringW(L"Preflight",L"ProfileDirectory",L"",configured,32768,ini.c_str());
    if(!profile.empty())fprintf(report,"PROFILE source=resolved_virtual_plugins path=%s\n",utf8(profile).c_str());
    else if(mo2 && *configured){profile=configured;fprintf(report,"PROFILE source=configured path=%s\n",utf8(profile).c_str());}
    else if(mo2 && !errors){
        profile=chooseProfile();
        if(!profile.empty() && exists(profile+L"\\plugins.txt") && exists(profile+L"\\modlist.txt"))WritePrivateProfileStringW(L"Preflight",L"ProfileDirectory",profile.c_str(),ini.c_str());
    }
    std::vector<std::string> active,moOrder;std::string activeBytes,moBytes;
    if(!mo2){
        profile=parent(reportPath);moOrder=wide;
        fprintf(report,"PROFILE mode=non_MO2 wide_order_is_authoritative=1\n");
        if(effective.empty() || !text(effective,activeBytes) || !lines(activeBytes,active,true))warn("No effective launcher plugins.txt was readable; selection checks use the explicit wide order only.");
    }else if(profile.empty() || !exists(profile+L"\\modlist.txt") || !text(profile+L"\\plugins.txt",activeBytes) || !lines(activeBytes,active,true))problem("Select the active MO2 profile folder containing plugins.txt and modlist.txt. Configure [Preflight] ProfileDirectory if automatic detection is unavailable.");
    else{
        winning("MO2 active plugins",profile+L"\\plugins.txt");
        if(!text(profile+L"\\loadorder.txt",moBytes) || !lines(moBytes,moOrder))problem("MO2 loadorder.txt is missing or malformed in the selected profile.");
        if(!effective.empty()){
            std::string effectiveBytes;std::vector<std::string> effectiveActive;
            if(text(effective,effectiveBytes) && lines(effectiveBytes,effectiveActive,true) && normalized(effectiveActive)!=normalized(active))problem("The chosen profile differs from the effective plugins.txt seen by the game. Select the active launch profile, not another profile.");
        }
    }
    {
        auto d=compare(active,moOrder,wide);
        for(size_t i=0;i<active.size();++i)fprintf(report,"MO2_ACTIVE ordinal=%zu name=%s\n",i,active[i].c_str());
        if(mo2)for(size_t i=0;i<moOrder.size();++i)fprintf(report,"MO2_ORDER ordinal=%zu name=%s\n",i,moOrder[i].c_str());
        for(auto& name:d.missing)problem(std::string(mo2?"MO2":"The launcher")+" enables a plugin absent from the wide order: "+name);
        if(d.reordered)problem("MO2 and the wide order disagree on the relative order of shared active plugins. Synchronize their order before launching.");
        fprintf(report,"SELECTION mo2_active=%zu wide=%zu wide_only=%zu\n",active.size(),wide.size(),d.wideOnly.size());
        for(auto& name:d.wideOnly)fprintf(report,"WIDE_ONLY %s\n",name.c_str());
        if(!d.wideOnly.empty())warn("Wide-only plugins may be intentional above MO2's limit. They are listed above and included in the reviewed baseline.");
    }
    std::string baseline="WideNormalLoader baseline v1\n";section(baseline,"MO2Active",active);section(baseline,"MO2Order",moOrder);section(baseline,"WideOrder",wide);section(baseline,"PluginFiles",pluginStates);section(baseline,"NativeDLLs",nativeStates);
    section(baseline,"Settings",{std::string("autodetect=")+std::to_string(GetPrivateProfileIntW(L"WideLoader",L"AutoDetectOptionalAdapters",0,ini.c_str())),std::string("optional_adapters_enabled=")+std::to_string(GetPrivateProfileIntW(L"WideLoader",L"OptionalAdaptersEnabled",1,ini.c_str()))});
    auto baselinePath=profile+L"\\WideNormalLoader-preflight.baseline";std::string previous;
    bool have=text(baselinePath,previous) && validBaseline(previous);auto changes=changedSections(previous,baseline);
    for(auto& s:changes){
        auto a=sectionValues(previous,s),b=sectionValues(baseline,s);bool membership=false;
        for(auto& value:a)if(std::find(b.begin(),b.end(),value)==b.end()){fprintf(report,"REMOVED section=%s value=%s\n",s.c_str(),value.c_str());membership=true;}
        for(auto& value:b)if(std::find(a.begin(),a.end(),value)==a.end()){fprintf(report,"ADDED section=%s value=%s\n",s.c_str(),value.c_str());membership=true;}
        if(!membership)fprintf(report,"ORDER_CHANGED section=%s\n",s.c_str());
    }
    fprintf(report,"BASELINE path=%s present=%u changed_sections=",utf8(baselinePath).c_str(),have);
    for(auto& s:changes)fprintf(report,"%s,",s.c_str());fprintf(report,"\nRESULT errors=%u warnings=%u\n",errors,warnings);fflush(report);
    fprintf(loaderLog,"STARTUP_PREFLIGHT report=%s errors=%u warnings=%u\n",utf8(reportPath).c_str(),errors,warnings);fflush(loaderLog);
    if(errors){
        std::wstring msg=L"Plugin loading was stopped before engine hooks were installed.\n\n"+widen(firstError)+L"\n\nFull report:\n"+reportPath+L"\n\nFix the findings, then launch again. Your plugin selection was not changed.";
        MessageBoxW(nullptr,msg.c_str(),L"WideNormalLoader: startup check failed",MB_OK|MB_ICONERROR|MB_SETFOREGROUND);return false;
    }
    if(!have || !changes.empty()){
        std::wstring msg=have?L"The modlist changed since its last reviewed startup.\n\nChanged sections:\n":L"This profile has no reviewed startup baseline.\n\n";
        if(have)for(auto& s:changes)msg+=L" - "+widen(s)+L"\n";
        msg+=L"\nReview the report before continuing:\n"+reportPath+L"\n\nSelect Yes to accept this selection and continue, or No to stop. This does not enable, disable or reorder plugins. File checks do not certify gameplay or save compatibility.";
        if(MessageBoxW(nullptr,msg.c_str(),L"WideNormalLoader: review modlist",MB_YESNO|MB_DEFBUTTON2|MB_ICONWARNING|MB_SETFOREGROUND)!=IDYES){fprintf(report,"USER_DECISION stopped_without_accepting\n");return false;}
        if(!writeAtomic(baselinePath,baseline)){fprintf(report,"ERROR baseline could not be saved\n");MessageBoxW(nullptr,L"The reviewed baseline could not be saved in the profile folder. Check write permissions.",L"WideNormalLoader preflight stopped",MB_OK|MB_ICONERROR);return false;}
        fprintf(report,"USER_DECISION accepted_baseline\n");
    }
    fprintf(report,"STARTUP_CHECK_PASSED runtime_hook_checks_and_gameplay_still_required=1\n");return true;
}
}} // namespace wide::startup
