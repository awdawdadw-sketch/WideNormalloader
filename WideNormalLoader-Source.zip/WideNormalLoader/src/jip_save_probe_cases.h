#pragma once
struct JipSaveProbeCase {uint32_t slot;const char* writeExpression;double writeExpected;const char* readExpression;double readExpected;};
inline constexpr JipSaveProbeCase jipSaveProbeCases[]={
    {997,"AuxiliaryVariableSetFloat \"WideSaveFloat\" 9001",1,"AuxiliaryVariableGetFloat \"WideSaveFloat\"",9001},
    {998,"AuxiliaryVariableSetFloat \"WideSaveFloat\" 9002",1,"AuxiliaryVariableGetFloat \"WideSaveFloat\"",9002},
    {997,"AuxiliaryVariableSetString \"WideSaveString\" \"wide-save-A\"",1,"(AuxiliaryVariableGetString \"WideSaveString\") == \"wide-save-A\"",1},
    {998,"AuxiliaryVariableSetString \"WideSaveString\" \"wide-save-B\"",1,"(AuxiliaryVariableGetString \"WideSaveString\") == \"wide-save-B\"",1},
    {997,"AuxiliaryVariableSetRef \"WideSaveRef\" (GetFormFromMod \"NativeProbe_0689.esp\" \"000800\")",1,"(AuxiliaryVariableGetRef \"WideSaveRef\") == (GetFormFromMod \"NativeProbe_0689.esp\" \"000800\")",1},
    {998,"AuxiliaryVariableSetRef \"WideSaveRef\" (GetFormFromMod \"NativeProbe_0690.esp\" \"000800\")",1,"(AuxiliaryVariableGetRef \"WideSaveRef\") == (GetFormFromMod \"NativeProbe_0690.esp\" \"000800\")",1},
    {997,"RefMapArraySetFloat \"WideSaveMap\" 9101",0,"RefMapArrayGetFloat \"WideSaveMap\"",9101},
    {998,"RefMapArraySetFloat \"WideSaveMap\" 9102",0,"RefMapArrayGetFloat \"WideSaveMap\"",9102},
    {997,"RefMapArraySetRef \"WideSaveMapRef\" (GetFormFromMod \"NativeProbe_0689.esp\" \"000800\")",0,"(RefMapArrayGetRef \"WideSaveMapRef\") == (GetFormFromMod \"NativeProbe_0689.esp\" \"000800\")",1},
    {998,"RefMapArraySetRef \"WideSaveMapRef\" (GetFormFromMod \"NativeProbe_0690.esp\" \"000800\")",0,"(RefMapArrayGetRef \"WideSaveMapRef\") == (GetFormFromMod \"NativeProbe_0690.esp\" \"000800\")",1},
};
