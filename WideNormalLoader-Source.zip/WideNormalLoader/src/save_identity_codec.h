#pragma once
#include <stdint.h>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>
namespace wide {
// Independent, versioned metadata. ESP/ESM selectors and legacy records are
// unchanged. Runtime handles are saved alongside their canonical identities.
struct SavedFormIdentity {uint32_t handle;uint16_t slot;uint32_t local;};
struct SaveIdentities {std::vector<std::string> plugins;std::vector<SavedFormIdentity> forms;};
static constexpr uint32_t saveIdentityVersion=1,saveIdentityRecord=0x5749444D; // WIDM numeric FourCC
static constexpr uint32_t maxIdentityBytes=64*1024*1024;
inline std::string normalizedPlugin(std::string value){
    for(char& c:value)if(c>='A' && c<='Z')c+=32;
    return value;
}
inline bool identitySlotMap(const std::vector<std::string>& saved,const std::vector<std::string>& current,std::vector<uint32_t>& output,uint32_t& missing){
    if(saved.size()>1024 || current.size()>1024)return false;
    std::unordered_map<std::string,uint32_t> names;
    for(uint32_t i=0;i<current.size();++i)if(!names.emplace(normalizedPlugin(current[i]),i).second)return false;
    std::vector<uint32_t> mapped(saved.size(),UINT32_MAX);uint32_t absent=0;
    for(uint32_t i=0;i<saved.size();++i){auto it=names.find(normalizedPlugin(saved[i]));if(it==names.end())++absent;else mapped[i]=it->second;}
    output=std::move(mapped);missing=absent;return true;
}
inline uint32_t identityCrc(const unsigned char* data,size_t n){
    uint32_t crc=~0u;
    for(size_t i=0;i<n;++i){crc^=data[i];for(unsigned j=0;j<8;++j)crc=(crc>>1)^(0xEDB88320u&-(crc&1));}
    return ~crc;
}
inline bool validPluginName(const std::string& s){
    if(s.empty() || s.size()>259)return false;
    for(unsigned char c:s)if(!c || c=='/' || c=='\\' || c==':')return false;
    return true;
}
inline bool validateIdentities(const SaveIdentities& in){
    if(in.plugins.empty() || in.plugins.size()>1024 || in.forms.size()>(maxIdentityBytes-12)/10)return false;
    std::unordered_set<std::string> names;
    for(const auto& name:in.plugins)if(!validPluginName(name) || !names.insert(normalizedPlugin(name)).second)return false;
    std::unordered_set<uint32_t> handles;std::unordered_set<uint64_t> canonical;
    for(auto f:in.forms){
        if(f.handle<0xFD000800 || f.handle>=0xFF000000 || f.slot<253 || f.slot>=in.plugins.size() || f.local<0x800 || f.local>0xFFFFFF)return false;
        if(!handles.insert(f.handle).second || !canonical.insert((uint64_t(f.slot)<<24)|f.local).second)return false;
    }
    return true;
}
inline void identityPut(std::vector<unsigned char>& out,uint32_t value,unsigned width){
    for(unsigned i=0;i<width;++i)out.push_back((unsigned char)(value>>(8*i)));
}
inline bool encodeIdentities(const SaveIdentities& in,std::vector<unsigned char>& out){
    if(!validateIdentities(in))return false;
    std::vector<unsigned char> bytes;
    identityPut(bytes,saveIdentityVersion,4);identityPut(bytes,(uint32_t)in.plugins.size(),4);
    for(const auto& name:in.plugins){identityPut(bytes,(uint32_t)name.size(),2);bytes.insert(bytes.end(),name.begin(),name.end());}
    identityPut(bytes,(uint32_t)in.forms.size(),4);
    for(auto f:in.forms){identityPut(bytes,f.handle,4);identityPut(bytes,f.slot,2);identityPut(bytes,f.local,4);}
    if(bytes.size()>maxIdentityBytes-4)return false;
    identityPut(bytes,identityCrc(bytes.data(),bytes.size()),4);out=std::move(bytes);return true;
}
inline bool decodeIdentities(const unsigned char* data,size_t size,SaveIdentities& output){
    if(!data || size<16 || size>maxIdentityBytes)return false;
    size_t end=size-4,pos=0;
    auto word=[&](unsigned width,uint32_t& v){
        if(width>end-pos)return false;v=0;
        for(unsigned i=0;i<width;++i)v|=uint32_t(data[pos++])<<(8*i);
        return true;
    };
    uint32_t stored=uint32_t(data[end])|uint32_t(data[end+1])<<8|uint32_t(data[end+2])<<16|uint32_t(data[end+3])<<24;
    if(identityCrc(data,end)!=stored)return false;
    uint32_t version=0,count=0;
    if(!word(4,version) || version!=saveIdentityVersion || !word(4,count) || !count || count>1024)return false;
    SaveIdentities decoded;decoded.plugins.reserve(count);
    for(uint32_t i=0;i<count;++i){
        uint32_t n=0;if(!word(2,n) || !n || n>259 || n>end-pos)return false;
        decoded.plugins.emplace_back((const char*)data+pos,n);pos+=n;
    }
    if(!word(4,count) || count>(end-pos)/10 || end-pos!=size_t(count)*10)return false;
    decoded.forms.reserve(count);
    for(uint32_t i=0;i<count;++i){
        uint32_t handle=0,slot=0,local=0;
        if(!word(4,handle) || !word(2,slot) || !word(4,local))return false;
        decoded.forms.push_back({handle,(uint16_t)slot,local});
    }
    if(pos!=end || !validateIdentities(decoded))return false;
    output=std::move(decoded);return true;
}
}
