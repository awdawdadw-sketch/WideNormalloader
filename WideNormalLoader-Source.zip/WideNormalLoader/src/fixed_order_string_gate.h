#pragma once
#include <cstring>
#include "save_identity_codec.h"
namespace wide {
inline void buildCoreStringOwnerBridge(unsigned char (&code)[27],uint32_t address,uint32_t callback,uint32_t reject,uint32_t accept){
    const unsigned char bytes[]={0x51,0xB8,0,0,0,0,0xFF,0xD0,0x83,0xC4,0x04,0x3D,0xFF,0,0,0,0x0F,0x84,0,0,0,0,0xE9,0,0,0,0};
    memcpy(code,bytes,sizeof(bytes));memcpy(code+2,&callback,4);
    uint32_t delta=reject-(address+22);memcpy(code+18,&delta,4);delta=accept-(address+27);memcpy(code+23,&delta,4);
}
// Legacy STVR has only an owner byte. Accept opaque owners solely when full
// WIDM plugin names prove identical order; this does not infer individual owners.
inline bool validateFixedOrderStringSave(const unsigned char* bytes,size_t size,const std::vector<std::string>& current,uint32_t& opaqueCount,uint32_t& manifestCrc){
    if(!bytes || size<20 || size>maxIdentityBytes || memcmp(bytes,"NVSE",4))return false;
    auto u32=[&](size_t pos){return uint32_t(bytes[pos])|(uint32_t(bytes[pos+1])<<8)|(uint32_t(bytes[pos+2])<<16)|(uint32_t(bytes[pos+3])<<24);};
    if(u32(4)!=1 || u32(16)>65536)return false;
    size_t pos=20;bool manifest=false,inStrings=false,sawStrings=false,closedStrings=false;uint32_t count=0,crc=0;
    std::unordered_set<uint32_t> ids;
    for(uint32_t block=0;block<u32(16);++block){
        if(size-pos<12)return false;
        uint32_t opcode=u32(pos),records=u32(pos+4),length=u32(pos+8);pos+=12;
        if(length>size-pos || records>length/12)return false;size_t end=pos+length;
        for(uint32_t record=0;record<records;++record){
            if(end-pos<12)return false;
            uint32_t tag=u32(pos),version=u32(pos+4),n=u32(pos+8);pos+=12;if(n>end-pos)return false;
            if(tag==saveIdentityRecord){
                SaveIdentities saved;
                if(manifest || version!=saveIdentityVersion || !decodeIdentities(bytes+pos,n,saved) || saved.plugins.size()!=current.size())return false;
                for(size_t i=0;i<current.size();++i)if(normalizedPlugin(saved.plugins[i])!=normalizedPlugin(current[i]))return false;
                manifest=true;crc=identityCrc(bytes+pos,n-4);
            }
            if(opcode==0x1400){
                if(tag==0x53545653){if(sawStrings || version || n)return false;sawStrings=inStrings=true;}
                else if(tag==0x53545645){if(!inStrings || version || n)return false;inStrings=false;closedStrings=true;}
                else if(tag==0x53545652){
                    if(!inStrings || version || n<7)return false;
                    uint32_t id=u32(pos+1),length=bytes[pos+5]|(uint32_t(bytes[pos+6])<<8);
                    if(!id || !ids.insert(id).second || length>=0x4000 || length!=n-7 || memchr(bytes+pos+7,0,length))return false;
                    if(bytes[pos]==253 || bytes[pos]==254)++count;
                }else if(inStrings)return false;
            }
            pos+=n;
        }
        if(pos!=end)return false;
    }
    if(pos!=size || !manifest || !sawStrings || !closedStrings || inStrings)return false;
    opaqueCount=count;manifestCrc=crc;return true;
}
}
