#pragma once
#include <windows.h>
#include <tlhelp32.h>
#include "runtime_patch.h"
#include "module_sha256.h"

// Exact installed xNVSE only. Observe its existing invalid allocation guard;
// never bypass it. No heap allocation or CRT formatting in the failure callback.
namespace wide {
static HANDLE fastFailFile=INVALID_HANDLE_VALUE;
static RuntimePatch fastFailPatch;
static LONG fastFailCaptured=0;
static unsigned char fastFailStack[32768],fastFailFrame[1024];
static unsigned char fastFailStrings[3][4096];
static void __cdecl captureNvseFastFail(const DWORD* saved) {
    if(InterlockedCompareExchange(&fastFailCaptured,1,0))return;
    // pushfd/pushad: EDI ESI EBP original-ESP EBX EDX ECX EAX EFLAGS.
    DWORD registers[9]{};SIZE_T got=0;
    ReadProcessMemory(GetCurrentProcess(),saved,registers,sizeof(registers),&got);
    DWORD esp=registers[3]+4,frame=registers[2]-512,written=0;
    SIZE_T stackBytes=0,frameBytes=0;
    ReadProcessMemory(GetCurrentProcess(),(void*)esp,fastFailStack,sizeof(fastFailStack),&stackBytes);
    ReadProcessMemory(GetCurrentProcess(),(void*)frame,fastFailFrame,sizeof(fastFailFrame),&frameBytes);
    DWORD header[]={0x5746464E,2,GetCurrentThreadId(),esp,frame,(DWORD)stackBytes,(DWORD)frameBytes,5};
    WriteFile(fastFailFile,header,sizeof(header),&written,nullptr);
    WriteFile(fastFailFile,registers,sizeof(registers),&written,nullptr);
    WriteFile(fastFailFile,fastFailStack,(DWORD)stackBytes,&written,nullptr);
    WriteFile(fastFailFile,fastFailFrame,(DWORD)frameBytes,&written,nullptr);
    const int offsets[]={-0x44,-0x28,8};
    for(unsigned i=0;i<3;++i){
        DWORD object[6]{};SIZE_T bytes=0;
        DWORD address=registers[2]+offsets[i];
        ReadProcessMemory(GetCurrentProcess(),(void*)address,object,sizeof(object),&bytes);
        DWORD data=object[5]>15?object[0]:address;
        SIZE_T captured=0;
        // Capture a bounded region including the possible allocator header.
        ReadProcessMemory(GetCurrentProcess(),(void*)(data-32),fastFailStrings[i],sizeof(fastFailStrings[i]),&captured);
        DWORD descriptor[]={address,data-32,(DWORD)bytes,(DWORD)captured};
        WriteFile(fastFailFile,descriptor,sizeof(descriptor),&written,nullptr);
        WriteFile(fastFailFile,object,sizeof(object),&written,nullptr);
        WriteFile(fastFailFile,fastFailStrings[i],(DWORD)captured,&written,nullptr);
    }
    FlushFileBuffers(fastFailFile);
}
static bool installNvseFastFailCapture(const char* logPath,FILE* log) {
    HMODULE module=GetModuleHandleA("nvse_1_4.dll");
    if(!moduleMatchesSha256(module,"e82c5d348bac255a8ff4cf477df2e48149304b18f02b42b2a835c3cba71f3dfb"))return false;
    const unsigned char expected[]={0xB9,5,0,0,0,0xCD,0x29};
    DWORD site=(DWORD)module+0x1169E;
    if(memcmp((void*)site,expected,sizeof(expected)))return false;
    char path[MAX_PATH]{};
    if(strlen(logPath)+strlen(".nvse-fastfail.bin")>=sizeof(path))return false;
    strcpy(path,logPath);strcat(path,".nvse-fastfail.bin");
    fastFailFile=CreateFileA(path,GENERIC_WRITE,FILE_SHARE_READ,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
    if(fastFailFile==INVALID_HANDLE_VALUE)return false;
    // Call observer with register snapshot, restore machine state, execute the
    // original mov ecx,5; int 29 via the trampoline. Failure remains observable.
    auto* bridge=(unsigned char*)VirtualAlloc(nullptr,32,MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);
    if(!bridge){CloseHandle(fastFailFile);fastFailFile=INVALID_HANDLE_VALUE;return false;}
    const unsigned char code[]={0x9C,0x60,0x8B,0xC4,0x50,0xE8,0,0,0,0,0x83,0xC4,4,0x61,0x9D,0xE9,0,0,0,0};
    memcpy(bridge,code,sizeof(code));
    *(DWORD*)(bridge+6)=(DWORD)&captureNvseFastFail-(DWORD)(bridge+10);
    auto* original=(unsigned char*)VirtualAlloc(nullptr,12,MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);
    if(!original){VirtualFree(bridge,0,MEM_RELEASE);CloseHandle(fastFailFile);fastFailFile=INVALID_HANDLE_VALUE;return false;}
    memcpy(original,expected,sizeof(expected));original[7]=0xE9;
    *(DWORD*)(original+8)=site+7-(DWORD)(original+12);
    *(DWORD*)(bridge+16)=(DWORD)original-(DWORD)(bridge+20);
    FlushInstructionCache(GetCurrentProcess(),original,12);
    FlushInstructionCache(GetCurrentProcess(),bridge,sizeof(code));
    unsigned char patch[7]={0xE9,0,0,0,0,0x90,0x90};
    *(DWORD*)(patch+1)=(DWORD)bridge-site-5;
    if(!fastFailPatch.replace(site,expected,patch,sizeof(patch))){
        fastFailPatch.restore();VirtualFree(bridge,0,MEM_RELEASE);VirtualFree(original,0,MEM_RELEASE);
        CloseHandle(fastFailFile);fastFailFile=INVALID_HANDLE_VALUE;return false;
    }
    fastFailPatch.trampoline=original;
    HANDLE snapshot=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE,GetCurrentProcessId());
    if(snapshot!=INVALID_HANDLE_VALUE){
        MODULEENTRY32 entry{};entry.dwSize=sizeof(entry);
        if(Module32First(snapshot,&entry))do{
            fprintf(log,"FASTFAIL_MODULE base=%08lX size=%08lX path=%s\n",(DWORD)entry.modBaseAddr,entry.modBaseSize,entry.szExePath);
        }while(Module32Next(snapshot,&entry));
        CloseHandle(snapshot);
    }
    fprintf(log,"NVSE_FASTFAIL_CAPTURE_ACTIVE site=%08lX output=%s preserves_fastfail=1\n",site,path);fflush(log);
    return true;
}
}
