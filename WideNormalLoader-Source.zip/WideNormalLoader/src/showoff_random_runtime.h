#pragma once
#include "plugin_owner_scope.h"
#include "sup_hud_transfer_stub.h"
#include "module_sha256.h"
#include "runtime_patch.h"
#include <array>
#include <utility>
namespace wide {
class ShowOffRandomRuntime {
    inline static ShowOffRandomRuntime* active=nullptr;
    using Resolver=bool(*)(void*,uint32_t&);
    Resolver resolver=nullptr;
    std::array<CommandExecute,6> originals{};
    std::vector<RuntimePatch> patches;
    std::vector<void*> executable;
    static uint32_t __cdecl owner(uint32_t fallback){return PluginOwnerScope::currentOrByte(fallback);}
    template<size_t index> static bool __cdecl command(WIDE_COMMAND_ARGS){
        uint32_t value=UINT32_MAX;
        try{if(active->resolver(scriptObj,value) && PluginOwnerScope::valid(value)){
            PluginOwnerScope scope(value);return active->originals[index](WIDE_PASS_ARGS);
        }}catch(...){}
        if(result)*result=-1;return true;
    }
    template<size_t... indices> static constexpr auto callbacks(std::index_sequence<indices...>){return std::array<CommandExecute,sizeof...(indices)>{{&command<indices>...}};}
    void rollback(){for(auto p=patches.rbegin();p!=patches.rend();++p)p->restore();for(auto* p:executable)VirtualFree(p,0,MEM_RELEASE);patches.clear();executable.clear();if(active==this)active=nullptr;}
public:
    struct CommandSite{const char* name;uint32_t rva;};
    inline static constexpr CommandSite commands[]={
        {"SetRandomizerSeed",0x88210},{"SetSeedUsingForm",0x88250},{"GetRandomizerSeed",0x882b0},
        {"RandSeeded",0x88440},{"GetRandomPercentSeeded",0x884b0},{"AdvanceSeed",0x884f0}};
    // Complete instructions. Two spans include a direct CALL relocated into a
    // separately generated landing block, never copied with its old offset.
    inline static constexpr SupHudTransferSite sites[]={
        {0x88147,11,SupHudTransferKind::Current,4,{0x0f,0xb6,0xf3,0x56,0xc7,0x45,0xfc,0,0,0,0},8,{0x56,0xc7,0x45,0xfc,0,0,0,0}},
        {0x88387,11,SupHudTransferKind::Current,16,{0x0f,0xb6,0xdb,0x53,0xc7,0x45,0xfc,0,0,0,0},8,{0x53,0xc7,0x45,0xfc,0,0,0,0}},
        {0x882e9,9,SupHudTransferKind::Current,28,{0x0f,0xb6,0xc0,0x50,0xe8,0x1e,0xf6,0,0},1,{0x50}},
        {0x8854b,9,SupHudTransferKind::Current,28,{0x0f,0xb6,0xc0,0x50,0xe8,0xbc,0xf3,0,0},1,{0x50}}
    };
    bool install(HMODULE module,WideCommandTable* table,Resolver source){
        if(!moduleHasImageRange(module,0xf99c8))return false;
        return installVerified(module,table,source);
    }
#ifdef WIDE_SHOWOFF_RANDOM_TEST
    bool installSynthetic(HMODULE module,WideCommandTable* table,Resolver source){return installVerified(module,table,source);}
    void uninstallSynthetic(){rollback();}
#endif
private:
    bool installVerified(HMODULE module,WideCommandTable* table,Resolver source){
        if(active || !module || !table || !table->getName || !source)return false;
        uint32_t base=uint32_t(module);if(*(uint32_t*)(base+0xf99c4))return false;
        std::array<const WideCommandInfo*,6> infos{};
        for(size_t i=0;i<6;++i){infos[i]=table->getName(commands[i].name);if(!infos[i] || uint32_t(infos[i]->execute)!=base+commands[i].rva)return false;originals[i]=infos[i]->execute;}
        for(auto& s:sites)if(memcmp((void*)(base+s.rva),s.bytes,s.size))return false;
        resolver=source;
        try{
            patches.reserve(10);executable.reserve(4);
            for(size_t i=0;i<4;++i){auto& site=sites[i];auto* memory=(unsigned char*)VirtualAlloc(nullptr,256,MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);if(!memory){rollback();return false;}executable.push_back(memory);
                uint32_t resume=base+site.rva+site.size;
                if(i>=2){auto* landing=memory+128;landing[0]=0xe8;*(uint32_t*)(landing+1)=base+0x97910-uint32_t(landing+5);landing[5]=0xe9;*(uint32_t*)(landing+6)=resume-uint32_t(landing+10);resume=uint32_t(landing);}
                auto code=supHudTransferStub(site,{nullptr,nullptr,nullptr,nullptr,owner},uint32_t(memory),resume,i<2?16:28);
                if(code.size()>=128){rollback();return false;}memcpy(memory,code.data(),code.size());FlushInstructionCache(GetCurrentProcess(),memory,256);
            }
            active=this;
            for(size_t i=0;i<4;++i){auto& site=sites[i];std::vector<unsigned char> jump(site.size,0x90);jump[0]=0xe9;*(uint32_t*)(jump.data()+1)=uint32_t(executable[i])-(base+site.rva+5);patches.emplace_back();if(!patches.back().replace(base+site.rva,site.bytes,jump.data(),site.size)){rollback();return false;}}
            constexpr auto wrapped=callbacks(std::make_index_sequence<6>{});
            for(size_t i=0;i<6;++i){patches.emplace_back();if(!patches.back().replace(uint32_t(&infos[i]->execute),reinterpret_cast<const unsigned char*>(&originals[i]),reinterpret_cast<const unsigned char*>(&wrapped[i]),4)){rollback();return false;}}
            return true;
        }catch(...){rollback();return false;}
    }
};
}
