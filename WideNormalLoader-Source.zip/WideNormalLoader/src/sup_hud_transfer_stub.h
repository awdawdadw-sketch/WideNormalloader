#pragma once
#include "sup_hud_command_sites.h"
#include <vector>
#include <cstring>
#include <stdexcept>
namespace wide {
struct SupHudTransferCallbacks {
    uint32_t (__cdecl* current)();
    uint32_t (__cdecl* trait)(uint32_t,uint32_t);
    uint32_t (__cdecl* visible)(uint32_t);
    uint32_t (__cdecl* reported)(uint32_t);
    uint32_t (__cdecl* currentWithFallback)(uint32_t)=nullptr;
};
// Complete-instruction spans and their relocated tails are pinned to one SUP
// build. Callback execution preserves flags, integer registers and FXSAVE state.
inline std::vector<unsigned char> supHudTransferStub(const SupHudTransferSite& site,
        SupHudTransferCallbacks callbacks,uint32_t address,uint32_t resume,uint32_t fallbackRegister=UINT32_MAX) {
    std::vector<unsigned char> out;
    auto bytes=[&](std::initializer_list<unsigned char> values){out.insert(out.end(),values);};
    auto word=[&](uint32_t value){auto* p=reinterpret_cast<unsigned char*>(&value);out.insert(out.end(),p,p+4);};
    uint32_t callback=0,args=0;
    bytes({0x9c,0x60,0x89,0xe3}); // flags, PUSHAD; EBX points to saved registers
    bytes({0x81,0xec});word(0x220);bytes({0x83,0xe4,0xf0,0x0f,0xae,0x04,0x24});
    switch(site.kind) {
    case SupHudTransferKind::Current:
        if(callbacks.currentWithFallback){
            if(fallbackRegister!=28 && fallbackRegister!=16)throw std::invalid_argument("invalid fallback register");
            bytes({0x83,0xec,0x0c,0xff,0x73,static_cast<unsigned char>(fallbackRegister)});
            callback=uint32_t(callbacks.currentWithFallback);args=4;
        }else callback=uint32_t(callbacks.current);
        break;
    case SupHudTransferKind::BarTrait:
        bytes({0x83,0xec,0x08}); // keep ESP 16-byte aligned at CALL
        bytes({0xff,0xb5});word(uint32_t(-0x4008)); // full explicit owner
        bytes({0x0f,0xb6,0x04,0x0f,0x50}); // byte argument count [EDI+ECX]
        callback=uint32_t(callbacks.trait);args=8;break;
    case SupHudTransferKind::Visible:
        bytes({0x83,0xec,0x0c});
        bytes({0xff,0xb5});word(uint32_t(-0x4008));
        callback=uint32_t(callbacks.visible);args=4;break;
    case SupHudTransferKind::Reported:
        bytes({0x83,0xec,0x0c});
        bytes({0xff,0x76,0x50});callback=uint32_t(callbacks.reported);args=4;break;
    default:throw std::invalid_argument("unknown transfer kind");
    }
    if(!callback || site.tailSize>sizeof(site.tail))throw std::invalid_argument("invalid transfer");
    bytes({0xb8});word(callback);bytes({0xff,0xd0});
    if(args)bytes({0x83,0xc4,0x10});
    if(site.kind!=SupHudTransferKind::Reported) {
        if(site.reg!=28 && site.reg!=24 && site.reg!=20 && site.reg!=16 && site.reg!=4)
            throw std::invalid_argument("invalid output register");
        bytes({0x89,0x43,static_cast<unsigned char>(site.reg)});
        if(site.kind==SupHudTransferKind::BarTrait || site.kind==SupHudTransferKind::Visible)
            bytes({0x89,0x43,0x14}); // selected owner also survives in EDX
    }
    bytes({0x0f,0xae,0x0c,0x24}); // FXRSTOR before overriding reported XMM0
    if(site.kind==SupHudTransferKind::Reported)bytes({0x66,0x0f,0x6e,0xc0});
    bytes({0x89,0xdc,0x61,0x9d});
    out.insert(out.end(),site.tail,site.tail+site.tailSize);
    bytes({0xe9});word(resume-(address+uint32_t(out.size())+4));
    return out;
}
} // namespace wide
