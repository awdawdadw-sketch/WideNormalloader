#pragma once
#include <stdint.h>
namespace wide {
// Preload replaces serialized state. NewGame only cleans unreferenced core
// arrays/strings; referenced objects created during menu startup survive.
inline bool replacesCoreOwnership(uint32_t message){return message==6;}
}
