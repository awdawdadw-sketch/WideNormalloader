#pragma once
#include <windows.h>
#include <tlhelp32.h>
#include <stdint.h>

// Observe first-chance hardware faults without claiming they are unhandled.
// Never swallow the exception or replace another mod's crash handler. Module
// names are cached outside the callback; no heap/CRT/game calls in the callback.
namespace wide { namespace faults {
struct Module { DWORD base,size; char name[MAX_PATH]; };
static Module modules[512]{};
static volatile LONG moduleCount=0,busy=0,eventCount=0,pluginCount=0,adapterMask=0;
static const char* volatile lastStage="loader_initialization";
static HANDLE report=INVALID_HANDLE_VALUE;
static PVOID handler=nullptr;
static wchar_t reportPath[MAX_PATH]{};
static char buffer[16384];
static DWORD stackWords[64];
static unsigned used=0;
static DWORD fileBytes=0;
inline void append(const char* text){if(text)while(*text && used<sizeof(buffer)-1)buffer[used++]=*text++;}
inline void hex(uint32_t value){const char* digits="0123456789ABCDEF";for(int i=7;i>=0;--i)if(used<sizeof(buffer)-1)buffer[used++]=digits[(value>>(i*4))&15];}
inline void field(const char* name,DWORD value){append(name);hex(value);append("\r\n");}
inline bool selected(DWORD code){
    return code==EXCEPTION_ACCESS_VIOLATION || code==EXCEPTION_IN_PAGE_ERROR ||
        code==EXCEPTION_ILLEGAL_INSTRUCTION || code==EXCEPTION_INT_DIVIDE_BY_ZERO ||
        code==EXCEPTION_INT_OVERFLOW || code==EXCEPTION_STACK_OVERFLOW ||
        code==EXCEPTION_PRIV_INSTRUCTION || code==0xC0000374 || code==0xC0000409;
}
inline LONG read(volatile LONG& value){return InterlockedCompareExchange(&value,0,0);}
inline void stage(const char* literal){InterlockedExchangePointer((PVOID volatile*)&lastStage,(PVOID)literal);}
inline void counts(DWORD plugins,DWORD requestedAdapters){InterlockedExchange(&pluginCount,plugins);InterlockedExchange(&adapterMask,requestedAdapters);}
inline int findModule(DWORD address){LONG n=read(moduleCount);for(LONG i=0;i<n;++i)if(address>=modules[i].base && address-modules[i].base<modules[i].size)return i;return -1;}
inline void address(DWORD value){
    hex(value);int i=findModule(value);
    if(i>=0){append(" ");append(modules[i].name);append("+0x");hex(value-modules[i].base);}
    else append(" [outside cached module images; may be generated code or invalid]");
    append("\r\n");
}
inline void refreshModules(){
    // Called on the loader thread only. Publish fully initialized entries and
    // never mutate published entries while a worker may be reporting a fault.
    HANDLE snapshot=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE,GetCurrentProcessId());
    if(snapshot==INVALID_HANDLE_VALUE)return;
    MODULEENTRY32W entry{};entry.dwSize=sizeof(entry);
    if(Module32FirstW(snapshot,&entry))do{
        LONG n=read(moduleCount);bool known=false;
        for(LONG i=0;i<n;++i)if(modules[i].base==(DWORD)(uintptr_t)entry.modBaseAddr){known=true;break;}
        if(!known && n<512){auto& m=modules[n];m.base=(DWORD)(uintptr_t)entry.modBaseAddr;m.size=entry.modBaseSize;
            if(!WideCharToMultiByte(CP_UTF8,0,entry.szExePath,-1,m.name,MAX_PATH,nullptr,nullptr))lstrcpyA(m.name,"[module path exceeds cache capacity]");
            InterlockedExchange(&moduleCount,n+1);
        }
    }while(Module32NextW(snapshot,&entry));
    CloseHandle(snapshot);
}
inline void writeBuffer(){
    // Keep the newest evidence if a mod repeatedly raises handled faults.
    if(fileBytes+used>1024*1024){LARGE_INTEGER zero{};SetFilePointerEx(report,zero,nullptr,FILE_BEGIN);SetEndOfFile(report);fileBytes=0;}
    DWORD written=0;WriteFile(report,buffer,used,&written,nullptr);fileBytes+=written;FlushFileBuffers(report);
}
static LONG CALLBACK observe(EXCEPTION_POINTERS* exception){
    if(!exception || !exception->ExceptionRecord || !exception->ContextRecord ||
       !selected(exception->ExceptionRecord->ExceptionCode) || report==INVALID_HANDLE_VALUE)return EXCEPTION_CONTINUE_SEARCH;
    if(InterlockedCompareExchange(&busy,1,0))return EXCEPTION_CONTINUE_SEARCH;
    const auto& record=*exception->ExceptionRecord;const auto& context=*exception->ContextRecord;
    used=0;append("\r\n=== WideNormalLoader hardware fault observation v1 ===\r\n");
    append("FIRST_CHANCE: may be handled later. Faulting module is not proof of root cause.\r\n");
    field("event_hex=",InterlockedIncrement(&eventCount));field("tick_ms_hex=",GetTickCount());field("thread_id_hex=",GetCurrentThreadId());
    field("exception_code=",record.ExceptionCode);append("exception_address=");address((DWORD)(uintptr_t)record.ExceptionAddress);
    append("last_loader_stage=");append((const char*)InterlockedCompareExchangePointer((PVOID volatile*)&lastStage,nullptr,nullptr));append("\r\n");
    append("Stage is a process-wide breadcrumb, not proof of what this thread was executing. Module names use cached image ranges.\r\n");
    field("selected_plugin_count_hex=",read(pluginCount));field("requested_adapter_mask_hex=",read(adapterMask));
    append("adapter_mask: JIP=1 SUP=2 ShowOff=4 Stewie=8; see loader ACTIVE markers for installation status.\r\n");
    if((record.ExceptionCode==EXCEPTION_ACCESS_VIOLATION || record.ExceptionCode==EXCEPTION_IN_PAGE_ERROR) && record.NumberParameters>=2){
        field("access_kind_0read_1write_8execute=",(DWORD)record.ExceptionInformation[0]);field("access_target=",(DWORD)record.ExceptionInformation[1]);
        if(record.NumberParameters>=3)field("in_page_status=",(DWORD)record.ExceptionInformation[2]);
    }
    field("EAX=",context.Eax);field("EBX=",context.Ebx);field("ECX=",context.Ecx);field("EDX=",context.Edx);
    field("ESI=",context.Esi);field("EDI=",context.Edi);field("EBP=",context.Ebp);field("ESP=",context.Esp);field("EIP=",context.Eip);field("EFLAGS=",context.EFlags);
    SIZE_T got=0;ReadProcessMemory(GetCurrentProcess(),(void*)(uintptr_t)context.Esp,stackWords,sizeof(stackWords),&got);
    append("STACK_WORDS (raw values; module matches are candidates, NOT an unwound call stack):\r\n");
    for(unsigned i=0;i<got/sizeof(DWORD);++i){hex(context.Esp+i*4);append(": ");address(stackWords[i]);}
    append("Compare with WideNormalLoader-preflight.txt, the loader log, and CrashLogger.log.\r\n");
    append("Coverage: after reporter initialization only; concurrent/nested faults may be omitted. Fast termination, hangs and some stack overflows may produce no record.\r\n");
    writeBuffer();InterlockedExchange(&busy,0);return EXCEPTION_CONTINUE_SEARCH;
}
inline void controlledStop(const char* reason){
    if(report==INVALID_HANDLE_VALUE || InterlockedCompareExchange(&busy,1,0))return;
    used=0;append("\r\n=== WideNormalLoader deliberate stop (NOT a hardware exception) ===\r\nreason=");append(reason);append("\r\n");
    field("tick_ms_hex=",GetTickCount());field("thread_id_hex=",GetCurrentThreadId());
    append("last_loader_stage=");append((const char*)InterlockedCompareExchangePointer((PVOID volatile*)&lastStage,nullptr,nullptr));append("\r\n");
    append("See the loader log immediately before FAIL for the failed guard or signature.\r\n");writeBuffer();InterlockedExchange(&busy,0);
}
inline bool openAt(const wchar_t* folder){
    if(!folder || lstrlenW(folder)>MAX_PATH-65)return false;
    lstrcpyW(reportPath,folder);lstrcatW(reportPath,L"\\WideNormalLoader-faults.txt");
    wchar_t previous[MAX_PATH];lstrcpyW(previous,reportPath);lstrcatW(previous,L".previous.txt");
    MoveFileExW(reportPath,previous,MOVEFILE_REPLACE_EXISTING);
    report=CreateFileW(reportPath,GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
    return report!=INVALID_HANDLE_VALUE;
}
inline bool initialize(){
    if(handler)return true;
    wchar_t folder[MAX_PATH];DWORD length=GetModuleFileNameW(nullptr,folder,MAX_PATH);if(!length || length>=MAX_PATH)return false;
    wchar_t* slash=nullptr;for(wchar_t* p=folder;*p;++p)if(*p==L'\\')slash=p;if(!slash)return false;*slash=0;
    if(!openAt(folder)){
        length=GetEnvironmentVariableW(L"LOCALAPPDATA",folder,MAX_PATH);if(!length || length>MAX_PATH-65)return false;
        lstrcatW(folder,L"\\WideNormalLoader");CreateDirectoryW(folder,nullptr);if(!openAt(folder))return false;
    }
    refreshModules();ULONG guarantee=32768;SetThreadStackGuarantee(&guarantee);
    used=0;append("WideNormalLoader fault observer initialized. All numeric fields are hexadecimal.\r\n");
    append("Records first-chance hardware exceptions, including exceptions a mod may recover from.\r\n");
    append("No fault records means no observed fault, not proof that the game did not crash.\r\n");writeBuffer();
    handler=AddVectoredExceptionHandler(1,observe);
    if(!handler){CloseHandle(report);report=INVALID_HANDLE_VALUE;return false;}
    return true;
}
} }
