#pragma once
#include "array_restore_catalog.h"
namespace wide {
class ArrayLoadStream {
    size_t next=0,refNext=0;
    bool active=false,failed=false;
public:
    std::vector<ArrayLoadEntry> entries;
    bool complete()const{return !failed && next==entries.size() && refsComplete();}
    bool refsComplete()const{
        if(!active)return true;
        const auto& refs=entries[next-1].savedRefs;
        for(size_t i=refNext;i<refs.size();++i)if(refs[i]!=255)return false;
        return true;
    }
    size_t consumed()const{return next;}
    bool owner(uint8_t saved,uint8_t& mapped){
        if(failed || !refsComplete() || next>=entries.size() || entries[next].savedOwner!=saved){failed=true;return false;}
        mapped=entries[next++].currentOwner;refNext=0;active=true;return true;
    }
    bool reference(uint32_t id,uint32_t ordinal,uint8_t saved,uint8_t& mapped){
        if(failed || !active){failed=true;return false;}
        const auto& entry=entries[next-1];
        while(refNext<entry.savedRefs.size() && entry.savedRefs[refNext]==255)++refNext;
        if(entry.id!=id || ordinal!=refNext || ordinal>=entry.savedRefs.size() || entry.savedRefs[ordinal]!=saved || saved==255){failed=true;return false;}
        mapped=entry.currentRefs[ordinal];refNext=ordinal+1;return true;
    }
};
}
