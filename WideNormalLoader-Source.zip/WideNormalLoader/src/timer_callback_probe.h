#pragma once
// Local diagnostic. Compiled handlers are session-owned; no disk forms change.
struct TimerCallbackProbeState {
    void* handlers[2][3]{}; bool registered[2][3]{};
    uint32_t slots[2]{},hits[2][3]{},savedUpdates=0,phase=0,started=0,registrationLoops=0;
    bool active=false,passed=true;
};
static TimerCallbackProbeState& timerCallbackProbeState(){static TimerCallbackProbeState s;return s;}
static bool recordTimerCallback(unsigned owner,unsigned event,void* script,double* result){
    auto& s=timerCallbackProbeState();uint32_t actual=0;
    bool ok=s.active && script==s.handlers[owner][event] && supScriptOwner(script,actual) && actual==s.slots[owner]+3;
    if(ok)++s.hits[owner][event];else s.passed=false;
    if(!ok || event!=2 || s.hits[owner][event]==1){fprintf(logFile,"WIDE_TIMER_CALLBACK_HIT owner=%u event=%u slot=%u full_owner=%u count=%u verified=%u\n",owner,event,s.slots[owner],actual,s.hits[owner][event],ok);fflush(logFile);}
    *result=ok?1:0;return true;
}
static bool routeTimerCallbackProbe(void* script,double* result){
    auto& s=timerCallbackProbeState();
    for(unsigned o=0;o<2;++o)for(unsigned e=0;e<3;++e)
        if(script && script==s.handlers[o][e])return recordTimerCallback(o,e,script,result);
    return false;
}
static bool registerTimerCallback(unsigned owner,unsigned event,bool add){
    auto& s=timerCallbackProbeState();const char* events[]={"Start","Stop","Update"};
    char text[192];snprintf(text,sizeof(text),"SetOnAuxTimer%sHandler %u WidePersistentArrayScriptA \"*WideCallbackProbe\"",events[event],add?1:0);
    void* registration=supProbeApi->expression(text);if(!registration)return false;
    void* placeholder=lookup(fixtureFormHandle(saveFixtureSlot(0),0xd00));if(!placeholder)return false;
    struct Ref{void* name;uint16_t length,capacity;void* form;uint32_t varIndex;};
    static_assert(sizeof(Ref)==16,"Script::RefVariable");
    MasterNode node{},*cursor=(MasterNode*)((char*)registration+0x44);Ref* matched=nullptr;bool ended=false;
    for(unsigned n=0;cursor && n<64;++n){SIZE_T got=0;
        if(!ReadProcessMemory(GetCurrentProcess(),cursor,&node,sizeof(node),&got) || got!=sizeof(node))return false;
        if(node.data){Ref ref{};if(!ReadProcessMemory(GetCurrentProcess(),node.data,&ref,sizeof(ref),&got) || got!=sizeof(ref))return false;
            if(ref.form==placeholder && !ref.varIndex){if(matched)return false;matched=(Ref*)node.data;}}
        cursor=(MasterNode*)node.next;if(!cursor){ended=true;break;}
    }
    if(!ended || !matched)return false;
    // Replace only this freshly compiled diagnostic's verified static reference.
    // Native registration retains the handler pointer, not the reference node.
    struct Restore{Ref* ref;void* saved;~Restore(){ref->form=saved;}}restore{matched,matched->form};
    matched->form=s.handlers[owner][event];SupProbeElement output{};
    bool called=supProbeApi->call(registration,*(void**)0x11DEA3C,nullptr,&output,0);
    fprintf(logFile,"WIDE_TIMER_CALLBACK_REGISTER owner=%u event=%u add=%u called=%u\n",owner,event,add,called);fflush(logFile);return called;
}
static bool timerCallbackExpression(unsigned owner,const char* expression){double value=0;return jipMapProbeExpression(timerCallbackProbeState().slots[owner],expression,value,"WIDE_TIMER_CALLBACK");}
static void finishTimerCallbackProbe(){
    auto& s=timerCallbackProbeState();
    for(unsigned o=0;o<2;++o){s.passed=timerCallbackExpression(o,"AuxTimerStop \"*WideCallbackProbe\" 0") && s.passed;
        for(unsigned e=0;e<3;++e)if(s.registered[o][e]){bool ok=registerTimerCallback(o,e,false);s.passed=ok && s.passed;if(ok)s.registered[o][e]=false;}}
    fprintf(logFile,"WIDE_TIMER_CALLBACK_COMPLETE passed=%u A=%u,%u,%u B=%u,%u,%u scope=private_start_expiry_update_autorestart_no_save_changes\n",s.passed,s.hits[0][0],s.hits[0][1],s.hits[0][2],s.hits[1][0],s.hits[1][1],s.hits[1][2]);fflush(logFile);s.active=false;
}
static void startTimerCallbackProbe();
static void beginRegisteredTimerCallbackProbe();
static void advanceTimerCallbackProbe(){
    auto& s=timerCallbackProbeState();if(!s.active)return;
    // The console execution context must unwind before any nested compiler call.
    // Improved Console owns console declarations; xNVSE supplies borrowed text.
    if(s.phase==0){if(GetTickCount()-s.started>=1000)startTimerCallbackProbe();return;}
    // ShowOff's native RegisterEvent appends to EventQueueAdd. Its own game-loop
    // listener must publish that queue before synchronous start/stop tests.
    if(s.phase==4){++s.registrationLoops;if(s.registrationLoops>=2 && GetTickCount()-s.started>=1000)beginRegisteredTimerCallbackProbe();return;}
    if(GetTickCount()-s.started<6000)return;
    if(s.phase==1){bool ok=s.hits[0][0]==2 && s.hits[0][1]==2 && s.hits[0][2]>0 && s.hits[1][0]==1 && s.hits[1][1]==0 && s.hits[1][2]==0;
        s.passed=ok && s.passed;s.savedUpdates=s.hits[0][2];
        fprintf(logFile,"WIDE_TIMER_CALLBACK_PHASE phase=A_expiry passed=%u\n",ok);
        s.passed=timerCallbackExpression(1,"AuxTimerStart \"*WideCallbackProbe\" 2 263") && s.passed;s.phase=2;
    }else if(s.phase==2){bool ok=s.hits[0][0]==2 && s.hits[0][1]==2 && s.hits[0][2]==s.savedUpdates && s.hits[1][0]==2 && s.hits[1][1]==1 && s.hits[1][2]>0;
        s.passed=ok && s.passed;s.savedUpdates=s.hits[1][2];
        fprintf(logFile,"WIDE_TIMER_CALLBACK_PHASE phase=B_expiry passed=%u\n",ok);
        s.passed=timerCallbackExpression(0,"AuxTimerStart \"*WideCallbackProbe\" 1 279") && s.passed;s.phase=3;
    }else{bool ok=s.hits[0][0]>=4 && s.hits[0][1]>=3 && s.hits[1][0]==2 && s.hits[1][1]==1 && s.hits[1][2]==s.savedUpdates;
        s.passed=ok && s.passed;fprintf(logFile,"WIDE_TIMER_CALLBACK_PHASE phase=A_autorestart passed=%u\n",ok);finishTimerCallbackProbe();}
    s.started=GetTickCount();fflush(logFile);
}
static void startTimerCallbackProbe(){
    auto& s=timerCallbackProbeState();
    fputs("WIDE_TIMER_CALLBACK_BEGIN phase=compile_register context=deferred_game_loop\n",logFile);fflush(logFile);
    auto compile=(void*(__cdecl*)(const char*))supProbeApi->compile;
    for(unsigned o=0;o<2;++o)for(unsigned e=0;e<3;++e){char source[320];
        snprintf(source,sizeof(source),"string_var timerName\nref subject\n%sbegin function {timerName subject%s}\nWideTestCompatibility\nend\n",e==2?"float delta\n":"",e==2?" delta":"");
        fprintf(logFile,"WIDE_TIMER_CALLBACK_COMPILE owner=%u event=%u\n",o,e);fflush(logFile);
        void* handler=compile(source);if(!handler){s.passed=false;finishTimerCallbackProbe();return;}
        *(MasterNode*)((char*)handler+0x10)={loadedFiles[s.slots[o]],nullptr};s.handlers[o][e]=handler;uint32_t common=0;
        if(!supScriptOwner(handler,common) || common!=s.slots[o]+3 || !registerTimerCallback(o,e,true)){s.passed=false;finishTimerCallbackProbe();return;}s.registered[o][e]=true;
    }
    s.phase=4;s.started=GetTickCount();s.registrationLoops=0;
    fputs("WIDE_TIMER_CALLBACK_REGISTRATION_PENDING activation=native_event_queue_next_frames\n",logFile);fflush(logFile);
}
static void beginRegisteredTimerCallbackProbe(){
    auto& s=timerCallbackProbeState();
    fprintf(logFile,"WIDE_TIMER_CALLBACK_REGISTRATION_WAIT_COMPLETE loops=%u elapsed_ms=%u\n",s.registrationLoops,uint32_t(GetTickCount()-s.started));fflush(logFile);
    s.passed=timerCallbackExpression(0,"AuxTimerStart \"*WideCallbackProbe\" 2 295") && s.passed;
    s.passed=s.hits[0][0]==1 && s.hits[1][0]==0 && s.passed;
    s.passed=timerCallbackExpression(1,"AuxTimerStart \"*WideCallbackProbe\" 2 295") && s.passed;
    s.passed=s.hits[0][0]==1 && s.hits[1][0]==1 && s.passed;
    s.passed=timerCallbackExpression(0,"AuxTimerStop \"*WideCallbackProbe\" 1") && s.passed;
    s.passed=s.hits[0][1]==1 && s.hits[1][1]==0 && s.passed;
    s.passed=timerCallbackExpression(0,"AuxTimerStart \"*WideCallbackProbe\" 2 263") && s.passed;
    s.phase=1;s.started=GetTickCount();fprintf(logFile,"WIDE_TIMER_CALLBACK_PENDING immediate_checks=%u duration_seconds=18\n",s.passed);fflush(logFile);
}
static bool __cdecl probeTimerCallbacks(WIDE_COMMAND_ARGS){
    *result=0;auto& s=timerCallbackProbeState();
    if(!ready || !timerRuntimeInstalled || !supProbeApi || !supProbeApi->compile || s.active)return true;
    for(auto& group:s.registered)for(bool registered:group)if(registered)return true;
    s=TimerCallbackProbeState{};s.slots[0]=saveFixtureSlot(0);s.slots[1]=saveFixtureSlot(1);
    if(s.slots[0]<253 || s.slots[1]<253 || s.slots[0]>=loadedCount || s.slots[1]>=loadedCount)return true;
    // Queue only. Compile, registration and command execution occur later.
    s.active=true;s.started=GetTickCount();
    fputs("WIDE_TIMER_CALLBACK_QUEUED setup=next_game_loop_after_console_unwinds\n",logFile);fflush(logFile);*result=1;return true;
}
