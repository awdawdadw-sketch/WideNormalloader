#pragma once
#include "jip_build_profile.h"
#include "module_sha256.h"
#include "runtime_patch.h"
#include "plugin_owner_scope.h"
#include "jip_private_map_sites.h"
#include "jip_pp_private_map_sites.h"
#include <vector>
namespace wide {
// Only the aux/ref-map call sites are changed. The shared byte getter and
// byte-owned added-variable/linked-reference producers remain separate work.
class JipPrivateMapsRuntime {
    using Resolver=bool(*)(void*,uint32_t&);
    inline static JipPrivateMapsRuntime* active=nullptr;
    Resolver resolver=nullptr;
    std::vector<RuntimePatch> patches;
    std::vector<void*> code;
    static uint32_t __cdecl fullOwner(void* script){
        uint32_t owner=UINT32_MAX;
        try{if(active && active->resolver(script,owner) && PluginOwnerScope::valid(owner))return owner;}catch(...){}
        // Outside the valid namespace, rather than aliasing a valid private or
        // public owner. Loader registry validation excludes this in normal use.
        return UINT32_MAX;
    }
    void rollback(){for(auto p=patches.rbegin();p!=patches.rend();++p)p->restore();for(auto* p:code)VirtualFree(p,0,MEM_RELEASE);patches.clear();code.clear();if(active==this)active=nullptr;}
public:
    // Captures the actual thiscall script in ECX. This also covers quest-script
    // ownership in AuxVarGetFltCond without assuming an Execute-command scope.
    static std::vector<unsigned char> ownerStub(uint32_t address,uint32_t resume,uint32_t callback){
        std::vector<unsigned char> out;
        auto b=[&](std::initializer_list<unsigned char> v){out.insert(out.end(),v);};
        auto w=[&](uint32_t v){auto* p=(unsigned char*)&v;out.insert(out.end(),p,p+4);};
        b({0x9c,0x60,0x89,0xe3,0x81,0xec});w(0x220);
        b({0x83,0xe4,0xf0,0x0f,0xae,0x04,0x24,0x83,0xec,0x0c,0xff,0x73,0x18,0xb8});w(callback);
        b({0xff,0xd0,0x83,0xc4,0x10,0x89,0x43,0x1c,0x0f,0xae,0x0c,0x24,0x89,0xdc,0x61,0x9d,0xe9});
        w(resume-address-uint32_t(out.size())-4);return out;
    }
    bool install(HMODULE module,WideCommandTable* table,Resolver source){
        if(!moduleHasImageRange(module,jipRva(0x6a364)))return false;
        return installVerified(module,table,source);
    }
#ifdef WIDE_JIP_PRIVATE_MAP_TEST
    bool installSynthetic(HMODULE module,WideCommandTable* table,Resolver source){return installVerified(module,table,source);}
    void uninstallSynthetic(){rollback();}
#endif
private:
    bool installVerified(HMODULE module,WideCommandTable* table,Resolver source){
        if(active || !module || !table || !table->getName || !source)return false;
        uint32_t base=uint32_t(module);
        // Permanent and temporary map entry counts must all be empty at install.
        for(uint32_t legacyCount:{0x6a30cu,0x6a318u,0x6a354u,0x6a360u})if(*(uint32_t*)(base+jipRva(legacyCount)))return false;
        for(auto& s:(jipBuild==JipBuild::PPLN?jipPPMapCommands:jipMapCommands)){auto* info=table->getName(s.name);if(!info || uint32_t(info->execute)!=base+s.entry)return false;}
        auto* condition=table->getName("AuxVarGetFltCond");if(!condition || uint32_t(condition->eval)!=base+jipRva(jipMapConditionEval))return false;
        for(auto& s:(jipBuild==JipBuild::PPLN?jipPPMapOwnerSites:jipMapOwnerSites))if(memcmp((void*)(base+s.call),s.callBytes,5) || memcmp((void*)(base+s.narrow),s.narrowBytes,3))return false;
        resolver=source;
        try{
            patches.reserve(42);code.reserve(21);
            for(auto& s:(jipBuild==JipBuild::PPLN?jipPPMapOwnerSites:jipMapOwnerSites)){auto* memory=(unsigned char*)VirtualAlloc(nullptr,128,MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);if(!memory){rollback();return false;}code.push_back(memory);
                auto bytes=ownerStub(uint32_t(memory),base+s.call+5,uint32_t(fullOwner));if(bytes.size()>128){rollback();return false;}
                memcpy(memory,bytes.data(),bytes.size());FlushInstructionCache(GetCurrentProcess(),memory,128);
            }
            active=this;size_t i=0;
            for(auto& s:(jipBuild==JipBuild::PPLN?jipPPMapOwnerSites:jipMapOwnerSites)){unsigned char jump[5]={0xe9};*(uint32_t*)(jump+1)=uint32_t(code[i++])-base-s.call-5;
                patches.emplace_back();if(!patches.back().replace(base+s.call,s.callBytes,jump,5)){rollback();return false;}
                patches.emplace_back();if(!patches.back().replace(base+s.narrow,s.narrowBytes,s.replacement,3)){rollback();return false;}
            }
            return true;
        }catch(...){rollback();return false;}
    }
};
}
