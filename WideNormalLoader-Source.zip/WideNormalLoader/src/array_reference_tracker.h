#pragma once
#include <stdint.h>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <algorithm>
namespace wide {
struct TrackedArrayReference {
    uint32_t array,slot;uint8_t nativeByte;bool known;
};
struct ArrayReferenceCoverage {
    uint32_t known=0,unknown=0;bool byteCountsMatch=false,lifecycleComplete=false;
    std::unordered_map<uint32_t,uint32_t> fullSlots;
};
struct ArrayReferenceIssue {uint32_t firstCaller=0,lastCaller=0,overwrites=0,divergences=0;std::unordered_map<uint32_t,std::pair<uint32_t,uint32_t>> callers;};
struct ImportedArrayReference {uint32_t slot;uint8_t nativeByte;uint32_t count;};
class ArrayReferenceTracker {
    // Logical storage identity, not native byte-vector position. Double
    // wrappers use the original double address, never their stack temporary.
    std::unordered_map<uint64_t,TrackedArrayReference> refs;
    // Validated saved references have no stable runtime holder addresses.
    // Keep their provenance separately until a known native removal occurs.
    std::unordered_map<uint32_t,std::vector<ImportedArrayReference>> imports;
    bool overflowed=false;
    std::unordered_set<uint32_t> incomplete;
    uint32_t divergentRemoves=0,overwrittenBindings=0;
    std::unordered_map<uint32_t,ArrayReferenceIssue> issueDetails;
    void issue(uint32_t id,uint32_t caller,bool overwrite){
        if(!id)return;incomplete.insert(id);
        auto& detail=issueDetails[id];if(!detail.overwrites && !detail.divergences)detail.firstCaller=caller;
        detail.lastCaller=caller;auto& cause=detail.callers[caller];if(overwrite){++detail.overwrites;++cause.first;}else{++detail.divergences;++cause.second;}
    }
public:
    static uint64_t storage(uint32_t address,bool isDouble){return (uint64_t(address)<<1)|uint64_t(isDouble);}
    void clear(){refs.clear();imports.clear();incomplete.clear();issueDetails.clear();overflowed=false;divergentRemoves=overwrittenBindings=0;}
    void allocated(uint32_t id){imports.erase(id);incomplete.erase(id);issueDetails.erase(id);for(auto it=refs.begin();it!=refs.end();)if(it->second.array==id)it=refs.erase(it);else ++it;}
    bool importReferences(uint32_t id,const std::vector<ImportedArrayReference>& values){
        if(!id || overflowed || incomplete.count(id) || imports.count(id))return false;
        for(const auto& row:refs)if(row.second.array==id)return false;
        uint32_t count=0;std::unordered_set<uint32_t> groups;
        for(const auto& ref:values){if(!ref.count || ref.count>=0x4000 || ref.slot>=1024 || (ref.nativeByte<253?ref.slot!=ref.nativeByte:ref.slot<253 || ref.nativeByte==255) || !groups.insert((ref.slot<<8)|ref.nativeByte).second)return false;count+=ref.count;if(count>=0x4000)return false;}
        if(!values.empty())imports.emplace(id,values);return true;
    }
    std::vector<ImportedArrayReference> imported(uint32_t id)const{auto it=imports.find(id);return it==imports.end()?std::vector<ImportedArrayReference>{}:it->second;}
    uint32_t divergences()const{return divergentRemoves;}
    uint32_t overwrites()const{return overwrittenBindings;}
    uint32_t incompleteArrays()const{return (uint32_t)incomplete.size();}
    void poison(){overflowed=true;}
    std::vector<std::pair<uint32_t,ArrayReferenceIssue>> issues()const{return {issueDetails.begin(),issueDetails.end()};}
    std::vector<std::pair<uint64_t,TrackedArrayReference>> bindings(uint32_t id)const{std::vector<std::pair<uint64_t,TrackedArrayReference>> out;for(auto& row:refs)if(row.second.array==id)out.push_back(row);return out;}
    using BlockBindings=std::vector<std::pair<uint64_t,TrackedArrayReference>>;
    BlockBindings blockBindings(uint32_t address,uint32_t bytes)const{
        BlockBindings out;uint64_t end=uint64_t(address)+bytes;
        for(const auto& row:refs){auto at=row.first>>1;if(at>=address && at<end)out.push_back(row);}return out;
    }
    bool relocateBlock(const BlockBindings& plan,uint32_t oldAddress,uint32_t newAddress,uint32_t bytes,uint32_t caller=0,bool copiedValuesMatch=true){
        auto reject=[&](){for(const auto& row:plan)issue(row.second.array,caller,false);return false;};
        if(!oldAddress || !newAddress || uint64_t(oldAddress)+bytes>0x100000000ull || uint64_t(newAddress)+bytes>0x100000000ull || !copiedValuesMatch)return reject();
        std::unordered_set<uint64_t> sourceKeys;
        for(const auto& row:plan){auto at=row.first>>1;auto width=(row.first&1)?8u:4u;
            if(at<oldAddress || at+width>uint64_t(oldAddress)+bytes || !sourceKeys.insert(row.first).second)return reject();
            auto current=refs.find(row.first);
            if(current==refs.end() || current->second.array!=row.second.array || current->second.slot!=row.second.slot || current->second.nativeByte!=row.second.nativeByte || current->second.known!=row.second.known)return reject();
        }
        for(const auto& row:plan){uint64_t target=storage(newAddress+uint32_t((row.first>>1)-oldAddress),row.first&1);
            auto current=refs.find(target);if(current!=refs.end() && !sourceKeys.count(target)){issue(current->second.array,caller,false);return reject();}
        }
        auto relocated=refs;
        for(const auto& row:plan)relocated.erase(row.first);
        for(const auto& row:plan)relocated.emplace(storage(newAddress+uint32_t((row.first>>1)-oldAddress),row.first&1),row.second);
        refs.swap(relocated);
        return true;
    }
    bool find(uint64_t key,TrackedArrayReference& value)const{auto it=refs.find(key);if(it==refs.end())return false;value=it->second;return true;}
    void added(uint64_t key,uint32_t array,uint8_t byte,bool known,uint32_t slot,uint32_t caller=0){
        auto old=refs.find(key);
        if(old!=refs.end()){
            if(old->second.array!=array){issue(old->second.array,caller,true);++overwrittenBindings;}
            refs.erase(old);
        }
        if(!key || !array)return;
        if(refs.size()>=1048576){overflowed=true;return;}
        known=known && slot<1024 && (byte<253?slot==byte:slot>=253 && byte!=255);
        refs[key]={array,known?slot:UINT32_MAX,byte,known};
    }
    bool moved(uint64_t source,uint64_t destination,uint32_t array,uint32_t caller=0){
        if(source==destination)return true;
        auto old=refs.find(source);if(old==refs.end())return false;
        if(old->second.array!=array){issue(old->second.array,caller,false);issue(array,caller,false);return false;}
        auto value=old->second;refs.erase(old);
        auto target=refs.find(destination);
        if(target!=refs.end()){issue(target->second.array,caller,true);++overwrittenBindings;refs.erase(target);}
        refs[destination]=value;return true;
    }
    void removed(uint64_t key,uint32_t array,uint32_t caller=0,bool known=false,uint32_t slot=UINT32_MAX,uint8_t nativeByte=255){
        auto it=refs.find(key);
        if(it!=refs.end()){
            if(it->second.array!=array){issue(it->second.array,caller,false);if(array)issue(array,caller,false);++divergentRemoves;}
            refs.erase(it);
        }else {
            auto imported=imports.find(array);if(imported==imports.end())return;
            if(nativeByte<253){slot=nativeByte;known=true;}
            auto& values=imported->second;
            auto ref=std::find_if(values.begin(),values.end(),[&](const auto& value){return known && value.slot==slot && value.nativeByte==nativeByte;});
            if(ref==values.end()){issue(array,caller,false);++divergentRemoves;return;}
            if(!--ref->count)values.erase(ref);
            if(values.empty())imports.erase(imported);
        }
    }
    ArrayReferenceCoverage coverage(uint32_t array,const std::vector<uint8_t>& native)const{
        ArrayReferenceCoverage out;uint32_t observed[256]{},expected[256]{};
        for(auto byte:native)++expected[byte];
        for(auto& entry:refs)if(entry.second.array==array){auto& ref=entry.second;++observed[ref.nativeByte];if(ref.known){++out.known;++out.fullSlots[ref.slot];}else ++out.unknown;}
        auto loaded=imports.find(array);if(loaded!=imports.end())for(const auto& ref:loaded->second){observed[ref.nativeByte]+=ref.count;out.known+=ref.count;out.fullSlots[ref.slot]+=ref.count;}
        out.lifecycleComplete=!overflowed && !incomplete.count(array);
        out.byteCountsMatch=true;
        for(uint32_t i=0;i<256;++i)if(observed[i]!=expected[i])out.byteCountsMatch=false;
        return out;
    }
};
}
