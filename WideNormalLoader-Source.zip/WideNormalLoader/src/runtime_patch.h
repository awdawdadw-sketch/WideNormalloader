#pragma once
#include <windows.h>
#include <stdint.h>
#include <string.h>
#include <vector>
// Only complete, position-independent stolen instructions may be supplied.
// Validate every site before writing any of a batch. Roll back on failure.
struct RuntimePatch {
    uint32_t address=0;std::vector<unsigned char> original;void* trampoline=nullptr;
    static bool write(uint32_t at,const unsigned char* bytes,uint32_t n) {
        DWORD old=0;if(!VirtualProtect((void*)at,n,PAGE_EXECUTE_READWRITE,&old))return false;
        memcpy((void*)at,bytes,n);DWORD ignored=0;
        bool ok=VirtualProtect((void*)at,n,old,&ignored)!=0;
        FlushInstructionCache(GetCurrentProcess(),(void*)at,n);return ok;
    }
    bool replace(uint32_t at,const unsigned char* expected,const unsigned char* bytes,uint32_t n) {
        if(memcmp((void*)at,expected,n))return false;
        address=at;original.assign(expected,expected+n);return write(at,bytes,n);
    }
    bool hook(uint32_t at,const unsigned char* expected,uint32_t n,void* callback) {
        if(n<5 || memcmp((void*)at,expected,n))return false;
        trampoline=VirtualAlloc(nullptr,n+5,MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);
        if(!trampoline)return false;
        auto* t=(unsigned char*)trampoline;memcpy(t,expected,n);t[n]=0xE9;
        *(uint32_t*)(t+n+1)=at+n-(uint32_t)(t+n+5);
        FlushInstructionCache(GetCurrentProcess(),t,n+5);
        std::vector<unsigned char> patch(n,0x90);patch[0]=0xE9;
        *(uint32_t*)(patch.data()+1)=(uint32_t)callback-at-5;
        return replace(at,expected,patch.data(),n);
    }
    void restore() { if(address && !original.empty())write(address,original.data(),(uint32_t)original.size()); }
};
