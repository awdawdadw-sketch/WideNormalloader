#pragma once
#include <windows.h>
#include <algorithm>
#include "module_sha256.h"
#include "save_identity_codec.h"
namespace wide {
struct NvseStringState {uint32_t id,length,crc;uint8_t owner,temporary,cache;};
class NvseStringSnapshot {
    uint32_t base=0;const char*(__cdecl* get)(uint32_t)=nullptr;
    template<class T> static T read(uint32_t p){T v{};SIZE_T n=0;if(!p || !ReadProcessMemory(GetCurrentProcess(),(void*)p,&v,sizeof(v),&n) || n!=sizeof(v))throw "string_snapshot_unreadable";return v;}
    struct Lock {
        uint32_t base;
        explicit Lock(uint32_t b):base(b){((void(__thiscall*)(void*))(base+0x3D10))((void*)(base+0x1452C8));}
        ~Lock(){auto* count=(volatile uint32_t*)(base+0x1452CC);if(--*count==0)*(volatile uint32_t*)(base+0x1452C8)=0;}
    };
public:
    bool bind(HMODULE module,const char*(__cdecl* getter)(uint32_t),void* setter,void* creator){
        if(!moduleMatchesSha256(module,"e82c5d348bac255a8ff4cf477df2e48149304b18f02b42b2a835c3cba71f3dfb"))return false;
        uint32_t b=(uint32_t)module;
        if((uint32_t)getter!=b+0xD4EA0 || (uint32_t)setter!=b+0xD4EC0 || (uint32_t)creator!=b+0xD4EF0)return false;
        base=b;get=getter;return true;
    }
#ifdef WIDE_NVSE_STRING_SNAPSHOT_TEST
    void bindSynthetic(uint32_t module,const char*(__cdecl* getter)(uint32_t)){base=module;get=getter;}
#endif
    bool snapshot(std::vector<NvseStringState>& output){
        if(!base || !get)return false;
        try{
            Lock guard(base);uint32_t buckets=read<uint32_t>(base+0x145290),capacity=read<uint32_t>(base+0x145294),count=read<uint32_t>(base+0x145298);
            if(!capacity || (capacity&(capacity-1)) || capacity>1048576 || count>1048576 || (count && !buckets))return false;
            uint32_t tempData=read<uint32_t>(base+0x1452A8),tempCount=read<uint32_t>(base+0x1452AC),tempCapacity=read<uint32_t>(base+0x1452B0);
            if(tempCount>tempCapacity || tempCount>1048576 || (tempCount && !tempData))return false;
            std::unordered_set<uint32_t> temporary;
            for(uint32_t i=0;i<tempCount;++i)if(!temporary.insert(read<uint32_t>(tempData+i*4)).second)return false;
            std::unordered_set<uint32_t> nodes,ids;std::vector<NvseStringState> values;
            if(buckets)for(uint32_t i=0;i<capacity;++i){uint32_t node=read<uint32_t>(buckets+i*4);
                while(node){
                    if(nodes.size()>=count || !nodes.insert(node).second)return false;
                    uint32_t next=read<uint32_t>(node),id=read<uint32_t>(node+4),object=node+8;
                    if(!id || !ids.insert(id).second)return false;
                    uint32_t length=read<uint32_t>(object+0x10),allocation=read<uint32_t>(object+0x14);
                    if(length>65535 || length>allocation)return false;
                    uint32_t chars=allocation>15?read<uint32_t>(object):object;
                    if((uint32_t)get(id)!=chars)return false; // Validate the inferred layout against the public API.
                    std::vector<unsigned char> text(length);SIZE_T got=0;
                    if(length && (!ReadProcessMemory(GetCurrentProcess(),(void*)chars,text.data(),length,&got) || got!=length))return false;
                    if(read<char>(chars+length)!=0)return false;
                    values.push_back({id,length,identityCrc(text.data(),text.size()),read<uint8_t>(object+0x18),(uint8_t)temporary.count(id),read<uint8_t>(object+0x19)});
                    node=next;
                }
            }
            if(nodes.size()!=count)return false;
            output=std::move(values);return true;
        }catch(...){return false;}
    }
};
}
