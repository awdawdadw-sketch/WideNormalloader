#pragma once
#include <stdint.h>
#include <cstring>
namespace wide {
enum class JipBuild { Original, PPLN };
inline JipBuild jipBuild=JipBuild::Original;
inline constexpr const char* jipOriginalHash="9d2779647ed0ce63043390f47fc978e3234af8e558dc6cb6bcb231478a2d74d4";
inline constexpr const char* jipPPHash="348c834fafd8af7b081fef20aef3d8c38308fbaaee6573ef17d84b5c3863ba2b";
inline const char* jipBuildName(){return jipBuild==JipBuild::PPLN?"JIP PP LN 57.54":"JIP LN original";}
inline bool jipSupportedHash(const char* hash){return hash && (!std::strcmp(hash,jipOriginalHash) || !std::strcmp(hash,jipPPHash));}
// Exact audited RVA mapping. No nearest-symbol guess is used at runtime.
inline uint32_t jipRva(uint32_t original){
    if(jipBuild==JipBuild::Original)return original;
    switch(original){
    case 0x20b0:return 0x2210;
    case 0x2530:return 0x2690;
    case 0x3610:return 0x36d0;
    case 0x3c80:return 0x3d10;
    case 0x3d80:return 0x3e10;
    case 0x5540:return 0x5590;
    case 0x7810:return 0x8020;
    case 0x160d0:return 0x184f0;
    case 0x1e030:return 0x20450;
    case 0x28dd0:return 0x2fdb0;
    case 0x34d70:return 0x3d110;
    case 0x34d90:return 0x3d130;
    case 0x34e31:return 0x3d1d1;
    case 0x34e36:return 0x3d1d6;
    case 0x34e76:return 0x3d216;
    case 0x50950:return 0x59e30;
    case 0x50a10:return 0x59ef0;
    case 0x50c10:return 0x5a4e0;
    case 0x50d30:return 0x5a600;
    case 0x573d0:return 0x63a90;
    case 0x6a2d4:return 0x7c2fc;
    case 0x6a2dc:return 0x7c304;
    case 0x6a2e0:return 0x7c308;
    case 0x6a2f8:return 0x7c320;
    case 0x6a304:return 0x7c32c;
    case 0x6a30c:return 0x7c334;
    case 0x6a318:return 0x7c340;
    case 0x6a31c:return 0x7c344;
    case 0x6a324:return 0x7c34c;
    case 0x6a328:return 0x7c350;
    case 0x6a34c:return 0x7c374;
    case 0x6a354:return 0x7c37c;
    case 0x6a360:return 0x7c388;
    case 0x6a364:return 0x7c38c;
    case 0x7637a:return 0x8895a;
    case 0x7637b:return 0x8895b;
    case 0x76390:return 0x88970;
    case 0x764f0:return 0x88ad0;
    case 0x77218:return 0x897ec;
    case 0x77224:return 0x897f8;
    default:return 0; // Unknown PP address: must never be used by an adapter.
    }
}
}
