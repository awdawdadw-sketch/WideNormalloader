#pragma once
#include "sup_hud_bridge.h"
#include "sup_hud_identity.h"
#include "sup_hud_entry_sites.h"
#include "sup_hud_transfer_stub.h"
#include "module_sha256.h"
#include "runtime_patch.h"
#include <memory>
#include <utility>
// Included after nvse_commands.h. All foreign entry points use the pinned x86
// ABI; no C++ object from this DLL crosses the SUP boundary.
namespace wide {
class SupHudRuntime {
public:
    using ScriptOwner=bool(*)(void*,uint32_t&);
private:
    inline static SupHudRuntime* active=nullptr;
    uint32_t base=0,size=0;
    ScriptOwner sourceOwner=nullptr;
    SupFilenameLookup filenames=nullptr;
    void* filenameContext=nullptr;
    std::unique_ptr<SupHudBridge> bridge;
    std::vector<RuntimePatch> patches;
    std::vector<void*> executable;
    std::array<CommandExecute,sizeof(supHudCommands)/sizeof(*supHudCommands)> originals{};
    struct Creation {
        Creation* previous;
        std::string identifier;
        inline static thread_local Creation* current=nullptr;
        explicit Creation(std::string name):previous(current),identifier(std::move(name)){current=this;}
        ~Creation(){current=previous;}
    };
    static SupCallOrigin origin(void* caller){auto address=uint32_t(caller);return address>=active->base && address-active->base<active->size ? SupCallOrigin::InternalToken:SupCallOrigin::NativeApi;}
    static uint32_t __cdecl current(){uint32_t token=UINT32_MAX;SupHudCommandScope::currentToken(token);return token;}
    static uint32_t __cdecl trait(uint32_t count,uint32_t explicitOwner){uint32_t token=UINT32_MAX;try{active->bridge->barTraitOwner(current(),uint8_t(count),explicitOwner,token);}catch(...){}return token;}
    static uint32_t __cdecl visible(uint32_t explicitOwner){uint32_t token=UINT32_MAX;try{active->bridge->visibleOwner(current(),explicitOwner,token);}catch(...){}return token;}
    static uint32_t __cdecl reported(uint32_t token){int32_t value=-1;SupOwnerKind kind{};try{active->bridge->reportedOwner(token,value,kind);}catch(...){}return uint32_t(value);}
    static const char* __fastcall ownerName(uint32_t token){
        try{SupOwnerKey key{};if(!active->bridge->identity(token,key))return "";
        auto* name=supHudOwnerName(key,active->filenames,active->filenameContext);return name?name:"";}catch(...){return "";}
    }
    static int __cdecl formatName(char* output,const char*,const char*,int32_t){
        auto* frame=Creation::current;
        if(!frame || !output)return -1;
        memcpy(output,frame->identifier.c_str(),frame->identifier.size()+1);
        return int(frame->identifier.size());
    }
    __attribute__((noinline)) static bool __cdecl add(char* name,float x,float y,int32_t meter,int32_t owner){
        try {
            auto from=origin(__builtin_return_address(0));uint32_t token=0;SupOwnerKey key{};
            if(!name || !active->bridge->resolve(from,uint32_t(owner),token) || !active->bridge->identity(token,key))return false;
            size_t length=0;for(;length<0x4000 && name[length];++length){}
            if(length==0x4000)return false;
            std::string formatted;if(!supHudIdentifier(key,std::string(name,length),formatted))return false;
            Creation frame(std::move(formatted));bool result=false;
            active->bridge->addNewElement(SupCallOrigin::InternalToken,token,result,name,x,y,meter);return result;
        }catch(...){return false;}
    }
    // Native raw owner IDs and already-pooled owners have distinct boundaries.
    // Return-address classification also handles native callbacks reentering
    // during a script command without misclassifying them as script owners.
    // Variadic macro keeps individual arguments (including floats) typed.
#define SUP_NATIVE(method,type,signature,...) \
    __attribute__((noinline)) static type __cdecl method signature { \
        type result=type(-1);try{active->bridge->method(origin(__builtin_return_address(0)),uint32_t(owner),result,__VA_ARGS__);}catch(...){}return result;}
    SUP_NATIVE(destroy,int32_t,(char* name,int32_t owner),name)
    SUP_NATIVE(getKey,int32_t,(char* name,int32_t owner),name)
    SUP_NATIVE(getVisible,float,(char* name,int32_t element,int32_t owner),name,element)
    SUP_NATIVE(setAutoPos,int32_t,(char* name,int32_t value,int32_t owner),name,value)
    SUP_NATIVE(setIndent,int32_t,(char* name,int32_t element,float value,int32_t owner),name,element,value)
    SUP_NATIVE(setMeterTrait,int32_t,(char* name,int32_t element,float value,int32_t owner),name,element,value)
    SUP_NATIVE(setPos,int32_t,(char* name,int32_t element,float x,float y,int32_t owner),name,element,x,y)
    SUP_NATIVE(setSize,int32_t,(char* name,int32_t element,float x,float y,int32_t owner),name,element,x,y)
    SUP_NATIVE(setSizeAlt,int32_t,(char* name,int32_t element,float x,float y,int32_t owner),name,element,x,y)
    SUP_NATIVE(setTextString,int32_t,(char* name,int32_t element,char* text,int32_t owner),name,element,text)
    SUP_NATIVE(setTexture,int32_t,(char* name,int32_t element,char* texture,int32_t autoSize,int32_t owner),name,element,texture,autoSize)
    SUP_NATIVE(showBar,int32_t,(char* name,int32_t value,int32_t owner),name,value)
    SUP_NATIVE(setForceHide,float,(char* name,int32_t value,int32_t owner),name,value)
#undef SUP_NATIVE
    template<size_t index> static bool __cdecl command(WIDE_COMMAND_ARGS){
        uint32_t common=UINT32_MAX;bool accepted=false;
        try{if(active->sourceOwner(scriptObj,common) && active->bridge->scriptCommand(common,accepted,active->originals[index],WIDE_PASS_ARGS))return accepted;}catch(...){}
        if(result)*result=-1;return true;
    }
    template<size_t... indices> static constexpr auto commandCallbacks(std::index_sequence<indices...>){return std::array<CommandExecute,sizeof...(indices)>{{&command<indices>...}};}
    void rollback(){
        for(auto p=patches.rbegin();p!=patches.rend();++p)p->restore();
        for(auto& p:patches)if(p.trampoline)VirtualFree(p.trampoline,0,MEM_RELEASE);
        for(auto* p:executable)VirtualFree(p,0,MEM_RELEASE);
        patches.clear();executable.clear();bridge.reset();if(active==this)active=nullptr;
    }
public:
    bool install(HMODULE module,WideCommandTable* table,ScriptOwner source,SupFilenameLookup names,void* context=nullptr){
        if(active || !source || !table || !table->getName || !moduleHasImageRange(module,0x120590))return false;
        return installVerified(module,table,source,names,context);
    }
#ifdef WIDE_SUP_RUNTIME_TEST
    // Only present in the standalone test executable, never in the loader DLL.
    bool installSynthetic(HMODULE module,WideCommandTable* table,ScriptOwner source,SupFilenameLookup names){
        if(active || !module || !source || !table || !table->getName)return false;
        return installVerified(module,table,source,names,nullptr);
    }
    void uninstallSynthetic(){rollback();}
#endif
private:
    bool installVerified(HMODULE module,WideCommandTable* table,ScriptOwner source,SupFilenameLookup names,void* context){
        base=uint32_t(module);
        auto* dos=(IMAGE_DOS_HEADER*)module;auto* nt=(IMAGE_NT_HEADERS*)((char*)module+dos->e_lfanew);size=nt->OptionalHeader.SizeOfImage;
        // Existing bars lack provenance and cannot be safely reinterpreted.
        if(*(uint32_t*)(base+0x120588)!=*(uint32_t*)(base+0x12058c))return false;
        const unsigned char nameBytes[]={0x57,0x8b,0xf9,0x81,0xff,0xff,0,0,0};
        unsigned char formatBytes[]={0xe8,0,0,0,0};*(uint32_t*)(formatBytes+1)=0x4cc0-(0x3ce19+5);
        if(memcmp((void*)(base+0x2f440),nameBytes,9) || memcmp((void*)(base+0x3ce19),formatBytes,5))return false;
        std::array<const WideCommandInfo*,sizeof(supHudCommands)/sizeof(*supHudCommands)> infos{};
        for(size_t i=0;i<infos.size();++i){
            infos[i]=table->getName(supHudCommands[i].name);
            if(!infos[i] || uint32_t(infos[i]->execute)!=base+supHudCommands[i].entry)return false;
            originals[i]=infos[i]->execute;
        }
        for(auto& site:supHudEntrySites)if(memcmp((void*)(base+site.rva),site.bytes,site.size))return false;
        for(auto& site:supHudTransfers)if(memcmp((void*)(base+site.rva),site.bytes,site.size))return false;
        sourceOwner=source;filenames=names;filenameContext=context;
        try{
            patches.reserve(14+37+2+infos.size());executable.reserve(37);
            // Allocate every transfer before making any executable changes.
            for(auto& site:supHudTransfers){
                auto* memory=VirtualAlloc(nullptr,256,MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);if(!memory){rollback();return false;}
                executable.push_back(memory);
                auto code=supHudTransferStub(site,{current,trait,visible,reported},uint32_t(memory),base+site.rva+site.size);
                if(code.size()>256){rollback();return false;}memcpy(memory,code.data(),code.size());FlushInstructionCache(GetCurrentProcess(),memory,code.size());
            }
            void* wrappers[]={reinterpret_cast<void*>(add),reinterpret_cast<void*>(destroy),reinterpret_cast<void*>(getKey),reinterpret_cast<void*>(getVisible),reinterpret_cast<void*>(setAutoPos),reinterpret_cast<void*>(setIndent),reinterpret_cast<void*>(setMeterTrait),reinterpret_cast<void*>(setPos),reinterpret_cast<void*>(setSize),reinterpret_cast<void*>(setSizeAlt),reinterpret_cast<void*>(setTextString),reinterpret_cast<void*>(setTexture),reinterpret_cast<void*>(showBar),reinterpret_cast<void*>(setForceHide)};
            SupHudExports endpoints{};
            // These typed assignments intentionally avoid foreign struct layout
            // assumptions. A trampoline replaces one exact original endpoint.
            void* trampolines[14]{};
            active=this;
            for(size_t i=0;i<14;++i){auto& site=supHudEntrySites[i];patches.emplace_back();if(!patches.back().hook(base+site.rva,site.bytes,site.size,wrappers[i])){rollback();return false;}trampolines[i]=patches.back().trampoline;}
            endpoints.addNewElement=reinterpret_cast<decltype(endpoints.addNewElement)>(trampolines[0]);
            endpoints.destroy=reinterpret_cast<decltype(endpoints.destroy)>(trampolines[1]);
            endpoints.getKey=reinterpret_cast<decltype(endpoints.getKey)>(trampolines[2]);
            endpoints.getVisible=reinterpret_cast<decltype(endpoints.getVisible)>(trampolines[3]);
            endpoints.setAutoPos=reinterpret_cast<decltype(endpoints.setAutoPos)>(trampolines[4]);
            endpoints.setIndent=reinterpret_cast<decltype(endpoints.setIndent)>(trampolines[5]);
            endpoints.setMeterTrait=reinterpret_cast<decltype(endpoints.setMeterTrait)>(trampolines[6]);
            endpoints.setPos=reinterpret_cast<decltype(endpoints.setPos)>(trampolines[7]);
            endpoints.setSize=reinterpret_cast<decltype(endpoints.setSize)>(trampolines[8]);
            endpoints.setSizeAlt=reinterpret_cast<decltype(endpoints.setSizeAlt)>(trampolines[9]);
            endpoints.setTextString=reinterpret_cast<decltype(endpoints.setTextString)>(trampolines[10]);
            endpoints.setTexture=reinterpret_cast<decltype(endpoints.setTexture)>(trampolines[11]);
            endpoints.showBar=reinterpret_cast<decltype(endpoints.showBar)>(trampolines[12]);
            endpoints.setForceHide=reinterpret_cast<decltype(endpoints.setForceHide)>(trampolines[13]);
            endpoints.setBarValue=reinterpret_cast<decltype(endpoints.setBarValue)>(base+0x268f0);
            bridge=std::make_unique<SupHudBridge>(endpoints);
            patches.emplace_back();if(!patches.back().hook(base+0x2f440,nameBytes,9,reinterpret_cast<void*>(ownerName))){rollback();return false;}
            unsigned char call[]={0xe8,0,0,0,0};*(uint32_t*)(call+1)=uint32_t(formatName)-(base+0x3ce19+5);
            patches.emplace_back();if(!patches.back().replace(base+0x3ce19,formatBytes,call,5)){rollback();return false;}
            for(size_t i=0;i<executable.size();++i){auto& site=supHudTransfers[i];std::vector<unsigned char> jump(site.size,0x90);jump[0]=0xe9;*(uint32_t*)(jump.data()+1)=uint32_t(executable[i])-(base+site.rva+5);patches.emplace_back();if(!patches.back().replace(base+site.rva,site.bytes,jump.data(),site.size)){rollback();return false;}}
            constexpr auto callbacks=commandCallbacks(std::make_index_sequence<sizeof(supHudCommands)/sizeof(*supHudCommands)>{});
            for(size_t i=0;i<infos.size();++i){patches.emplace_back();if(!patches.back().replace(uint32_t(&infos[i]->execute),reinterpret_cast<const unsigned char*>(&originals[i]),reinterpret_cast<const unsigned char*>(&callbacks[i]),4)){rollback();return false;}}
            return true;
        }catch(...){rollback();return false;}
    }
};
} // namespace wide
