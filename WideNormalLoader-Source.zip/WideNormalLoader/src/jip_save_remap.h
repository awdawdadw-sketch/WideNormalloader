#pragma once
#include "jip_save_codec.h"
namespace wide {
// The identity registry can contain unrelated lookups created during gameplay.
// Require only the owners and references used by this complete snapshot.
// Resolver returns false for unavailable references; never infer an alias.
template<class Resolver> bool remapJipSave(const JipSave& saved,const std::vector<uint32_t>& slots,uint32_t currentCount,Resolver resolve,JipSave& output){
    try{
        JipSave mapped=saved;
        auto ref=[&](uint32_t& value){uint32_t current=0;if(!resolve(value,current))throw "JIP_reference_missing";value=current;};
        auto val=[&](JipSavedValue& value){if(value.type==2){uint32_t id=(uint32_t)value.bits;ref(id);value.bits=id;}};
        for(unsigned kind=0;kind<2;++kind){auto& owners=kind?mapped.refs:mapped.aux;
            for(auto& owner:owners){
                if(owner.slot!=jipPublicSlot){if(owner.slot>=slots.size() || slots[owner.slot]>=currentCount)throw "JIP_owner_missing";owner.slot=(uint16_t)slots[owner.slot];}
                for(auto& subject:owner.subjects){ref(subject.ref);for(auto& variable:subject.variables)for(auto& value:variable.values)val(value);}
                for(auto& map:owner.maps)for(auto& value:map.values){ref(value.ref);val(value.value);}
            }
        }
        // Reordered slots or resolved keys must not collide or merge owners.
        if(!validateJipSave(mapped,currentCount))return false;
        output=std::move(mapped);return true;
    }catch(...){return false;}
}
}
