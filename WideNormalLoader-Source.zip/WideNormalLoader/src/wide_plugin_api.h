#pragma once
#include <stdint.h>

// Versioned, read-only C ABI for cooperating DLLs. Owners are session ordinals;
// consumers must not persist them or infer ownership from a runtime FormID.
// Calls are restricted to the game thread. The startup probe has no play/save ABI.
#if defined(_WIN32)
#define WIDE_CALL __cdecl
#else
#define WIDE_CALL
#endif
enum WideStatus : uint32_t {
    WideOK=0, WideNotReady=1, WideInvalidArgument=2, WideNotFound=3,
    WideBufferTooSmall=4
};
struct WidePluginAPIv1 {
    uint32_t size;
    uint32_t version;
    WideStatus (WIDE_CALL *getCount)(uint32_t* count);
    WideStatus (WIDE_CALL *getName)(uint32_t owner,char* buffer,uint32_t capacity);
    WideStatus (WIDE_CALL *resolve)(uint32_t owner,uint32_t local,uint32_t* handle);
    WideStatus (WIDE_CALL *identify)(uint32_t handle,uint32_t* owner,uint32_t* local);
};
typedef const WidePluginAPIv1* (WIDE_CALL *WideGetInterface)(uint32_t version,uint32_t size);
// V2 explicitly separates legacy and wide owner domains. It enumerates both
// tables without changing the engine's legacy count or byte-valued entry points.
enum WideOwnerDomain : uint32_t { WideLegacyFile=0, WideExtendedFile=1, WideGenerated=2, WideFixed=3 };
struct WideFileKey { uint32_t domain,owner; };
struct WidePluginAPIv2 {
    uint32_t size,version;
    WideStatus (WIDE_CALL *getCount)(uint32_t* count);
    WideStatus (WIDE_CALL *getFile)(uint32_t index,WideFileKey* key,char* name,uint32_t capacity);
    WideStatus (WIDE_CALL *findFile)(const char* name,WideFileKey* key);
    WideStatus (WIDE_CALL *resolve)(const WideFileKey* key,uint32_t local,uint32_t* handle);
    WideStatus (WIDE_CALL *identify)(uint32_t handle,WideFileKey* key,uint32_t* local);
};
typedef const void* (WIDE_CALL *WideGetAnyInterface)(uint32_t version,uint32_t size);
