#pragma once
#include <cstring>
#include "array_content_types.h"
#include "save_identity_codec.h"
namespace wide {
// Exact ARVR version 2 payload, including native reference-vector order.
// Form values and nested array IDs are copied without interpretation.
inline bool encodeArrayCorePayload(const ArrayContent& a,const std::vector<uint8_t>& refs,std::vector<unsigned char>& output){
    if(!a.id || (a.key!=1 && a.key!=3) || a.packed>1 || (a.key==3 && a.packed) || refs.empty() || refs.size()>=0x4000 || a.elements.size()>1048576)return false;
    std::vector<unsigned char> bytes;
    auto bits=[&](uint64_t n){identityPut(bytes,(uint32_t)n,4);identityPut(bytes,(uint32_t)(n>>32),4);};
    auto text=[&](const std::string& s){if(s.size()>=0x4000 || s.find('\0')!=std::string::npos)return false;identityPut(bytes,(uint32_t)s.size(),2);bytes.insert(bytes.end(),s.begin(),s.end());return true;};
    identityPut(bytes,a.owner,1);identityPut(bytes,a.id,4);identityPut(bytes,a.key,1);identityPut(bytes,a.packed,1);identityPut(bytes,(uint32_t)refs.size(),4);bytes.insert(bytes.end(),refs.begin(),refs.end());identityPut(bytes,(uint32_t)a.elements.size(),4);
    for(const auto& e:a.elements){
        if(a.key==3){if(!text(e.keyText))return false;}else if(!a.packed)bits(e.keyBits);
        identityPut(bytes,e.type,1);
        if(e.type==1)bits(e.bits);
        else if(e.type==2 || e.type==4){if(e.bits>UINT32_MAX)return false;identityPut(bytes,(uint32_t)e.bits,4);}
        else if(e.type==3){if(!text(e.text))return false;}
        else return false;
        if(bytes.size()>maxIdentityBytes)return false;
    }
    output=std::move(bytes);return true;
}
inline bool decodeArrayCorePayload(const unsigned char* bytes,size_t length,ArrayContent& output,std::vector<uint8_t>& outputRefs){
    if(!bytes || length<16 || length>maxIdentityBytes)return false;
    size_t pos=0;auto word=[&](unsigned width,uint32_t& n){if(width>length-pos)return false;n=0;for(unsigned j=0;j<width;++j)n|=uint32_t(bytes[pos++])<<(j*8);return true;};
    auto bits=[&](uint64_t& n){uint32_t lo,hi;if(!word(4,lo) || !word(4,hi))return false;n=lo|(uint64_t(hi)<<32);return true;};
    auto text=[&](std::string& s){uint32_t n;if(!word(2,n) || n>=0x4000 || n>length-pos || memchr(bytes+pos,0,n))return false;s.assign((const char*)bytes+pos,n);pos+=n;return true;};
    ArrayContent a;uint32_t owner,key,packed,n;
    if(!word(1,owner) || !word(4,a.id) || !word(1,key) || !word(1,packed) || !a.id || (key!=1 && key!=3) || packed>1 || (key==3 && packed) || !word(4,n) || !n || n>=0x4000 || n>length-pos)return false;
    a.owner=(uint8_t)owner;a.key=(uint8_t)key;a.packed=(uint8_t)packed;
    std::vector<uint8_t> refs(bytes+pos,bytes+pos+n);pos+=n;
    if(!word(4,n) || n>1048576 || n>(length-pos)/3)return false;
    a.elements.reserve(n);
    for(uint32_t j=0;j<n;++j){
        ArrayContentElement e;uint32_t type,v;
        if(a.key==3){if(!text(e.keyText))return false;}
        else if(!a.packed){if(!bits(e.keyBits))return false;}
        else {double index=j;memcpy(&e.keyBits,&index,8);}
        if(!word(1,type))return false;e.type=(uint8_t)type;
        if(type==1){if(!bits(e.bits))return false;}
        else if(type==2 || type==4){if(!word(4,v))return false;e.bits=v;}
        else if(type==3){if(!text(e.text))return false;}
        else return false;
        a.elements.push_back(std::move(e));
    }
    if(pos!=length)return false;output=std::move(a);outputRefs=std::move(refs);return true;
}
}
