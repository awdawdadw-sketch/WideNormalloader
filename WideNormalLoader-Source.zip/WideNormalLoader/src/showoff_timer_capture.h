#pragma once
#include <windows.h>
#include "module_sha256.h"
namespace wide {
static HANDLE timerCaptureFile=INVALID_HANDLE_VALUE;
static DWORD timerCaptureBase=0;
static LONG timerCaptured=0;
static unsigned char timerCaptureBuffer[32768];
static void timerCaptureBlock(DWORD address,DWORD wanted) {
    SIZE_T got=0;DWORD written=0;
    ReadProcessMemory(GetCurrentProcess(),(void*)address,timerCaptureBuffer,wanted,&got);
    DWORD header[]={address,wanted,(DWORD)got};
    WriteFile(timerCaptureFile,header,sizeof(header),&written,nullptr);
    WriteFile(timerCaptureFile,timerCaptureBuffer,(DWORD)got,&written,nullptr);
}
static LONG CALLBACK captureShowOffTimer(EXCEPTION_POINTERS* event) {
    if(event->ExceptionRecord->ExceptionCode!=0xC0000005 ||
       event->ContextRecord->Eip!=timerCaptureBase+0x756A7 ||
       InterlockedCompareExchange(&timerCaptured,1,0))return EXCEPTION_CONTINUE_SEARCH;
    DWORD written=0;
    DWORD header[]={0x43545357,1,GetCurrentThreadId(),timerCaptureBase,sizeof(CONTEXT),sizeof(EXCEPTION_RECORD)};
    WriteFile(timerCaptureFile,header,sizeof(header),&written,nullptr);
    WriteFile(timerCaptureFile,event->ContextRecord,sizeof(CONTEXT),&written,nullptr);
    WriteFile(timerCaptureFile,event->ExceptionRecord,sizeof(EXCEPTION_RECORD),&written,nullptr);
    auto& c=*event->ContextRecord;
    timerCaptureBlock(c.Esp,32768);timerCaptureBlock(c.Ebp-512,1024);
    timerCaptureBlock(c.Edi,64);timerCaptureBlock(c.Ebx-32,256);
    timerCaptureBlock(timerCaptureBase+0xF6E44,24);
    // Current map, mod/ref entries and iterator bucket cursors remain in the
    // pinned function frame. Observe them; never repair or skip the exception.
    const int offsets[]={-0x28,-0x14,-0x18,-8,-0x10,-0x20,-0x1C};
    for(int offset:offsets){
        DWORD pointer=0;SIZE_T got=0;
        ReadProcessMemory(GetCurrentProcess(),(void*)(c.Ebp+offset),&pointer,4,&got);
        timerCaptureBlock(pointer,128);
        DWORD object[5]{};
        if(ReadProcessMemory(GetCurrentProcess(),(void*)pointer,object,sizeof(object),&got) && got==sizeof(object)){
            // Include bounded possible bucket tables for map and entry layouts.
            timerCaptureBlock(object[0],4096);timerCaptureBlock(object[2],4096);
        }
    }
    FlushFileBuffers(timerCaptureFile);
    return EXCEPTION_CONTINUE_SEARCH;
}
static bool installShowOffTimerCapture(const char* logPath,FILE* log) {
    HMODULE module=GetModuleHandleA("ShowOffNVSE.dll");
    if(!moduleHasImageRange(module,0x756aa))return false;
    const unsigned char expected[]={0x8B,0x4F,0x20};
    timerCaptureBase=(DWORD)module;
    if(memcmp((void*)(timerCaptureBase+0x756A7),expected,sizeof(expected)))return false;
    char path[MAX_PATH]{};
    if(strlen(logPath)+strlen(".showoff-timer.bin")>=sizeof(path))return false;
    strcpy(path,logPath);strcat(path,".showoff-timer.bin");
    timerCaptureFile=CreateFileA(path,GENERIC_WRITE,FILE_SHARE_READ,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
    if(timerCaptureFile==INVALID_HANDLE_VALUE)return false;
    if(!AddVectoredExceptionHandler(1,captureShowOffTimer)){CloseHandle(timerCaptureFile);timerCaptureFile=INVALID_HANDLE_VALUE;return false;}
    fprintf(log,"SHOWOFF_TIMER_CAPTURE_ACTIVE base=%08lX output=%s behavior=observe_only\n",timerCaptureBase,path);fflush(log);
    return true;
}
}
