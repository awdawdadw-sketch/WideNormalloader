#pragma once
#include "core_array_bridges.h"
namespace wide {
// The original CALL supplies the return address and stdcall arguments.
// Observe its pushad register frame, preserve flags and x87/SSE state, then
// tail-jump to the original native entry (which owns argument cleanup).
inline std::vector<unsigned char> buildArrayReferenceCallBridge(uint32_t at,uint32_t callback,uint32_t kind,uint32_t native){
 ArrayBridgeBytes b(at);
 b.bytes({0x9C,0x60,0x89,0xE6,0x81,0xEC});b.word(528);
 b.bytes({0x83,0xE4,0xF0,0x0F,0xAE,0x04,0x24,0x68});b.word(kind);
 b.bytes({0x56,0xB8});b.word(callback);b.bytes({0xFF,0xD0,0x83,0xC4,0x08,0x0F,0xAE,0x0C,0x24,0x89,0xF4,0x61,0x9D});
 b.jump(native);return std::move(b.code);
}
inline std::vector<unsigned char> buildArrayReferenceMoveBridge(uint32_t at,uint32_t callback,uint32_t kind,const std::vector<unsigned char>& replay,uint32_t resume){
 auto code=buildArrayReferenceCallBridge(at,callback,kind,resume);code.resize(code.size()-5);
 ArrayBridgeBytes b(at);b.code=std::move(code);b.code.insert(b.code.end(),replay.begin(),replay.end());b.jump(resume);return std::move(b.code);
}

}
