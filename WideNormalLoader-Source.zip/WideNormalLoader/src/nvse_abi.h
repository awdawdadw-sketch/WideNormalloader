#pragma once
#include <stdint.h>
struct NVSEInterface {
    uint32_t nvseVersion,runtimeVersion,editorVersion,isEditor;
    bool (*RegisterCommand)(void*); void (*SetOpcodeBase)(uint32_t);
    void* (*QueryInterface)(uint32_t); uint32_t (*GetPluginHandle)();
    bool (*RegisterTypedCommand)(void*,uint32_t); const char* (*GetRuntimeDirectory)();
    uint32_t isNogore;
};
struct PluginInfo { uint32_t infoVersion; const char* name; uint32_t version; };
struct Message { const char* sender; uint32_t type,dataLen; void* data; };
struct Messaging { uint32_t version; bool (*RegisterListener)(uint32_t,const char*,void (*)(Message*)); bool (*Dispatch)(uint32_t,uint32_t,void*,uint32_t,const char*); };
