#pragma once
#include <cstring>
#include "string_save_codec.h"
namespace wide {
struct StringRestoreEntry {uint32_t id,slot;uint8_t savedByte,currentByte;};
struct StringRestoreCatalog {std::vector<StringRestoreEntry> entries;uint32_t manifestCrc=0,ownerCrc=0;};
// Validate all owner metadata against the entire native stream before exposing
// any entries to the reader. Missing owners and legacy/extended boundary moves
// are rejected until the corresponding native FormID path is implemented.
inline bool buildStringRestoreCatalog(const unsigned char* bytes,size_t size,const std::vector<std::string>& current,StringRestoreCatalog& output){
 if(!bytes || size<20 || size>maxIdentityBytes || memcmp(bytes,"NVSE",4))return false;
 auto u32=[&](size_t p){return uint32_t(bytes[p])|uint32_t(bytes[p+1])<<8|uint32_t(bytes[p+2])<<16|uint32_t(bytes[p+3])<<24;};
 if(u32(4)!=1 || u32(16)>65536)return false;
 struct Native {uint32_t id,length,crc;uint8_t owner;};
 std::vector<Native> native;std::unordered_set<uint32_t> ids;
 SaveIdentities manifest;StringSave owners;const unsigned char* ownerData=nullptr;size_t ownerLength=0;uint32_t manifestOpcode=0,ownerOpcode=0;
 bool haveManifest=false,saw=false,active=false,closed=false;size_t pos=20;StringRestoreCatalog result;
 for(uint32_t block=0;block<u32(16);++block){
  if(size-pos<12)return false;
  uint32_t opcode=u32(pos),records=u32(pos+4),length=u32(pos+8);pos+=12;
  if(length>size-pos || records>length/12)return false;size_t end=pos+length;
  for(uint32_t record=0;record<records;++record){
   if(end-pos<12)return false;
   uint32_t tag=u32(pos),version=u32(pos+4),n=u32(pos+8);pos+=12;if(n>end-pos)return false;
   if(tag==saveIdentityRecord){
    if(haveManifest || version!=saveIdentityVersion || !decodeIdentities(bytes+pos,n,manifest))return false;
    haveManifest=true;manifestOpcode=opcode;result.manifestCrc=identityCrc(bytes+pos,n-4);
   }
   if(tag==stringSaveRecord){
    if(ownerData || version!=stringSaveVersion)return false;ownerOpcode=opcode;ownerData=bytes+pos;ownerLength=n;
   }
   if(opcode==0x1400){
    if(tag==0x53545653){if(saw || version || n)return false;active=saw=true;}
    else if(tag==0x53545645){if(!active || version || n)return false;active=false;closed=true;}
    else if(tag==0x53545652){
     if(!active || version || n<7)return false;
     uint32_t id=u32(pos+1),length=bytes[pos+5]|uint32_t(bytes[pos+6])<<8;
     if(!id || !ids.insert(id).second || length>=0x4000 || length!=n-7 || memchr(bytes+pos+7,0,length))return false;
     if(bytes[pos]!=255)native.push_back({id,length,identityCrc(bytes+pos+7,length),bytes[pos]});
    }else if(active)return false;
   }
   pos+=n;
  }
  if(pos!=end)return false;
 }
 if(pos!=size || !haveManifest || !ownerData || manifestOpcode!=ownerOpcode || !saw || !closed || active || !decodeStringSave(ownerData,ownerLength,(uint32_t)manifest.plugins.size(),owners) || owners.owners.size()!=native.size())return false;
 std::vector<uint32_t> slots;uint32_t missing=0;if(!identitySlotMap(manifest.plugins,current,slots,missing))return false;
 std::unordered_map<uint32_t,StringSaveOwner> byId;for(auto entry:owners.owners)byId.emplace(entry.id,entry);
 for(auto entry:native){
  auto it=byId.find(entry.id);if(it==byId.end())return false;auto saved=it->second;
  if(saved.length!=entry.length || saved.textCrc!=entry.crc)return false;
  if(entry.owner<253 ? saved.slot!=entry.owner : saved.slot<253)return false;
  uint32_t slot=slots[saved.slot];if(slot==UINT32_MAX || (saved.slot<253)!=(slot<253))return false;
  result.entries.push_back({entry.id,slot,entry.owner,uint8_t(slot<253?slot:entry.owner)});
 }
 result.ownerCrc=identityCrc(ownerData,ownerLength-4);output=std::move(result);return true;
}
}
