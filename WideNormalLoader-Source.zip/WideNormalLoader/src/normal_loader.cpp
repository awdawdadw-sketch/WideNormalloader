// Normal engine LoadFiles path experiment. Save codecs are not migrated.
#include <windows.h>
#include <tlhelp32.h>
#include <stdio.h>
#include <unordered_map>
#include <vector>
#include <string>
#include <algorithm>
#include <memory>
#include "nvse_abi.h"
#include "scalable_registry.h"
#include "file_identity_codec.h"
#include "wide_plugin_api.h"
#include "runtime_patch.h"
#include "loader_patch_sites.h"
#include "nvse_commands.h"
#include "bounded_file_cache.h"
#include "module_sha256.h"
#include "optional_adapter_detection.h"
#include "startup_preflight.h"
#include "fault_report.h"
#include "native_save_ref_remap.h"
#include "fixed_order_string_gate.h"
#include "string_owner_tracker.h"
#include "string_save_codec.h"
#include "string_restore_catalog.h"
#include "sup_hud_runtime.h"
#include "sup_hud_probe_cases.h"
#include "showoff_random_runtime.h"
#include "showoff_timer_runtime.h"
#include "jip_private_maps_runtime.h"
#include "jip_value_probe_cases.h"
#include "jip_condition_probe_inputs.h"
#include "jip_save_probe_cases.h"
#include "nvse_fastfail_capture.h"
#include "nvse_array_snapshot.h"
#include "fixed_order_array_gate.h"
#include "core_array_bridges.h"
#include "core_array_patch_signatures.h"
#include "array_content_compare.h"
#include "array_owner_tracker.h"
#include "ownership_lifecycle.h"
#include "array_identity_codec.h"
#include "array_core_payload.h"
#include "array_restore_catalog.h"
#include "array_load_stream.h"
#include "array_pool_reloc_signature.h"
#include "array_reference_tracker.h"
#include "array_reference_call_bridge.h"
#include "array_self_move_signatures.h"
#include "showoff_timer_capture.h"
#include "combined_probe_cases.h"
#include "jip_added_variables_runtime.h"
#include "jip_link_owners_runtime.h"
#include "jip_script_link_runtime.h"
#include "save_identity_codec.h"
#include "jip_save_runtime.h"
#include "jip_save_remap.h"
#include "nvse_string_snapshot.h"
#include "save_serialization_abi.h"
static_assert(sizeof(void*)==4,"32-bit engine");
static constexpr uint32_t maxFiles=1024,legacySlots=253;
// One extra slot is a guard: the index setter rejects an excessive count before
// the next loop iteration. Never write into DataHandler's following fields.
static unsigned char* loadedFiles[maxFiles+1]{};
static uint32_t loadedCount=0;static bool loading=false,ready=false;
static FILE* logFile=nullptr;static std::string orderFile;
static HMODULE startupModule=nullptr;static std::wstring startupIniPath;
static std::string additionalDirectory;static uint32_t diagnosticHold=0,firstLoop=0;static bool loopLogged=false;
static std::string unresolvedReport;static bool dumpUnresolved=false;
static bool traceUnresolvedOrigin=false;
static bool wideWeaponProjectileRefs=false;
static bool traceFunctions=false;static RuntimePatch functionInfoHook;
static bool wideLambdaIds=false;static RuntimePatch lambdaAllocationHook;
static bool wideShowOffIni=false;static RuntimePatch showOffIniHook;static HMODULE showOffModule=nullptr;
static bool wideJIPFormLookup=false;
static bool autoDetectOptionalAdapters=false;
static bool optionalAdaptersEnabled=true;
static bool wideJipPrivateMaps=false,jipPrivateMapsProbeCommand=false,jipValuesProbeCommand=false;static wide::JipPrivateMapsRuntime jipPrivateMapsRuntime;
struct ReloadConsole {uint32_t version;bool(__cdecl* run)(const char*,void*);};
static ReloadConsole* reloadConsole=nullptr;
static bool supportedStewie=false;
static bool wideStewieModNames=false;static RuntimePatch stewieModNameHook;
static bool supLegacyCacheGuard=false;static RuntimePatch supLegacyCacheHook;
static bool supWideHudOwners=false;static wide::SupHudRuntime supHudRuntime;
static bool supHudProbeCommand=false;
static bool supHudDiskScripts=false;static std::string supHudFixtureOutput;
static bool jipValueDiskScripts=false;static std::string jipValueFixtureOutput;
static bool jipDialogueCaptureCommand=false,jipDialogueProbeCommand=false;
static bool persistentArrayCapture=false;
static bool persistentArrayProbeCommand=false;
static bool combinedProbeCommand=false,combinedProbeRunning=false;
static bool timerCallbackProbeCommand=false;
static bool routeTimerCallbackProbe(void*,double*);
static bool __cdecl probeTimerCallbacks(WIDE_COMMAND_ARGS);
static bool wideJipAddedVariables=false;static wide::JipAddedVariablesRuntime jipAddedVariablesRuntime;
static bool wideJipScriptLinks=false;static wide::JipLinkOwnersRuntime jipLinkOwnersRuntime;
static uint32_t jipScriptLinkProbeMode=0;
static bool queueJipScriptLinkProbe(double*);
static wide::JipScriptLinkRuntime& jipScriptLinkRuntime(){static wide::JipScriptLinkRuntime runtime;return runtime;}
static bool traceArrayOwners=false;
static bool traceArrayReferences=false;
static bool traceArrayInternalCalls=false;
static bool traceArrayIssueInventory=false;
static bool traceArraySelfMoves=false;
static bool wideArraySave=false;
static bool wideArrayLoad=false,arrayIdentityRestored=false;
static bool traceArrayPoolMoves=false;
static volatile LONG arrayPoolCalls=0,arrayPoolMoved=0,arrayPoolRejected=0,arrayPoolErrors=0;
static uint32_t arraySelfMoveHits[8]{},arraySelfMovesMatched=0,arraySelfMovesMissing=0;
static uint32_t arrayInternalCallHits[6]{};
static bool captureArraySharing=false;
static bool captureArrayRelease=false;
static bool arraySharingProbe=false;
static bool arrayReleaseProbe=false;
struct ArrayReleaseWitness {uint32_t acquisitions=0,releases=0,array=0,slot=UINT32_MAX;uint64_t key=0;bool acquisitionKnown=false,removed=false,started=false;};
static ArrayReleaseWitness arrayReleaseWitness;
static bool wideSaveProbeCommands=false;
static bool traceNvseFastFail=false;
static bool traceShowOffTimer=false;
static bool wideSaveIdentity=false;static WideSerialization* saveSerialization=nullptr;
static bool showOffRandomOwners=false,showOffRandomProbeCommand=false;
static wide::ShowOffRandomRuntime showOffRandomRuntime;
static bool wideShowOffTimers=false,timerRestoreOnly=false;static wide::ShowOffTimerRuntime showOffTimerRuntime;
static bool timerInstallAfterMenu=false,timerRuntimeInstalled=false;
static bool timerInstallAfterPluginLoad=true;
static bool runTimerPersistenceChecks();
static wide::BoundedLegacyFileCache supLegacyFiles;
static void* const* __cdecl boundedSupLegacyCache() {
    DWORD savedError=GetLastError();
    auto* handler=*(unsigned char**)0x11C3F2C;
    auto* nodes=handler?reinterpret_cast<wide::LegacyFileNode*>(handler+0x210):nullptr;
    auto* files=supLegacyFiles.rebuild(nodes);
    static uint32_t reports=0;
    if(reports++<8) {
        fprintf(logFile,"SUP_LEGACY_CACHE count=%u limit=253 loader_ready=%u\n",supLegacyFiles.count(),ready);
        fflush(logFile);
    }
    SetLastError(savedError);return files;
}
static bool installSupLegacyCacheGuard() {
    auto module=GetModuleHandleA("supNVSE.dll");
    if(!wide::moduleHasImageRange(module,0x1206EC))return false;
    unsigned char expected[]={0x83,0x3D,0,0,0,0,0};
    *(uint32_t*)(expected+2)=(uint32_t)module+0x1206E8;
    return supLegacyCacheHook.hook((uint32_t)module+0x34A0,expected,sizeof(expected),(void*)&boundedSupLegacyCache);
}
static const char* __fastcall stewieModName(void* handler,void*,uint32_t index) {
    // Pinned Stewie build: original lazy cache at RVA F7268 has 256 slots.
    // Its list walk uses a 16-bit position and overwrites adjacent CRT globals
    // before the loader can truncate the legacy list after native linking.
    // Preserve the legacy filename interface using a bounded walk, no cache.
    // FD/FE are opaque wide domains, not unique legacy plugin positions.
    if(index>=legacySlots)return "";
    struct Node {unsigned char* file;Node* next;};
    auto* node=(Node*)((unsigned char*)handler+0x210);
    for(uint32_t i=0;node && i<index;++i)node=node->next;
    static uint32_t reports=0;
    if(reports++<16){fprintf(logFile,"STEWIE_MOD_NAME index=%u file=%s\n",index,node && node->file?(char*)node->file+0x20:"");fflush(logFile);}
    return node && node->file?(char*)node->file+0x20:"";
}
static bool traceDialogue=false,wideResponseRefs=false;static RuntimePatch dialogueLinkHook;
static thread_local uint32_t dialogueDepth=0;
static thread_local void* dialogueSource=nullptr;
static thread_local void* dialogueResponse=nullptr;
static void __fastcall traceDialogueLink(void* link,void*,void* form) {
    DWORD savedError=GetLastError();unsigned char data[0x2C]{};SIZE_T got=0;
    bool readable=ReadProcessMemory(GetCurrentProcess(),link,data,sizeof(data),&got) && got==sizeof(data);
    uint32_t id=0;unsigned char type=0;
    ReadProcessMemory(GetCurrentProcess(),(char*)form+0xC,&id,4,&got);
    ReadProcessMemory(GetCurrentProcess(),(char*)form+4,&type,1,&got);
    // INFO pending link data contains disk references. Observe them without
    // changing their resolution or the native function's result.
    void* previous=dialogueSource;void* previousResponse=dialogueResponse;dialogueSource=form;dialogueResponse=link;++dialogueDepth;
    if(traceDialogue) {
        fprintf(logFile,"DIALOGUE_LINK_BEGIN link=%p form=%p type=%u id=%08X readable=%u refs=",link,form,type,id,readable);
        for(uint32_t i=0;i<sizeof(data);i+=4)fprintf(logFile,"%08X,",*(uint32_t*)(data+i));
        fputc('\n',logFile);fflush(logFile);
    }SetLastError(savedError);
    ((void(__thiscall*)(void*,void*))dialogueLinkHook.trampoline)(link,form);
    savedError=GetLastError();if(traceDialogue){fprintf(logFile,"DIALOGUE_LINK_END link=%p id=%08X\n",link,id);fflush(logFile);}
    --dialogueDepth;dialogueSource=previous;dialogueResponse=previousResponse;SetLastError(savedError);
}
static bool traceRuntime=false;static RuntimePatch runtimeAbortHook,runtimeMessageHook,runtimeTerminateHook;
static bool traceOverflow=false,traceStewieLocale=false;static HANDLE overflowFile=INVALID_HANDLE_VALUE;
static HMODULE stewieDiagnosticModule=nullptr;static RuntimePatch stewieFacetHook;
static void localeSnapshot(const char* phase,void* locale=nullptr,void* facet=nullptr) {
    DWORD saved=GetLastError();SIZE_T got=0;uint32_t state[4]{},loc[8]{},fac[8]{};
    uint32_t base=(uint32_t)stewieDiagnosticModule;
    const uint32_t offsets[]={0xF25E0,0xF25F4,0xF7670,0xF25C8};
    for(unsigned i=0;i<4;++i)ReadProcessMemory(GetCurrentProcess(),(void*)(base+offsets[i]),state+i,4,&got);
    if(locale)ReadProcessMemory(GetCurrentProcess(),locale,loc,sizeof(loc),&got);
    if(facet)ReadProcessMemory(GetCurrentProcess(),facet,fac,sizeof(fac),&got);
    fprintf(logFile,"STEWIE_LOCALE phase=%s slot=%08X global=%08X cached=%08X counter=%08X locale=%p facet=%p loc=",phase,state[0],state[1],state[2],state[3],locale,facet);
    for(auto v:loc)fprintf(logFile,"%08X,",v);fputs(" facet_data=",logFile);
    for(auto v:fac)fprintf(logFile,"%08X,",v);fputc('\n',logFile);fflush(logFile);SetLastError(saved);
}
static void* __cdecl observeStewieFacet(void* locale) {
    localeSnapshot("facet-enter",locale);
    void* result=((void*(__cdecl*)(void*))stewieFacetHook.trampoline)(locale);
    localeSnapshot("facet-return",locale,result);return result;
}
static LONG CALLBACK captureOverflow(EXCEPTION_POINTERS* event) {
    static LONG captured=0;static unsigned char stack[16384];
    bool overflow=traceOverflow && event->ExceptionRecord->ExceptionCode==0xC00000FD;
    bool startup=traceStewieLocale && event->ExceptionRecord->ExceptionCode==0xC0000005 && event->ContextRecord->Eip==(uint32_t)stewieDiagnosticModule+0x162EF;
    if((!overflow && !startup) || InterlockedCompareExchange(&captured,1,0))return EXCEPTION_CONTINUE_SEARCH;
    SIZE_T count=0;DWORD written=0;
    ReadProcessMemory(GetCurrentProcess(),(void*)event->ContextRecord->Esp,stack,sizeof(stack),&count);
    DWORD header[]={0x574F5646,1,GetCurrentThreadId(),event->ContextRecord->Esp,event->ContextRecord->Eip,(DWORD)count,sizeof(EXCEPTION_RECORD),sizeof(CONTEXT)};
    // Preopened handle, static storage, no allocation or formatted logging.
    WriteFile(overflowFile,header,sizeof(header),&written,nullptr);
    WriteFile(overflowFile,event->ExceptionRecord,sizeof(EXCEPTION_RECORD),&written,nullptr);
    WriteFile(overflowFile,event->ContextRecord,sizeof(CONTEXT),&written,nullptr);
    WriteFile(overflowFile,stack,(DWORD)count,&written,nullptr);FlushFileBuffers(overflowFile);
    return EXCEPTION_CONTINUE_SEARCH;
}
static bool installOverflowCapture() {
    ULONG reserve=65536;if(!SetThreadStackGuarantee(&reserve))return false;
    HANDLE modules=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE,GetCurrentProcessId());if(modules==INVALID_HANDLE_VALUE)return false;
    MODULEENTRY32 entry{};entry.dwSize=sizeof(entry);
    if(Module32First(modules,&entry))do{fprintf(logFile,"OVERFLOW_MODULE base=%08X size=%08lX path=%s\n",(uint32_t)entry.modBaseAddr,entry.modBaseSize,entry.szExePath);}while(Module32Next(modules,&entry));
    CloseHandle(modules);fflush(logFile);return AddVectoredExceptionHandler(1,captureOverflow)!=nullptr;
}
static void logRuntimeStack(const char* reason) {
    if(!logFile)return;
    void* frames[48]{};USHORT count=CaptureStackBackTrace(0,48,frames,nullptr);
    fprintf(logFile,"RUNTIME_TRACE reason=%s thread=%lu\n",reason,GetCurrentThreadId());
    for(USHORT i=0;i<count;i++) {
        HMODULE module=nullptr;char name[MAX_PATH]{};
        GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,(const char*)frames[i],&module);
        if(module)GetModuleFileNameA(module,name,MAX_PATH);
        const char* base=strrchr(name,'\\');
        fprintf(logFile,"  %p %s+%08X\n",frames[i],base?base+1:name,(uint32_t)frames[i]-(uint32_t)module);
    }
    fflush(logFile);
}
static void __cdecl traceAbort() {
    logRuntimeStack("msvcrt abort");((void(__cdecl*)())runtimeAbortHook.trampoline)();
}
static void __cdecl traceRuntimeMessage(int code) {
    fprintf(logFile,"RUNTIME_MESSAGE code=%d\n",code);logRuntimeStack("msvcrt _amsg_exit");
    ((void(__cdecl*)(int))runtimeMessageHook.trampoline)(code);
}
static void __cdecl traceTerminate() {
    logRuntimeStack("msvcrt terminate");((void(__cdecl*)())runtimeTerminateHook.trampoline)();
}
static LONG CALLBACK traceException(EXCEPTION_POINTERS* event) {
    static LONG count=0;
    DWORD code=event->ExceptionRecord->ExceptionCode;
    if((code==0xE06D7363 || code==0xC0000005 || code==0xC000001D) && InterlockedIncrement(&count)<=100) {
        fprintf(logFile,"RUNTIME_EXCEPTION code=%08lX site=%p info_count=%lu",code,event->ExceptionRecord->ExceptionAddress,event->ExceptionRecord->NumberParameters);
        for(DWORD i=0;i<event->ExceptionRecord->NumberParameters;i++)fprintf(logFile," %08X",(uint32_t)event->ExceptionRecord->ExceptionInformation[i]);
        fputc('\n',logFile);logRuntimeStack("first chance exception");
    }
    return EXCEPTION_CONTINUE_SEARCH;
}
static bool installRuntimeTrace() {
    auto crt=GetModuleHandleA("msvcrt.dll");if(!crt)return false;
    const unsigned char prolog[]={0x8B,0xFF,0x55,0x8B,0xEC};
    auto abortSite=GetProcAddress(crt,"abort"),messageSite=GetProcAddress(crt,"_amsg_exit"),terminateSite=GetProcAddress(crt,"?terminate@@YAXXZ");
    // Seven bytes containing two complete position-independent instructions: push 8; push
    // the CRT's relocated exception handler data. Validate this local build.
    unsigned char terminateProlog[]={0x6A,8,0x68,0,0,0,0};
    *(uint32_t*)(terminateProlog+3)=(uint32_t)crt+0xAFD70;
    if(!abortSite || !messageSite || !terminateSite || memcmp((void*)abortSite,prolog,5) || memcmp((void*)messageSite,prolog,5) || memcmp((void*)terminateSite,terminateProlog,7))return false;
    if(!runtimeAbortHook.hook((uint32_t)abortSite,prolog,5,(void*)&traceAbort) || !runtimeMessageHook.hook((uint32_t)messageSite,prolog,5,(void*)&traceRuntimeMessage) || !runtimeTerminateHook.hook((uint32_t)terminateSite,terminateProlog,7,(void*)&traceTerminate)) {
        runtimeAbortHook.restore();runtimeMessageHook.restore();runtimeTerminateHook.restore();return false;
    }
    return AddVectoredExceptionHandler(1,traceException)!=nullptr;
}
static ScalableWideRegistry registry;
static std::unordered_map<void*,uint32_t> owners;
static std::recursive_mutex ownerLock;
static RuntimePatch orchestration,indexSetter,header,embedded,localGetter,localCompare,cloneHook,perFileHook,masterBuilderHook;
struct MasterNode {void* data;MasterNode* next;};
static std::vector<MasterNode> masterLookupList;
static std::vector<RuntimePatch> operandPatches;
static RuntimePatch onamPatch,groupSearchPatch;static std::vector<void*> codeBridges;
static thread_local void* cloningSource=nullptr;
static WideCommandTable* commands=nullptr;static WideScriptInterface* scripts=nullptr;
struct CommandChange {const char* name;CommandExecute callback,original=nullptr;RuntimePatch patch;};
static bool __cdecl commandCount(WIDE_COMMAND_ARGS);
static bool __cdecl commandIndex(WIDE_COMMAND_ARGS);
static bool __cdecl commandLoaded(WIDE_COMMAND_ARGS);
static bool __cdecl commandSource(WIDE_COMMAND_ARGS);
static bool __cdecl commandLocal(WIDE_COMMAND_ARGS);
static bool __cdecl commandBuild(WIDE_COMMAND_ARGS);
static bool __cdecl commandJIPForm(WIDE_COMMAND_ARGS);
static CommandChange jipFormChange={"GetFormFromMod",commandJIPForm};
static CommandChange commandChanges[]={
    {"GetNumLoadedMods",commandCount},{"GetModIndex",commandIndex},{"IsModLoaded",commandLoaded},
    {"GetSourceModIndex",commandSource},{"GetLocalRefIndex",commandLocal},{"BuildRef",commandBuild}};
struct MapEntry {MapEntry* next;uint32_t key;void* form;};
struct FormMap {void* vtable;uint32_t buckets;MapEntry** table;uint32_t count;};
static void* lookup(uint32_t id) {
    auto* map=*(FormMap**)0x11C54C0;if(!map || !map->buckets || !map->table)return nullptr;
    for(auto* e=map->table[id%map->buckets];e;e=e->next)if(e->key==id)return e->form;
    return nullptr;
}
static bool occupied(uint32_t id) {return lookup(id)!=nullptr;}
static bool wideVoiceIds=false,traceDialogueResults=false;
static RuntimePatch voiceIdCallPatch,voiceSuffixHook,dialogueResultHook;
static thread_local uint32_t resultScriptDepth=0;
static const char* canonicalOwnerName(uint32_t id) {
    auto* entry=registry.reverse(id);
    uint32_t slot=entry?entry->key.plugin+legacySlots:id>>24;
    return slot<loadedCount?(char*)loadedFiles[slot]+0x20:"<generated-or-unknown>";
}
static uint32_t __fastcall voiceLocalId(void* info,void*) {
    uint32_t id=((uint32_t(__thiscall*)(void*))0x84E3A0)(info);
    // Only this voice-suffix call is redirected. Its caller masks to 24 bits.
    // INFO's opaque runtime handle must never become an on-disk asset name.
    if(ready && *((unsigned char*)info+4)==70) {
        auto* entry=registry.reverse(id);
        if(entry && lookup(id)==info)return entry->key.local;
    }
    return id;
}
static void __fastcall observeVoiceSuffix(void* response,void*,void* quest,void* topic,void* info,void* output) {
    ((void(__thiscall*)(void*,void*,void*,void*,void*))voiceSuffixHook.trampoline)(response,quest,topic,info,output);
    if(!ready || !info || !output)return;
    uint32_t id=*(uint32_t*)((char*)info+0xC);
    const char* owner=canonicalOwnerName(id);
    static uint32_t reports=0;
    if(lstrcmpiA(owner,"ShadowOverGoodsprings.esp") || reports++>=128)return;
    char suffix[260]{};SIZE_T got=0;
    auto* text=*(const char**)output;
    if(text)ReadProcessMemory(GetCurrentProcess(),text,suffix,sizeof(suffix)-1,&got);
    auto* entry=registry.reverse(id);
    fprintf(logFile,"VOICE_SUFFIX owner=%s info=%08X local=%06X response=%u wide_adapter=%u suffix=%s\n",owner,id,entry?entry->key.local:id&0xFFFFFF,*((unsigned char*)response+0xC),wideVoiceIds,suffix);
    fflush(logFile);
}
static void __fastcall observeDialogueResult(void* info,void*,uint32_t onEnd,void* actor) {
    uint32_t id=*(uint32_t*)((char*)info+0xC);
    const char* owner=ready?canonicalOwnerName(id):"<loading>";
    bool target=!lstrcmpiA(owner,"ShadowOverGoodsprings.esp");
    static uint32_t reports=0;
    if(target && reports++<256) {
        auto* entry=registry.reverse(id);
        void* process=actor?*(void**)((char*)actor+0x68):nullptr;
        uint32_t level=UINT32_MAX;SIZE_T got=0;
        if(process)ReadProcessMemory(GetCurrentProcess(),(char*)process+0x28,&level,sizeof(level),&got);
        fprintf(logFile,"DIALOGUE_RESULT owner=%s info=%08X local=%06X actor=%08X end=%u depth=%u process=%p process_level=%u\n",owner,id,entry?entry->key.local:id&0xFFFFFF,actor?*(uint32_t*)((char*)actor+0xC):0,onEnd,resultScriptDepth,process,level);
        fflush(logFile);
    }
    ++resultScriptDepth;
    ((void(__thiscall*)(void*,uint32_t,void*))dialogueResultHook.trampoline)(info,onEnd,actor);
    --resultScriptDepth;
}
static bool installVoiceDiagnostics() {
    const unsigned char call[]={0xE8,0x3B,0x6F,0x23,0x00};
    const unsigned char mask[]={0x25,0xFF,0xFF,0xFF,0x00};
    const unsigned char suffix[]={0x55,0x8B,0xEC,0x81,0xEC,0x1C,0x01,0x00,0x00};
    const unsigned char result[]={0x55,0x8B,0xEC,0x83,0xEC,0x0C};
    if(wideVoiceIds && (memcmp((void*)0x617460,call,sizeof(call)) || memcmp((void*)0x617465,mask,sizeof(mask))))return false;
    if(traceDialogueResults && (memcmp((void*)0x617400,suffix,sizeof(suffix)) || memcmp((void*)0x61F170,result,sizeof(result))))return false;
    if(wideVoiceIds) {
        unsigned char patched[5]={0xE8};*(uint32_t*)(patched+1)=(uint32_t)&voiceLocalId-0x617465;
        if(!voiceIdCallPatch.replace(0x617460,call,patched,sizeof(patched)))return false;
    }
    if(traceDialogueResults) {
        if(!voiceSuffixHook.hook(0x617400,suffix,sizeof(suffix),(void*)&observeVoiceSuffix) ||
           !dialogueResultHook.hook(0x61F170,result,sizeof(result),(void*)&observeDialogueResult)) {
            voiceSuffixHook.restore();dialogueResultHook.restore();voiceIdCallPatch.restore();return false;
        }
    }
    fprintf(logFile,"VOICE_LOCAL_ID_ADAPTER=%u DIALOGUE_RESULT_TRACE=%u\n",wideVoiceIds,traceDialogueResults);fflush(logFile);return true;
}
static bool __cdecl allocateWideLambda(void* lambda,void* parent) {
    uint32_t parentId=*(uint32_t*)((char*)parent+0xC);
    if(!registry.reverse(parentId))return false;
    auto* dh=*(void**)0x11C3F2C;
    uint32_t id=((uint32_t(__thiscall*)(void*))0x469800)(dh);
    auto** vtable=*(void***)lambda;
    ((void(__thiscall*)(void*,uint32_t,bool))vtable[0x128/4])(lambda,id,true);
    fprintf(logFile,"WIDE_LAMBDA parent=%08X generated=%08X\n",parentId,id);fflush(logFile);
    return true;
}
static bool installWideLambda(HMODULE nvse) {
    // Local xNVSE build's inlined GetNextFreeFormID(parent): its form-map-only
    // search cannot see reserved canonical handles for deferred records.
    uint32_t site=(uint32_t)nvse+0x8D6A7;
    const unsigned char expected[]={0xA1,0xC0,0x54,0x1C,0x01,0x8B,0x70,0x08,0x8B,0x40,0x04,0x89,0x45,0xE8};
    if(memcmp((void*)site,expected,sizeof(expected)))return false;
    unsigned char bytes[]={0x9C,0x60,0x53,0x57,0xB8,0,0,0,0,0xFF,0xD0,0x83,0xC4,8,0x85,0xC0,0x74,7,0x61,0x9D,0xE9,0,0,0,0,0x61,0x9D,0xE9,0,0,0,0};
    auto* bridge=(unsigned char*)VirtualAlloc(nullptr,sizeof(bytes),MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);if(!bridge)return false;
    *(uint32_t*)(bytes+5)=(uint32_t)&allocateWideLambda;
    *(uint32_t*)(bytes+21)=(uint32_t)nvse+0x8D6EE - ((uint32_t)bridge+25);
    memcpy(bridge,bytes,sizeof(bytes));
    if(!lambdaAllocationHook.hook(site,expected,5,bridge))return false;
    *(uint32_t*)(bridge+28)=(uint32_t)lambdaAllocationHook.trampoline-((uint32_t)bridge+32);
    FlushInstructionCache(GetCurrentProcess(),bridge,sizeof(bytes));codeBridges.push_back(bridge);return true;
}
static void* __fastcall traceFunctionInfo(void* context,void*,void* script) {
    unsigned char object[0x54]{};SIZE_T copied=0;
    bool readable=script && ReadProcessMemory(GetCurrentProcess(),script,object,sizeof(object),&copied) && copied==sizeof(object);
    uint32_t id=readable?*(uint32_t*)(object+0xC):0;
    uint32_t length=readable?*(uint32_t*)(object+0x20):0;
    void* data=readable?*(void**)(object+0x30):nullptr;
    unsigned char prefix[64]{};SIZE_T prefixRead=0;
    if(data && length)ReadProcessMemory(GetCurrentProcess(),data,prefix,length<sizeof(prefix)?length:sizeof(prefix),&prefixRead);
    fprintf(logFile,"FUNCTION_INFO script=%p readable=%u type=%u id=%08X length=%u data=%p prefix=",script,readable,readable?object[4]:0,id,length,data);
    for(SIZE_T i=0;i<prefixRead;i++)fprintf(logFile,"%02X",prefix[i]);fputc('\n',logFile);fflush(logFile);
    return ((void*(__thiscall*)(void*,void*))functionInfoHook.trampoline)(context,script);
}
[[noreturn]] static void stop(const char* reason) {
    wide::faults::controlledStop(reason);
    wide::faults::stage("loader_deliberate_stop_see_FAIL_in_loader_log");
    if(logFile){fprintf(logFile,"FAIL %s\n",reason);fflush(logFile);}
    char message[2048]{};snprintf(message,sizeof(message),"WideNormalLoader stopped loading:\n\n%s\n\nSee the loader log and WideNormalLoader-preflight.txt beside FalloutNV.exe for details. If that folder is not writable, the preflight report is under Local AppData\\WideNormalLoader.",reason);
    MessageBoxA(nullptr,message,"WideNormalLoader: loading stopped",MB_OK|MB_ICONERROR|MB_SETFOREGROUND);ExitProcess(91);
}
static bool binding(void* pointer,MasterBinding& out) {
    std::lock_guard<std::recursive_mutex> guard(ownerLock);
    auto it=owners.find(pointer);if(it==owners.end())return false;
    out={it->second>=legacySlots,it->second>=legacySlots?it->second-legacySlots:it->second};return true;
}
static bool supScriptOwner(void* script,uint32_t& common) {
    if(!ready)return false;
    if(!script){common=255;return true;}
    auto* node=reinterpret_cast<MasterNode*>((char*)script+0x10);
    MasterNode value{};SIZE_T got=0;
    for(uint32_t i=0;i<4096;++i) {
        if(!ReadProcessMemory(GetCurrentProcess(),node,&value,sizeof(value),&got) || got!=sizeof(value))return false;
        if(!value.next){
            if(!value.data){common=255;return true;}
            MasterBinding file;if(!binding(value.data,file))return false;
            common=file.wide?256+file.owner:file.owner;return true;
        }
        node=value.next;
    }
    return false;
}
static const char* supFilename(wide::SupOwnerKind kind,uint32_t owner,void*) {
    uint32_t slot=kind==wide::SupOwnerKind::ExtendedPlugin?owner+legacySlots:owner;
    return slot<loadedCount && loadedFiles[slot]?(char*)loadedFiles[slot]+0x20:"";
}
// Test only: compile real commands through xNVSE, and temporarily attach each
// compiled function to a real loaded TESFile. This exercises SUP's command path
// with two extended source owners; it does not test SCPT records read from ESP.
struct alignas(8) SupProbeElement {double number;uint8_t type;uint8_t padding[7];};
static_assert(sizeof(SupProbeElement)==16,"xNVSE numeric Element ABI");
struct SupProbeScriptApi {
    bool(__cdecl* call)(void*,void*,void*,SupProbeElement*,uint8_t,...);
    void* parameters;void* extract;void* format;void* callAlt;void* compile;
    void*(__cdecl* expression)(const char*);
};
static SupProbeScriptApi* supProbeApi=nullptr;
struct JipProbeStringApi {uint32_t version;const char*(__cdecl* get)(uint32_t);void(__cdecl* set)(uint32_t,const char*);uint32_t(__cdecl* create)(const char*,void*);};
struct JipProbeArrayApi {void*(__cdecl* create)(const SupProbeElement*,uint32_t,void*);void* stringMap;void* map;void* assign;void* set;void* append;uint32_t(__cdecl* size)(void*);void*(__cdecl* lookup)(uint32_t);};
static JipProbeStringApi* jipProbeStrings=nullptr;static JipProbeArrayApi* jipProbeArrays=nullptr;
static bool supProbeExpression(uint32_t index,uint32_t slot,const char* expression,double& value) {
    void* script=nullptr;
    if(supHudDiskScripts){
        auto* entry=registry.find({slot-legacySlots,0xA00+index});
        if(entry)script=lookup(entry->handle);
        if(!script){fprintf(logFile,"SUP_HUD_PROBE_MISSING_SCPT slot=%u local=%06X\n",slot,0xA00+index);fflush(logFile);return false;}
        uint32_t source=0;if(!supScriptOwner(script,source) || source!=slot-legacySlots+256)return false;
    }else script=supProbeApi->expression(expression);
    if(!script)return false;
    auto* head=reinterpret_cast<MasterNode*>((char*)script+0x10);
    struct Restore {MasterNode* head;MasterNode saved;bool enabled;~Restore(){if(enabled)*head=saved;}} restore{head,*head,!supHudDiskScripts};
    if(!supHudDiskScripts)*head={loadedFiles[slot],nullptr};
    if(!supHudDiskScripts && !supHudFixtureOutput.empty()) {
        unsigned char info[20];memcpy(info,(char*)script+0x18,20);
        uint32_t length=*(uint32_t*)(info+8);
        auto* data=*(unsigned char**)((char*)script+0x30);
        if(*(uint32_t*)(info+4) || *(uint32_t*)(info+12) || !data || !length || length>0xFFFF){fprintf(logFile,"SUP_HUD_SCPT_EXPORT_REJECTED slot=%u step=%u refs=%u vars=%u length=%u\n",slot,index,*(uint32_t*)(info+4),*(uint32_t*)(info+12),length);fflush(logFile);return false;}
        char filename[80];sprintf(filename,"\\sup-hud-scpt-%u-%u.bin",slot,index);
        auto path=supHudFixtureOutput+filename;FILE* exported=fopen(path.c_str(),"wb");if(!exported)return false;
        bool ok=fwrite(info,1,20,exported)==20 && fwrite(data,1,length,exported)==length;
        ok=fclose(exported)==0 && ok;if(!ok)return false;
        fprintf(logFile,"SUP_HUD_SCPT_EXPORT slot=%u local=%06X length=%u refs=0 vars=0\n",slot,0xA00+index,length);fflush(logFile);
    }
    SupProbeElement output{};
    bool called=supProbeApi->call(script,*(void**)0x11DEA3C,nullptr,&output,0);
    fprintf(logFile,"SUP_HUD_PROBE_STEP slot=%u file=%s expression=%s called=%u type=%u value=%.9g\n",slot,(char*)loadedFiles[slot]+0x20,expression,called,output.type,output.number);fflush(logFile);
    // Compiled functions remain session-owned: xNVSE caches their contexts.
    if(!called || output.type!=1)return false;value=output.number;return true;
}
static bool __cdecl probeSupHud(WIDE_COMMAND_ARGS) {
    *result=0;
    if(!ready || !supWideHudOwners || loadedCount!=1024 || !supProbeApi || !supProbeApi->call || !supProbeApi->expression)return true;
    const char* name="WideHudDiskProbe";
    char expression[256];bool passed=true;double value=0;
    // Slots997/998 map to public script owners1000/1001, avoiding any byte
    // distinction that could accidentally masquerade as extended ownership.
    for(uint32_t i=0;i<sizeof(supHudProbeCases)/sizeof(*supHudProbeCases);++i){
        const auto& test=supHudProbeCases[i];
        sprintf(expression,"%s \"%s\"%s",test.operation,name,test.tail);
        bool ok=supProbeExpression(i,test.slot,expression,value) && value==test.expected;passed=passed && ok;
    }
    fprintf(logFile,"SUP_HUD_PROBE_COMPLETE passed=%u owners=1000,1001 steps=30 context=%s\n",passed,supHudDiskScripts?"disk_SCPT_records":"temporary_loaded_TESFile_sources");fflush(logFile);
    *result=passed?1:0;return true;
}
static WideCommandInfo supHudProbe={"WideTestSupHud","",0,"Test extended SUP HUD ownership (local diagnostic)",0,0,nullptr,probeSupHud,nullptr,nullptr,0};
static bool showOffProbeExpression(uint32_t slot,const char* expression,double& value) {
    auto* script=supProbeApi->expression(expression);if(!script){fprintf(logFile,"SHOWOFF_RANDOM_PROBE_COMPILE_FAILED slot=%u expression=%s\n",slot,expression);fflush(logFile);return false;}
    auto* head=reinterpret_cast<MasterNode*>((char*)script+0x10);
    struct Restore {MasterNode* head;MasterNode saved;~Restore(){*head=saved;}} restore{head,*head};
    *head=slot<loadedCount?MasterNode{loadedFiles[slot],nullptr}:MasterNode{nullptr,nullptr};
    SupProbeElement output{};bool called=supProbeApi->call(script,*(void**)0x11DEA3C,nullptr,&output,0);
    fprintf(logFile,"SHOWOFF_RANDOM_PROBE_STEP slot=%u expression=%s called=%u type=%u value=%.17g\n",slot,expression,called,output.type,output.number);fflush(logFile);
    if(!called || output.type!=1)return false;value=output.number;return true;
}
static bool __cdecl probeShowOffRandom(WIDE_COMMAND_ARGS) {
    *result=0;if(!ready || !showOffRandomOwners || !supProbeApi || !supProbeApi->call || !supProbeApi->expression || loadedCount!=1024)return true;
    bool passed=true;double value=0,x=0,y=0,z=0;
    auto run=[&](uint32_t slot,const char* text){bool ok=showOffProbeExpression(slot,text,value);passed=passed && ok;return ok;};
    auto expect=[&](uint32_t slot,const char* text,double expected){bool ok=run(slot,text) && value==expected;passed=passed && ok;};
    auto draw=[&](uint32_t slot,double& saved){if(run(slot,"RandSeeded 0 1000000")){saved=value;passed=passed && value>=0 && value<=1000000;}};
    run(997,"SetRandomizerSeed 111");run(998,"SetRandomizerSeed 222");
    expect(997,"GetRandomizerSeed",111);expect(998,"GetRandomizerSeed",222);
    draw(997,x);run(997,"SetRandomizerSeed 111");expect(997,"RandSeeded 0 1000000",x);
    draw(998,y);run(998,"SetRandomizerSeed 222");expect(997,"AdvanceSeed 7",1);expect(998,"RandSeeded 0 1000000",y);
    run(997,"SetRandomizerSeed 333");draw(997,z);run(997,"SetRandomizerSeed 333");expect(998,"AdvanceSeed 5",1);expect(997,"RandSeeded 0 1000000",z);
    run(997,"SetRandomizerSeed -2");expect(997,"GetRandomizerSeed",4294967294.0);expect(998,"GetRandomizerSeed",222);
    run(997,"SetSeedUsingForm");expect(997,"GetRandomizerSeed",5489);expect(998,"GetRandomizerSeed",222);
    if(run(997,"GetRandomPercentSeeded"))passed=passed && value>=1 && value<=100;
    run(252,"SetRandomizerSeed 3333");expect(252,"GetRandomizerSeed",3333);expect(997,"GetRandomizerSeed",5489);
    run(UINT32_MAX,"SetRandomizerSeed 6666");expect(UINT32_MAX,"GetRandomizerSeed",6666);expect(998,"GetRandomizerSeed",222);
    fprintf(logFile,"SHOWOFF_RANDOM_PROBE_COMPLETE passed=%u extended_owners=1000,1001 legacy_owner=252 console_owner=255 context=temporary_loaded_TESFile_sources\n",passed);fflush(logFile);
    *result=passed?1:0;return true;
}
static WideCommandInfo showOffRandomProbe={"WideTestShowoffRandom","",0,"Test extended ShowOff random ownership (local diagnostic)",0,0,nullptr,probeShowOffRandom,nullptr,nullptr,0};
static bool jipMapProbeExpression(uint32_t slot,const char* expression,double& value,const char* tag="JIP_MAP"){
    auto* script=supProbeApi->expression(expression);if(!script){fprintf(logFile,"%s_PROBE_COMPILE_FAILED slot=%u expression=%s\n",tag,slot,expression);fflush(logFile);return false;}
    auto* head=reinterpret_cast<MasterNode*>((char*)script+0x10);
    struct Restore{MasterNode* head;MasterNode saved;~Restore(){*head=saved;}}restore{head,*head};
    *head=slot<loadedCount?MasterNode{loadedFiles[slot],nullptr}:MasterNode{nullptr,nullptr};
    SupProbeElement output{};bool called=supProbeApi->call(script,*(void**)0x11DEA3C,nullptr,&output,0);
    fprintf(logFile,"%s_PROBE_STEP slot=%u expression=%s called=%u type=%u value=%.17g\n",tag,slot,expression,called,output.type,output.number);fflush(logFile);
    if(!called || output.type!=1)return false;value=output.number;return true;
}
static bool __cdecl probeJipPrivateMaps(WIDE_COMMAND_ARGS){
    *result=0;if(!ready || !wideJipPrivateMaps || !supProbeApi || !supProbeApi->call || !supProbeApi->expression || loadedCount!=1024)return true;
    bool passed=true;double value=0;
    auto expect=[&](uint32_t slot,const char* text,double expected){bool ok=jipMapProbeExpression(slot,text,value) && value==expected;passed=passed && ok;};
    expect(997,"AuxiliaryVariableSetFloat \"*WideJipProbe\" 111",1);
    expect(998,"AuxiliaryVariableSetFloat \"*WideJipProbe\" 222",1);
    expect(997,"AuxiliaryVariableGetFloat \"*WideJipProbe\"",111);
    expect(998,"AuxiliaryVariableGetFloat \"*WideJipProbe\"",222);
    expect(997,"AuxiliaryVariableGetSize \"*WideJipProbe\"",1);
    expect(998,"AuxiliaryVariableGetType \"*WideJipProbe\"",1);
    expect(997,"AuxiliaryVariableErase \"*WideJipProbe\"",-1);
    expect(997,"AuxiliaryVariableGetSize \"*WideJipProbe\"",0);
    expect(998,"AuxiliaryVariableGetFloat \"*WideJipProbe\"",222);
    expect(998,"AuxiliaryVariableEraseAll 1",0);
    expect(998,"AuxiliaryVariableGetSize \"*WideJipProbe\"",0);
    expect(997,"RefMapArraySetFloat \"*WideJipProbe\" 333",0);
    expect(998,"RefMapArraySetFloat \"*WideJipProbe\" 444",0);
    expect(997,"RefMapArrayGetFloat \"*WideJipProbe\"",333);
    expect(998,"RefMapArrayGetFloat \"*WideJipProbe\"",444);
    expect(997,"RefMapArrayGetSize \"*WideJipProbe\"",1);
    expect(998,"RefMapArrayGetType \"*WideJipProbe\"",1);
    expect(997,"RefMapArrayValidate \"*WideJipProbe\"",1);
    expect(997,"RefMapArrayErase \"*WideJipProbe\"",0);
    expect(997,"RefMapArrayGetSize \"*WideJipProbe\"",0);
    expect(998,"RefMapArrayGetFloat \"*WideJipProbe\"",444);
    expect(998,"RefMapArrayDestroy \"*WideJipProbe\"",0);
    expect(998,"RefMapArrayGetSize \"*WideJipProbe\"",0);
    // Clear only the private permanent namespaces of two dummy fixture files.
    expect(997,"AuxiliaryVariableSetFloat \"WideJipProbe\" 555",1);
    expect(998,"AuxiliaryVariableSetFloat \"WideJipProbe\" 666",1);
    expect(997,"RefMapArraySetFloat \"WideJipProbe\" 777",0);
    expect(998,"RefMapArraySetFloat \"WideJipProbe\" 888",0);
    expect(997,"ClearJIPSavedData 0 0 1 1",0);
    expect(997,"AuxiliaryVariableGetSize \"WideJipProbe\"",0);
    expect(997,"RefMapArrayGetSize \"WideJipProbe\"",0);
    expect(998,"AuxiliaryVariableGetFloat \"WideJipProbe\"",666);
    expect(998,"RefMapArrayGetFloat \"WideJipProbe\"",888);
    expect(998,"ClearJIPSavedData 0 0 1 1",0);
    expect(998,"AuxiliaryVariableGetSize \"WideJipProbe\"",0);
    expect(998,"RefMapArrayGetSize \"WideJipProbe\"",0);
    expect(997,"AuxiliaryVariableSetFloat \"*_WideJipPublicProbe\" 999",1);
    expect(998,"AuxiliaryVariableGetFloat \"*_WideJipPublicProbe\"",999);
    expect(997,"AuxiliaryVariableErase \"*_WideJipPublicProbe\"",-1);
    expect(997,"RefMapArraySetFloat \"*_WideJipPublicProbe\" 123",0);
    expect(998,"RefMapArrayGetFloat \"*_WideJipPublicProbe\"",123);
    expect(997,"RefMapArrayDestroy \"*_WideJipPublicProbe\"",0);
    expect(252,"AuxiliaryVariableSetFloat \"*WideJipLegacyProbe\" 456",1);
    expect(252,"AuxiliaryVariableGetFloat \"*WideJipLegacyProbe\"",456);
    expect(997,"AuxiliaryVariableGetSize \"*WideJipLegacyProbe\"",0);
    expect(252,"AuxiliaryVariableErase \"*WideJipLegacyProbe\"",-1);
    expect(UINT32_MAX,"RefMapArraySetFloat \"*WideJipConsoleProbe\" 789",0);
    expect(UINT32_MAX,"RefMapArrayGetFloat \"*WideJipConsoleProbe\"",789);
    expect(998,"RefMapArrayGetSize \"*WideJipConsoleProbe\"",0);
    expect(UINT32_MAX,"RefMapArrayDestroy \"*WideJipConsoleProbe\"",0);
    fprintf(logFile,"JIP_MAP_PROBE_COMPLETE passed=%u extended_owners=1000,1001 legacy_owner=252 console_owner=255 steps=49 context=temporary_loaded_TESFile_sources\n",passed);fflush(logFile);
    *result=passed?1:0;return true;
}
static WideCommandInfo jipMapProbe={"WideTestJipMaps","",0,"Test extended JIP private maps (local diagnostic)",0,0,nullptr,probeJipPrivateMaps,nullptr,nullptr,0};
static bool jipConditionProbe(){
    auto* info=commands->getName("AuxVarGetFltCond");auto module=GetModuleHandleA("jip_nvse.dll");
    if(!info || uint32_t(info->eval)!=uint32_t(module)+wide::jipRva(wide::jipMapConditionEval))return false;
    auto eval=(bool(__cdecl*)(void*,void*,void*,double*))info->eval;
    // Retain compiled script objects for xNVSE's session caches, as with other probes.
    auto* scriptA=supProbeApi->expression("0");auto* scriptB=supProbeApi->expression("0");if(!scriptA || !scriptB)return false;
    auto* headA=(MasterNode*)((char*)scriptA+0x10);auto* headB=(MasterNode*)((char*)scriptB+0x10);
    struct Restore{MasterNode* head;MasterNode saved;~Restore(){*head=saved;}}restoreA{headA,*headA},restoreB{headB,*headB};
    *headA={loadedFiles[997],nullptr};*headB={loadedFiles[998],nullptr};
    uint32_t stringId=jipProbeStrings->create("*WideJipConditionProbe",scriptA);if(!stringId || !jipProbeStrings->get(stringId))return false;
    JipConditionVariable variable{37,0,double(stringId),0,{}};JipConditionNode node{&variable,nullptr};
    JipConditionLocals locals{scriptA,0,nullptr,&node,nullptr};JipConditionQuestInput quest{};quest.script=scriptA;quest.locals=&locals;
    bool passed=true;double value=0;uint32_t steps=0;
    auto command=[&](uint32_t slot,const char* text,double expected){bool ok=jipMapProbeExpression(slot,text,value,"JIP_CONDITION_SETUP") && value==expected;passed=passed && ok;};
    auto check=[&](const char* name,void* script,void* variableId,double expected){quest.script=script;value=0;bool called=eval(*(void**)0x11DEA3C,&quest,variableId,&value);++steps;
        bool ok=called && value==expected;passed=passed && ok;fprintf(logFile,"JIP_CONDITION_PROBE_STEP case=%s called=%u value=%.17g expected=%.17g\n",name,called,value,expected);fflush(logFile);};
    command(997,"AuxiliaryVariableSetFloat \"*WideJipConditionProbe\" 111",1);command(998,"AuxiliaryVariableSetFloat \"*WideJipConditionProbe\" 222",1);
    check("quest_A",scriptA,(void*)37,111);check("quest_B",scriptB,(void*)37,222);
    // One compiled script has two file nodes; last source must win.
    MasterNode overriding{loadedFiles[998],nullptr};*headA={loadedFiles[997],&overriding};
    check("overridden_A_by_B",scriptA,(void*)37,222);*headA={loadedFiles[997],nullptr};
    check("quest_A_restored",scriptA,(void*)37,111);check("missing_variable",scriptA,(void*)38,0);
    quest.locals=nullptr;check("missing_event_list",scriptA,(void*)37,0);quest.locals=&locals;
    jipProbeStrings->set(stringId,"");check("empty_variable_name",scriptA,(void*)37,0);
    jipProbeStrings->set(stringId,"*_WideJipConditionPublicProbe");
    command(997,"AuxiliaryVariableSetFloat \"*_WideJipConditionPublicProbe\" 333",1);
    check("public_A",scriptA,(void*)37,333);check("public_B",scriptB,(void*)37,333);
    command(997,"AuxiliaryVariableErase \"*WideJipConditionProbe\"",-1);command(998,"AuxiliaryVariableErase \"*WideJipConditionProbe\"",-1);
    command(997,"AuxiliaryVariableErase \"*_WideJipConditionPublicProbe\"",-1);
    // String interface has no deletion method. Empty this one retained session
    // string; it is not a persistent quest variable or registered quest object.
    jipProbeStrings->set(stringId,"");
    fprintf(logFile,"JIP_CONDITION_PROBE_COMPLETE passed=%u steps=%u context=controlled_quest_inputs_actual_JIP_Eval\n",passed,steps);fflush(logFile);return passed;
}
static bool exportJipValueScript(void* script,uint32_t slot,uint32_t index){
    unsigned char info[20];memcpy(info,(char*)script+0x18,20);
    uint32_t refCount=*(uint32_t*)(info+4),length=*(uint32_t*)(info+8),variables=*(uint32_t*)(info+12);
    auto* data=*(unsigned char**)((char*)script+0x30);
    if(variables || refCount>255 || !data || !length || length>0xffff)return false;
    std::vector<uint32_t> references;
    auto* node=(MasterNode*)((char*)script+0x44);SIZE_T got=0;
    for(uint32_t count=0;node && count<256;++count){
        MasterNode item{};if(!ReadProcessMemory(GetCurrentProcess(),node,&item,sizeof(item),&got) || got!=sizeof(item))return false;node=item.next;
        if(!item.data)continue;
        uint32_t ref[4]{};if(!ReadProcessMemory(GetCurrentProcess(),item.data,ref,sizeof(ref),&got) || got!=sizeof(ref))return false;
        void* form=(void*)ref[2];uint32_t variable=ref[3];
        // Initial fixtures admit only static base-game references. Their master
        // selector is zero, preserving ordinary disk FormID interpretation.
        if(variable || !form)return false;uint32_t id=0;
        if(!ReadProcessMemory(GetCurrentProcess(),(char*)form+0xc,&id,4,&got) || got!=4)return false;
        if(id>>24 || lookup(id)!=form)return false;references.push_back(id);
    }
    if(node || references.size()!=refCount)return false;
    char filename[100];sprintf(filename,"\\jip-values-scpt-%u-%u.bin",slot,index);auto path=jipValueFixtureOutput+filename;
    FILE* output=fopen(path.c_str(),"wb");if(!output)return false;const uint32_t magic=0x31435357;
    bool ok=fwrite(&magic,4,1,output)==1 && fwrite(info,1,20,output)==20 && fwrite(&refCount,4,1,output)==1;
    if(refCount)ok=fwrite(references.data(),4,refCount,output)==refCount && ok;
    ok=fwrite(data,1,length,output)==length && ok;ok=fclose(output)==0 && ok;
    if(ok){fprintf(logFile,"JIP_VALUE_SCPT_EXPORT slot=%u index=%u local=%06X length=%u refs=%u vars=0\n",slot,index,0xb00+index,length,refCount);fflush(logFile);}
    return ok;
}
static bool jipDiskValueExpression(uint32_t slot,uint32_t index,const char* expression,double& value){
    auto* entry=registry.find({slot-legacySlots,0xb00+index});void* script=entry?lookup(entry->handle):nullptr;
    uint32_t source=0;if(!script || !supScriptOwner(script,source) || source!=slot-legacySlots+256){fprintf(logFile,"JIP_DISK_PROBE_MISSING_SCRIPT slot=%u index=%u\n",slot,index);fflush(logFile);return false;}
    SupProbeElement output{};bool called=supProbeApi->call(script,*(void**)0x11DEA3C,nullptr,&output,0);
    fprintf(logFile,"JIP_DISK_PROBE_STEP index=%u slot=%u local=%06X expression=%s called=%u type=%u value=%.17g context=disk_SCPT\n",index,slot,0xb00+index,expression,called,output.type,output.number);fflush(logFile);
    if(!called || output.type!=1)return false;value=output.number;return true;
}
static bool __cdecl probeJipValues(WIDE_COMMAND_ARGS){
    *result=0;if(!ready || !wideJipPrivateMaps || !supProbeApi || !jipProbeStrings || !jipProbeArrays || loadedCount!=1024)return true;
    auto* script=supProbeApi->expression("0");if(!script)return true;
    auto* head=(MasterNode*)((char*)script+0x10);struct Restore{MasterNode* head;MasterNode saved;~Restore(){*head=saved;}}restore{head,*head};
    *head={loadedFiles[997],nullptr};SupProbeElement values[3]{};for(auto& v:values)v.type=1;
    values[0].number=11;values[1].number=12;void* arrays[4]{};arrays[0]=jipProbeArrays->create(values,2,script);
    values[0].number=31;arrays[2]=jipProbeArrays->create(values,1,script);
    *head={loadedFiles[998],nullptr};values[0].number=21;values[1].number=22;values[2].number=23;arrays[1]=jipProbeArrays->create(values,3,script);
    values[0].number=41;arrays[3]=jipProbeArrays->create(values,1,script);
    for(unsigned i=0;i<4;++i)if(!arrays[i] || jipProbeArrays->size(arrays[i])!=(i==0?2:i==1?3:1))return true;
    bool passed=true;double value=0;uint32_t index=0;
    for(auto& test:jipValueProbeCases){char expression[1024]{};if(test.arrayArgument)sprintf(expression,test.expression,uint32_t(arrays[test.arrayArgument-1]));else strcpy(expression,test.expression);
        bool executed=false;
        if(!test.arrayArgument && jipValueDiskScripts)executed=jipDiskValueExpression(test.slot,index,expression,value);
        else {
            if(!test.arrayArgument && !jipValueFixtureOutput.empty()){
                auto* compiled=supProbeApi->expression(expression);bool exported=compiled && exportJipValueScript(compiled,test.slot,index);passed=passed && exported;
                if(!exported){fprintf(logFile,"JIP_VALUE_SCPT_EXPORT_FAILED slot=%u index=%u\n",test.slot,index);fflush(logFile);}
            }
            executed=jipMapProbeExpression(test.slot,expression,value,"JIP_VALUES");
        }
        bool ok=executed && value==test.expected;passed=passed && ok;
        fprintf(logFile,"JIP_VALUES_EXPECT index=%u passed=%u expected=%.17g\n",index++,ok,test.expected);fflush(logFile);
    }
    bool conditionPassed=jipConditionProbe();passed=passed && conditionPassed;
    fprintf(logFile,"JIP_VALUES_PROBE_COMPLETE passed=%u steps=%u condition_passed=%u context=%s\n",passed,index,conditionPassed,jipValueDiskScripts?"54_disk_SCPT_plus_4_dynamic_array_inputs":"temporary_loaded_TESFile_sources");fflush(logFile);
    *result=passed?1:0;return true;
}
static WideCommandInfo jipValuesProbe={"WideTestJipValues","",0,"Test JIP values and condition ownership (local diagnostic)",0,0,nullptr,probeJipValues,nullptr,nullptr,0};
static bool capturePersistentArrayOne(uint32_t index,double* result){
    *result=0;
    auto reject=[](const char* reason){fprintf(logFile,"PERSISTENT_ARRAY_CAPTURE_REJECTED reason=%s\n",reason);fflush(logFile);return true;};
    if(!ready || !supProbeApi || !supProbeApi->compile)return reject("not_ready_or_missing_compile_api");
    // Reading a nonempty output directory into a new std::string at plugin
    // startup reproducibly exposed an invalid UI list during menu setup.
    // Resolve diagnostics paths only when the user invokes this command, using
    // bounded stack buffers. This does not establish the corruption's origin.
    HMODULE self=nullptr;char iniPath[MAX_PATH]{},directory[MAX_PATH]{},path[MAX_PATH]{};
    if(!GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,(LPCSTR)&capturePersistentArrayOne,&self))return reject("module_path_unavailable");
    DWORD iniLength=GetModuleFileNameA(self,iniPath,sizeof(iniPath));
    if(!iniLength || iniLength>=sizeof(iniPath))return reject("module_path_too_long");
    auto* extension=strrchr(iniPath,'.');if(!extension || size_t(extension-iniPath)+5>sizeof(iniPath))return reject("ini_path_invalid");strcpy(extension,".ini");
    DWORD directoryLength=GetPrivateProfileStringA("Diagnostics","PersistentArrayCaptureOutputDirectory","",directory,sizeof(directory),iniPath);
    if(!directoryLength || directoryLength>=sizeof(directory)-1)return reject("output_directory_empty_or_too_long");
    int pathLength=index>=2?snprintf(path,sizeof(path),"%s\\%s",directory,index==3?"array-release-quest-scpt.bin":"array-sharing-quest-scpt.bin"):snprintf(path,sizeof(path),"%s\\persistent-array-%c-scpt.bin",directory,index?'B':'A');
    if(pathLength<0 || size_t(pathLength)>=sizeof(path))return reject("output_path_too_long");
    auto compile=(void*(__cdecl*)(const char*))supProbeApi->compile;HMODULE provider=nullptr;
    if(!GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,(LPCSTR)compile,&provider) || provider!=GetModuleHandleA("nvse_1_4.dll"))return reject("compile_api_provider_mismatch");
    char source[1024]{};snprintf(source,sizeof(source),"scn WidePersistentArrayQuest%c\narray_var WideArray\nbegin GameMode\nif eval WideArray == ar_Null\nlet WideArray := ar_List %u.25 \"wide-array-%c\" (GetFormFromMod \"NativeProbe_%04u.esp\" \"000800\") (ar_List %u.5 \"wide-child-%c\")\nendif\nend\n",index?'B':'A',123+index,index?'B':'A',689+index,456+index,index?'B':'A');
    if(index==2)strcpy(source,"scn WideArraySharingQuest\narray_var WideShared\nbegin GameMode\nif eval WideShared == ar_Null\nlet WideShared := GetArrayVariable \"WideArray\" (GetFormFromMod \"NativeProbe_0689.esp\" \"000D10\")\nendif\nend\n");
    if(index==3)strcpy(source,"scn WideArrayReleaseQuest\narray_var WideShared\nbegin GameMode\nlet WideShared := GetArrayVariable \"WideArray\" (GetFormFromMod \"NativeProbe_0689.esp\" \"000D10\")\nlet WideShared := ar_Null\nStopQuest (GetFormFromMod \"NativeProbe_0690.esp\" \"000D50\")\nend\n");
    auto* script=compile(source);if(!script){fputs("PERSISTENT_ARRAY_CAPTURE_COMPILE_FAILED\n",logFile);fflush(logFile);return true;}
    unsigned char info[20];memcpy(info,(char*)script+0x18,20);uint32_t refs=*(uint32_t*)(info+4),length=*(uint32_t*)(info+8),variables=*(uint32_t*)(info+12);
    auto* data=*(unsigned char**)((char*)script+0x30);
    if(refs || variables!=1 || !data || !length || length>0xffff){fprintf(logFile,"PERSISTENT_ARRAY_CAPTURE_REJECTED refs=%u vars=%u length=%u\n",refs,variables,length);fflush(logFile);return true;}
    MasterNode node{};SIZE_T got=0;if(!ReadProcessMemory(GetCurrentProcess(),(char*)script+0x4c,&node,sizeof(node),&got) || got!=sizeof(node) || !node.data)return reject("variable_list_unreadable");
    uint32_t variable[8]{};if(!ReadProcessMemory(GetCurrentProcess(),node.data,variable,sizeof(variable),&got) || got!=sizeof(variable))return reject("variable_definition_unreadable");
    char name[81]{};uint32_t nameLength=variable[7]&0xffff;
    if(!variable[0] || nameLength!=(index>=2?10u:9u) || !ReadProcessMemory(GetCurrentProcess(),(void*)variable[6],name,nameLength,&got) || got!=nameLength || lstrcmpiA(name,index>=2?"WideShared":"WideArray"))return reject("variable_identity_invalid");
    if(node.next){MasterNode extra{};if(!ReadProcessMemory(GetCurrentProcess(),node.next,&extra,sizeof(extra),&got) || got!=sizeof(extra) || extra.data || extra.next)return reject("unexpected_extra_variables");}
    FILE* output=fopen(path,"wb");if(!output)return reject("output_open_failed");
    const uint32_t magic=0x31435157;bool ok=fwrite(&magic,4,1,output)==1 && fwrite(info,1,20,output)==20 && fwrite(variable,1,24,output)==24 && fwrite(&nameLength,4,1,output)==1 && fwrite(name,1,nameLength,output)==nameLength && fwrite(data,1,length,output)==length;
    ok=fclose(output)==0 && ok;
    fprintf(logFile,"PERSISTENT_ARRAY_CAPTURE_COMPLETE passed=%u refs=%u variables=%u variable_index=%u length=%u name=%s context=compile_only_no_quest_execution\n",ok,refs,variables,variable[0],length,name);fflush(logFile);
    *result=ok?1:0;return true;
}
static bool __cdecl captureJipDialogue(WIDE_COMMAND_ARGS){
    if(captureArrayRelease)return capturePersistentArrayOne(3,result);
    if(captureArraySharing)return capturePersistentArrayOne(2,result);
    if(persistentArrayCapture){double a=0,b=0;capturePersistentArrayOne(0,&a);capturePersistentArrayOne(1,&b);*result=(a==1 && b==1)?1:0;fprintf(logFile,"PERSISTENT_ARRAY_CAPTURE_PAIR passed=%u\n",*result==1);fflush(logFile);return true;}
    *result=0;
    auto reject=[](const char* reason){fprintf(logFile,"JIP_DIALOGUE_CAPTURE_REJECTED reason=%s\n",reason);fflush(logFile);return true;};
    if(!ready || !supProbeApi || !supProbeApi->compile)return reject("not_ready_or_missing_compile_api");
    // Reading a nonempty output directory into a new std::string at plugin
    // startup reproducibly exposed an invalid UI list during menu setup.
    // Resolve diagnostics paths only when the user invokes this command, using
    // bounded stack buffers. This does not establish the corruption's origin.
    HMODULE self=nullptr;char iniPath[MAX_PATH]{},directory[MAX_PATH]{},path[MAX_PATH]{};
    if(!GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,(LPCSTR)&captureJipDialogue,&self))return reject("module_path_unavailable");
    DWORD iniLength=GetModuleFileNameA(self,iniPath,sizeof(iniPath));
    if(!iniLength || iniLength>=sizeof(iniPath))return reject("module_path_too_long");
    auto* extension=strrchr(iniPath,'.');if(!extension || size_t(extension-iniPath)+5>sizeof(iniPath))return reject("ini_path_invalid");strcpy(extension,".ini");
    DWORD directoryLength=GetPrivateProfileStringA("Diagnostics","JipDialogueCaptureOutputDirectory","",directory,sizeof(directory),iniPath);
    if(!directoryLength || directoryLength>=sizeof(directory)-1)return reject("output_directory_empty_or_too_long");
    int pathLength=snprintf(path,sizeof(path),"%s\\jip-dialogue-quest-scpt.bin",directory);
    if(pathLength<0 || size_t(pathLength)>=sizeof(path))return reject("output_path_too_long");
    auto compile=(void*(__cdecl*)(const char*))supProbeApi->compile;HMODULE provider=nullptr;
    if(!GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,(LPCSTR)compile,&provider) || provider!=GetModuleHandleA("nvse_1_4.dll"))return reject("compile_api_provider_mismatch");
    const char source[]="scn WideDialogueProbeQuest\nstring_var WideName\nbegin GameMode\nif WideName == 0\nlet WideName := sv_Construct \"*WideDialogueValue\"\nendif\nend\n";
    auto* script=compile(source);if(!script){fputs("JIP_DIALOGUE_CAPTURE_COMPILE_FAILED\n",logFile);fflush(logFile);return true;}
    unsigned char info[20];memcpy(info,(char*)script+0x18,20);uint32_t refs=*(uint32_t*)(info+4),length=*(uint32_t*)(info+8),variables=*(uint32_t*)(info+12);
    auto* data=*(unsigned char**)((char*)script+0x30);
    if(refs || variables!=1 || !data || !length || length>0xffff){fprintf(logFile,"JIP_DIALOGUE_CAPTURE_REJECTED refs=%u vars=%u length=%u\n",refs,variables,length);fflush(logFile);return true;}
    MasterNode node{};SIZE_T got=0;if(!ReadProcessMemory(GetCurrentProcess(),(char*)script+0x4c,&node,sizeof(node),&got) || got!=sizeof(node) || !node.data)return reject("variable_list_unreadable");
    uint32_t variable[8]{};if(!ReadProcessMemory(GetCurrentProcess(),node.data,variable,sizeof(variable),&got) || got!=sizeof(variable))return reject("variable_definition_unreadable");
    char name[81]{};uint32_t nameLength=variable[7]&0xffff;
    if(!variable[0] || nameLength!=8 || !ReadProcessMemory(GetCurrentProcess(),(void*)variable[6],name,nameLength,&got) || got!=nameLength || lstrcmpiA(name,"WideName"))return reject("variable_identity_invalid");
    if(node.next){MasterNode extra{};if(!ReadProcessMemory(GetCurrentProcess(),node.next,&extra,sizeof(extra),&got) || got!=sizeof(extra) || extra.data || extra.next)return reject("unexpected_extra_variables");}
    FILE* output=fopen(path,"wb");if(!output)return reject("output_open_failed");
    const uint32_t magic=0x31435157;bool ok=fwrite(&magic,4,1,output)==1 && fwrite(info,1,20,output)==20 && fwrite(variable,1,24,output)==24 && fwrite(&nameLength,4,1,output)==1 && fwrite(name,1,nameLength,output)==nameLength && fwrite(data,1,length,output)==length;
    ok=fclose(output)==0 && ok;
    fprintf(logFile,"JIP_DIALOGUE_CAPTURE_COMPLETE passed=%u refs=%u variables=%u variable_index=%u length=%u name=%s context=compile_only_no_quest_execution\n",ok,refs,variables,variable[0],length,name);fflush(logFile);
    *result=ok?1:0;return true;
}
static WideCommandInfo jipDialogueCapture={"WideCaptureJipDialogue","",0,"Capture quest script for native dialogue fixture (local diagnostic)",0,0,nullptr,captureJipDialogue,nullptr,nullptr,0};
static bool __cdecl probeJipDialogue(WIDE_COMMAND_ARGS){
    *result=0;
    auto reject=[](const char* reason){fprintf(logFile,"JIP_DIALOGUE_PROBE_REJECTED reason=%s\n",reason);fflush(logFile);return true;};
    if(!ready || loadedCount!=1024 || !wideJipPrivateMaps || !jipProbeStrings || !supProbeApi || !reloadConsole || !reloadConsole->run)return reject("not_ready");
    void* player=*(void**)0x11DEA3C;if(!player)return reject("missing_player");
    void* quests[2]{},*topics[2]{},*infos[2][2]{};uint32_t topicIds[2]{};
    auto form=[&](uint32_t slot,uint32_t local,uint8_t type)->void*{auto* entry=registry.find({slot-legacySlots,local});auto* object=entry?lookup(entry->handle):nullptr;return object && *((uint8_t*)object+4)==type?object:nullptr;};
    for(uint32_t i=0;i<2;++i){
        uint32_t slot=997+i;auto* script=form(slot,0xc00,0x11);quests[i]=form(slot,0xc10,0x47);topics[i]=form(slot,0xc20,0x45);
        infos[i][0]=form(slot,0xc30,0x46);infos[i][1]=form(slot,0xc31,0x46);
        uint32_t owner=0;if(!script || !quests[i] || !topics[i] || !infos[i][0] || !infos[i][1] || !supScriptOwner(script,owner) || owner!=1000+i)return reject("missing_fixture_or_owner_mismatch");
        topicIds[i]=*(uint32_t*)((char*)topics[i]+0xc);
        if(*(void**)((char*)quests[i]+0x1c)!=script || *(void**)((char*)script+0x40)!=quests[i])return reject("native_quest_script_attachment_mismatch");
        auto* locals=*(JipConditionLocals**)((char*)quests[i]+0x5c);if(!locals)return reject("quest_event_list_not_initialized");
        JipConditionLocals localsValue{};SIZE_T localsRead=0;
        if(!ReadProcessMemory(GetCurrentProcess(),locals,&localsValue,sizeof(localsValue),&localsRead) || localsRead!=sizeof(localsValue))return reject("quest_event_list_unreadable");
        uint32_t stringId=0;bool found=false;auto* node=localsValue.variables;
        for(uint32_t n=0;node && n<4096;++n){
            JipConditionNode value{};SIZE_T got=0;if(!ReadProcessMemory(GetCurrentProcess(),node,&value,sizeof(value),&got) || got!=sizeof(value))return reject("quest_variable_node_unreadable");
            JipConditionVariable variable{};
            if(value.variable && (!ReadProcessMemory(GetCurrentProcess(),value.variable,&variable,sizeof(variable),&got) || got!=sizeof(variable)))return reject("quest_variable_unreadable");
            if(value.variable && variable.id==1){double id=variable.number;if(!(id>=1 && id<=UINT32_MAX) || id!=double(uint32_t(id)))return reject("quest_string_id_invalid");stringId=uint32_t(id);found=true;break;}
            node=value.next;
        }
        const char* name=found?jipProbeStrings->get(stringId):nullptr;
        if(!name || strcmp(name,"*WideDialogueValue"))return reject("quest_script_has_not_initialized_string_variable");
        for(uint32_t j=0;j<2;++j){
            if(*(void**)((char*)infos[i][j]+0x48)!=quests[i])return reject("info_quest_attachment_mismatch");
            auto* list=(MasterNode*)((char*)infos[i][j]+0x18);if(!list->data || list->next)return reject("unexpected_condition_list");
            uint32_t condition[7]{};SIZE_T got=0;if(!ReadProcessMemory(GetCurrentProcess(),list->data,condition,sizeof(condition),&got) || got!=sizeof(condition))return reject("condition_unreadable");
            float expected=i?222.0f:111.0f;
            if((condition[0]&0xff)!=(j?0x20:0) || *(float*)&condition[1]!=expected || condition[2]!=0x17b1 || condition[3]!=uint32_t(quests[i]) || condition[4]!=1 || condition[5]!=2 || condition[6]!=uint32_t(player)){
                fprintf(logFile,"JIP_DIALOGUE_CONDITION_MISMATCH slot=%u info=%u type=%u comparison=%.9g function_index=%08X arg1=%08X expected_quest=%p arg2=%u run_on=%u reference=%08X expected_player=%p\n",slot,j,condition[0]&255,*(float*)&condition[1],condition[2],condition[3],quests[i],condition[4],condition[5],condition[6],player);fflush(logFile);
                return reject("native_condition_fixup_mismatch");
            }
        }
        fprintf(logFile,"JIP_DIALOGUE_NATIVE_QUEST slot=%u owner=%u script=%p quest=%p locals=%p string_id=%u name=%s\n",slot,owner,script,quests[i],locals,stringId,name);fflush(logFile);
    }
    bool passed=true;uint32_t steps=0;double value=0;
    auto setup=[&](uint32_t slot,double number){char expression[128];snprintf(expression,sizeof(expression),"AuxiliaryVariableSetFloat \"*WideDialogueValue\" %.17g",number);bool ok=jipMapProbeExpression(slot,expression,value,"JIP_DIALOGUE_SETUP") && value==1;passed=passed && ok;return ok;};
    auto check=[&](const char* phase,bool expectPass){
        for(uint32_t i=0;i<2;++i)for(uint32_t j=0;j<2;++j){bool expected=j?!expectPass:expectPass,auxiliaryFlag=false;
            auto* list=(char*)infos[i][j]+0x18;
            // The engine's AL return is the condition-list truth value. The
            // bool* receives an auxiliary status, not the comparison outcome.
            bool returned=((bool(__thiscall*)(void*,void*,void*,bool*,bool))0x680C60)(list,player,nullptr,&auxiliaryFlag,false);
            bool ok=returned==expected;passed=passed && ok;++steps;
            fprintf(logFile,"JIP_DIALOGUE_CTDA_STEP phase=%s slot=%u info=%s returned=%u auxiliary_flag=%u expected=%u passed=%u\n",phase,997+i,j?"fallback":"pass",returned,auxiliaryFlag,expected,ok);fflush(logFile);
        }
    };
    if(!setup(997,111) || !setup(998,222))return reject("private_value_setup_failed");check("initial",true);
    if(!setup(997,444) || !setup(998,555))return reject("private_value_mutation_failed");check("mutated",false);
    if(!setup(997,111) || !setup(998,222))return reject("private_value_restore_failed");check("restored",true);
    if(passed)for(uint32_t i=0;i<2;++i){char line[64];snprintf(line,sizeof(line),"AddTopic %08X",topicIds[i]);bool ok=reloadConsole->run(line,nullptr);passed=passed && ok;fprintf(logFile,"JIP_DIALOGUE_ADD_TOPIC slot=%u id=%08X executed=%u edid=WideDialogueTopic%c\n",997+i,topicIds[i],ok,'A'+i);fflush(logFile);}
    fprintf(logFile,"JIP_DIALOGUE_PROBE_COMPLETE passed=%u steps=%u context=native_disk_quests_and_INFO_condition_lists conversation_selection=user_pending\n",passed,steps);fflush(logFile);*result=passed?1:0;return true;
}
static WideCommandInfo jipDialogueProbe={"WideTestJipDialogue","",0,"Test native quest and dialogue condition fixtures (local diagnostic)",0,0,nullptr,probeJipDialogue,nullptr,nullptr,0};
static void traceWideStringState(const char* phase);
static void traceCoreArrayState(const char* phase);
static void traceArrayIssueInventoryNow();
static void traceArrayOwnerCoverage(const std::vector<wide::NvseArrayState>& arrays,const std::unordered_set<uint32_t>& ids);
static uint32_t saveFixtureSlot(uint32_t index){
    const char* name=index?"NativeProbe_0690.esp":"NativeProbe_0689.esp";
    for(uint32_t slot=0;slot<loadedCount;++slot)if(!_stricmp((char*)loadedFiles[slot]+0x20,name))return slot;
    return UINT32_MAX;
}
static uint32_t fixtureFormHandle(uint32_t slot,uint32_t local){
    if(slot>=loadedCount)return 0;if(slot<legacySlots)return (slot<<24)|local;
    auto* entry=registry.find({slot-legacySlots,local});return entry?entry->handle:0;
}
// Read-only quest/array check. It never initializes or repairs fixture values.
static bool __cdecl checkPersistentArrays(WIDE_COMMAND_ARGS){
    *result=0;
    auto reject=[](const char* reason){fprintf(logFile,"WIDE_PERSISTENT_ARRAY_REJECTED reason=%s\n",reason);fflush(logFile);return true;};
    if(!ready || !jipProbeArrays)return reject("not_ready");
    uint32_t parents[2]{},children[2]{},slots[2]{saveFixtureSlot(0),saveFixtureSlot(1)};
    uint8_t owners[2]{};
    for(uint32_t i=0;i<2;++i){
        if(slots[i]>=loadedCount)return reject("fixture_slot_missing");
        void* quest=lookup(fixtureFormHandle(slots[i],0xd10));
        if(!quest || *((uint8_t*)quest+4)!=0x47)return reject("fixture_quest_missing");
        void* script=*(void**)((char*)quest+0x1c);if(!script || *((uint8_t*)script+4)!=0x11)return reject("quest_script_missing");
        owners[i]=*((uint8_t*)script+0xf);
        auto* locals=*(JipConditionLocals**)((char*)quest+0x5c);JipConditionLocals value{};SIZE_T got=0;
        if(!locals || !ReadProcessMemory(GetCurrentProcess(),locals,&value,sizeof(value),&got) || got!=sizeof(value))return reject("quest_locals_missing");
        auto* node=value.variables;
        for(uint32_t n=0;node && n<4096;++n){
            JipConditionNode nv{};JipConditionVariable variable{};
            if(!ReadProcessMemory(GetCurrentProcess(),node,&nv,sizeof(nv),&got) || got!=sizeof(nv))return reject("quest_node_unreadable");
            if(nv.variable && (!ReadProcessMemory(GetCurrentProcess(),nv.variable,&variable,sizeof(variable),&got) || got!=sizeof(variable)))return reject("quest_variable_unreadable");
            if(nv.variable && variable.id==1){double number=variable.number;if(number>=1 && number<=UINT32_MAX && number==double(uint32_t(number)))parents[i]=uint32_t(number);break;}
            node=nv.next;
        }
        if(!parents[i])return reject("quest_array_not_initialized");
    }
    if(arraySharingProbe){
        void* quest=lookup(fixtureFormHandle(slots[1],0xd30));uint32_t held=0;SIZE_T got=0;
        if(!quest || *((uint8_t*)quest+4)!=0x47)return reject("sharing_quest_missing");
        auto* locals=*(JipConditionLocals**)((char*)quest+0x5c);JipConditionLocals value{};
        if(!locals || !ReadProcessMemory(GetCurrentProcess(),locals,&value,sizeof(value),&got) || got!=sizeof(value))return reject("sharing_quest_locals_missing");
        auto* node=value.variables;
        for(uint32_t n=0;node && n<4096;++n){JipConditionNode nv{};JipConditionVariable variable{};
            if(!ReadProcessMemory(GetCurrentProcess(),node,&nv,sizeof(nv),&got) || got!=sizeof(nv))return reject("sharing_node_unreadable");
            if(nv.variable && (!ReadProcessMemory(GetCurrentProcess(),nv.variable,&variable,sizeof(variable),&got) || got!=sizeof(variable)))return reject("sharing_variable_unreadable");
            if(nv.variable && variable.id==1){double number=variable.number;if(number>=1 && number<=UINT32_MAX && number==double(uint32_t(number)))held=uint32_t(number);break;}node=nv.next;
        }
        bool ok=held && held==parents[0];fprintf(logFile,"WIDE_ARRAY_SHARING holder_slot=%u creator_slot=%u held=%u expected_parent=%u passed=%u scope=native_quest_assignment\n",slots[1],slots[0],held,parents[0],ok);fflush(logFile);
        if(!ok)return reject("sharing_quest_did_not_hold_A_parent");
    }
    wide::NvseArraySnapshot reader;
    if(!reader.bind(GetModuleHandleA("nvse_1_4.dll"),(void*)jipProbeArrays->create,jipProbeArrays->size,jipProbeArrays->lookup))return reject("array_api_mismatch");
    std::unordered_set<uint32_t> wanted{parents[0],parents[1]};std::vector<wide::NvseArrayState> arrays;
    auto find=[&](uint32_t id)->const wide::NvseArrayState*{for(auto& a:arrays)if(a.id==id)return &a;return nullptr;};
    if(!reader.snapshot(arrays,&wanted))return reject("parent_snapshot_failed");
    for(uint32_t i=0;i<2;++i){auto* a=find(parents[i]);if(!a || a->contents.size()!=4 || a->contents[3].type!=4 || !a->contents[3].bits || a->contents[3].bits>UINT32_MAX)return reject("nested_array_missing");children[i]=uint32_t(a->contents[3].bits);wanted.insert(children[i]);}
    if(wanted.size()!=4)return reject("parent_or_child_ids_aliased");
    if(!reader.snapshot(arrays,&wanted))return reject("full_snapshot_failed");
    uint32_t expectedForm=fixtureFormHandle(slots[0],0x800);if(!expectedForm)return reject("expected_form_missing");
    auto number=[](const wide::ArrayContentElement& e,double expected){uint64_t bits=0;memcpy(&bits,&expected,8);return e.type==1 && e.bits==bits;};
    auto layout=[](const wide::NvseArrayState* a,uint8_t owner,size_t count){return a && a->owner==owner && !a->temporary && a->keyType==1 && a->packed && a->contents.size()==count && std::find(a->refs.begin(),a->refs.end(),owner)!=a->refs.end();};
    bool passed=true;
    for(uint32_t i=0;i<2;++i){auto* p=find(parents[i]);auto* c=find(children[i]);bool ok=layout(p,owners[i],4) && layout(c,owners[i],2);
        if(ok)ok=number(p->contents[0],123.25) && p->contents[1].type==3 && p->contents[1].text=="wide-array-A" && p->contents[2].type==2 && p->contents[2].bits==expectedForm && p->contents[3].type==4 && p->contents[3].bits==children[i] && number(c->contents[0],456.5) && c->contents[1].type==3 && c->contents[1].text=="wide-child-A";
        passed=passed && ok;fprintf(logFile,"WIDE_PERSISTENT_ARRAY_QUEST slot=%u parent=%u child=%u owner_byte=%u passed=%u\n",slots[i],parents[i],children[i],owners[i],ok);
    }
    if(traceArrayOwners)traceArrayOwnerCoverage(arrays,wanted);
    if(traceArrayIssueInventory)traceArrayIssueInventoryNow();
    if(arrayReleaseProbe){auto& w=arrayReleaseWitness;
        if(!w.started && passed){double outputValue=0;bool called=jipMapProbeExpression(slots[1],"StartQuest (GetFormFromMod \"NativeProbe_0690.esp\" \"000D50\")",outputValue,"WIDE_ARRAY_RELEASE_START");w.started=called;
            fprintf(logFile,"WIDE_ARRAY_RELEASE_PENDING started=%u action=wait_then_run_check_again\n",called);passed=passed && called;
        }else{
            bool ok=w.started && w.acquisitions==1 && w.releases==1 && w.array==parents[0] && w.slot==slots[1] && w.acquisitionKnown && w.removed;
            fprintf(logFile,"WIDE_ARRAY_RELEASE_CHECK passed=%u acquisitions=%u releases=%u array=%u expected_parent=%u known_acquisition=%u binding_removed=%u scope=one_native_quest_assignment\n",ok,w.acquisitions,w.releases,w.array,parents[0],w.acquisitionKnown,w.removed);passed=passed && ok;
        }fflush(logFile);
    }
    fprintf(logFile,"WIDE_PERSISTENT_ARRAY_CHECK passed=%u parents=2 children=2 elements=12 scope=current_state_not_load_proof\n",passed);fflush(logFile);*result=passed?1:0;return true;
}
static WideCommandInfo persistentArrayCheck={"WideCheckPersistentArrays","",0,"Read persistent array fixture values",0,0,nullptr,checkPersistentArrays,nullptr,nullptr,0};
static bool combinedExpression(uint32_t slot,const char* text,void* caller,SupProbeElement& output){
    auto* script=supProbeApi->expression(text);if(!script)return false;
    auto* head=(MasterNode*)((char*)script+0x10);
    struct Restore{MasterNode* head;MasterNode saved;~Restore(){*head=saved;}} restore{head,*head};
    *head={loadedFiles[slot],nullptr};
    return supProbeApi->call(script,caller,nullptr,&output,0);
}
static bool combinedLinkedReferences(uint32_t a,uint32_t b){
    void* refs[2]{};bool passed=true;
    void* quest=lookup(fixtureFormHandle(a,0xd10));
    if(!quest || *((uint8_t*)quest+4)!=0x47)return false;
    void* targetScript=*(void**)((char*)quest+0x1c);auto* locals=*(JipConditionLocals**)((char*)quest+0x5c);
    char targetName[]="*WideBatchLinkTarget";
    auto* variable=(JipConditionVariable*)jipAddedVariablesRuntime.temporaryVariable(targetScript,locals,*(uint32_t*)((char*)quest+0xc),targetName);
    bool found=false;auto* node=locals?locals->variables:nullptr;
    for(uint32_t n=0;node && n<4096;++n){JipConditionNode value{};SIZE_T got=0;
        if(!ReadProcessMemory(GetCurrentProcess(),node,&value,sizeof(value),&got) || got!=sizeof(value))break;
        if(value.variable==variable && variable){found=true;break;}node=value.next;}
    if(!found){fputs("WIDE_COMBINED_LINK_REJECTED reason=temporary_quest_variable_not_found\n",logFile);fflush(logFile);return false;}
    // Two newly spawned bottle caps are the only objects changed by this test.
    for(unsigned i=0;i<2;++i){SupProbeElement out{};
        bool called=combinedExpression(i?b:a,"PlaceAtMe (GetFormFromMod \"FalloutNV.esm\" \"00000F\") 1",*(void**)0x11DEA3C,out);
        if(called && out.type==2){memcpy(&refs[i],&out.number,4);uint32_t id=0;uint8_t type=0;SIZE_T got=0;
            if(!refs[i] || !ReadProcessMemory(GetCurrentProcess(),(char*)refs[i]+0xc,&id,4,&got) || got!=4 || id>>24!=255 || lookup(id)!=refs[i] ||
               !ReadProcessMemory(GetCurrentProcess(),(char*)refs[i]+4,&type,1,&got) || got!=1 || type!=0x3a)refs[i]=nullptr;}
        fprintf(logFile,"WIDE_COMBINED_LINK_SPAWN index=%u called=%u type=%u verified_test_ref=%u\n",i,called,out.type,refs[i]!=nullptr);fflush(logFile);
    }
    auto link=[&](uint32_t slot,void* from,void* to){
        uint64_t bits=*(uint32_t*)((char*)to+0xc);memcpy(&variable->number,&bits,8);
        fprintf(logFile,"WIDE_COMBINED_LINK_BEGIN slot=%u target_id=%08X context=fixture_quest_ref_variable\n",slot,uint32_t(bits));fflush(logFile);
        SupProbeElement output{};bool called=combinedExpression(slot,"SetLinkedReference (GetRefVariable \"*WideBatchLinkTarget\" (GetFormFromMod \"NativeProbe_0689.esp\" \"000D10\"))",from,output);
        bool ok=called && output.type==1 && output.number==1;
        SupProbeElement read{};bool readCalled=combinedExpression(slot,"GetLinkedRef",from,read);void* actual=nullptr;
        if(readCalled && read.type==2)memcpy(&actual,&read.number,4);
        ok=ok && readCalled && read.type==2 && actual==to;
        fprintf(logFile,"WIDE_COMBINED_LINK_CHECK slot=%u called=%u read_called=%u passed=%u\n",slot,called,readCalled,ok);fflush(logFile);return ok;
    };
    if(refs[0] && refs[1] && refs[0]!=refs[1]){bool one=link(a,refs[0],refs[1]);bool two=link(b,refs[1],refs[0]);passed=one && two;}else passed=false;
    for(unsigned i=0;i<2;++i)if(refs[i]){SupProbeElement output{};
        bool unlinked=combinedExpression(i?b:a,"SetLinkedReference",refs[i],output) && output.type==1 && output.number==1;
        bool disabled=combinedExpression(i?b:a,"Disable",refs[i],output);
        bool removed=combinedExpression(i?b:a,"MarkForDelete",refs[i],output);
        passed=passed && unlinked && disabled && removed;
        fprintf(logFile,"WIDE_COMBINED_LINK_CLEANUP index=%u unlinked=%u disabled=%u removed=%u\n",i,unlinked,disabled,removed);fflush(logFile);
    }
    memset(&variable->number,0,8);
    fprintf(logFile,"WIDE_COMBINED_AREA area=links passed=%u scope=runtime_set_get_cleanup owner_persistence=pending\n",passed);fflush(logFile);return passed;
}
static bool __cdecl probeCombinedCompatibility(WIDE_COMMAND_ARGS){
    *result=0;
    if(jipScriptLinkProbeMode)return queueJipScriptLinkProbe(result);
    if(timerCallbackProbeCommand){if(routeTimerCallbackProbe(scriptObj,result))return true;return probeTimerCallbacks(WIDE_PASS_ARGS);}
    if(!ready || combinedProbeRunning || !supProbeApi || !supProbeApi->compile || loadedCount!=1024){fputs("WIDE_COMBINED_REJECTED reason=not_ready_or_reentrant\n",logFile);fflush(logFile);return true;}
    uint32_t slots[]={saveFixtureSlot(0),saveFixtureSlot(1),252};
    if(slots[0]>=loadedCount || slots[1]>=loadedCount || slots[0]==slots[1]){fputs("WIDE_COMBINED_REJECTED reason=fixture_missing\n",logFile);fflush(logFile);return true;}
    combinedProbeRunning=true;struct Reset{~Reset(){combinedProbeRunning=false;}}reset;
    bool passed=true,vars=true,timers=true;uint32_t failed=0,index=0;
    fprintf(logFile,"WIDE_COMBINED_BEGIN phase=runtime_baseline slots=%u,%u,252 persistence=pending callbacks=pending additional_creation_paths=pending engine_audit=pending\n",slots[0],slots[1]);fflush(logFile);
    for(auto& test:wide::combinedProbeCases()){
        double actual=0;bool called=jipMapProbeExpression(slots[test.owner],test.expression.c_str(),actual,"WIDE_COMBINED");
        bool ok=called && (!test.compare || actual==test.expected);
        passed=passed && ok;if(!ok)++failed;if(!strcmp(test.area,"variables"))vars=vars && ok;else timers=timers && ok;
        fprintf(logFile,"WIDE_COMBINED_CASE index=%u area=%s slot=%u expected=%.17g actual=%.17g compare=%u passed=%u\n",index++,test.area,slots[test.owner],test.expected,actual,test.compare,ok);fflush(logFile);
    }
    fprintf(logFile,"WIDE_COMBINED_AREA area=variables passed=%u scope=add_values_owner_filtered_remove\nWIDE_COMBINED_AREA area=timers passed=%u scope=paused_private_public_legacy_isolation\n",vars,timers);fflush(logFile);
    bool links=combinedLinkedReferences(slots[0],slots[1]);passed=passed && links;
    double randomResult=0,arrayResult=0;
    probeShowOffRandom(params,scriptData,thisObj,containingObj,scriptObj,eventList,&randomResult,offset);
    checkPersistentArrays(params,scriptData,thisObj,containingObj,scriptObj,eventList,&arrayResult,offset);
    passed=passed && randomResult==1 && arrayResult==1;
    if(wideShowOffTimers)passed=runTimerPersistenceChecks() && passed;
    fprintf(logFile,"WIDE_COMBINED_COMPLETE phase=runtime_baseline passed=%u cases=%u failed_cases=%u links=%u random=%u arrays=%u full_compatibility_certified=0 save_load=pending\n",passed,index,failed,links,randomResult==1,arrayResult==1);fflush(logFile);
    *result=passed?1:0;return true;
}
static WideCommandInfo combinedCompatibilityProbe={"WideTestCompatibility","",0,"Run combined compatibility baseline (local diagnostic)",0,0,nullptr,probeCombinedCompatibility,nullptr,nullptr,0};
#include "timer_callback_probe.h"
static bool runWideSaveProbe(bool prepare,double* result){
    if(!prepare){traceWideStringState("check");traceCoreArrayState("check");}
    *result=0;const char* phase=prepare?"prepare":"check";
    if(!ready || loadedCount!=1024 || !wideJipPrivateMaps || !jipProbeStrings || !supProbeApi){fprintf(logFile,"WIDE_SAVE_PROBE_REJECTED phase=%s reason=not_ready\n",phase);fflush(logFile);return true;}
    void* references[2]{};
    uint32_t fixtureSlots[2]={saveFixtureSlot(0),saveFixtureSlot(1)};
    for(uint32_t i=0;i<2;++i){uint32_t slot=fixtureSlots[i];if(slot<legacySlots || slot>=loadedCount)continue;auto* entry=registry.find({slot-legacySlots,0x800});references[i]=entry?lookup(entry->handle):nullptr;}
    if(!references[0] || !references[1] || references[0]==references[1]){fprintf(logFile,"WIDE_SAVE_PROBE_REJECTED phase=%s reason=extended_reference_targets_missing_or_aliased\n",phase);fflush(logFile);return true;}
    bool passed=true;uint32_t checks=0;
    for(uint32_t i=0;i<2;++i){
        uint32_t slot=fixtureSlots[i];auto* entry=registry.find({slot-legacySlots,0xc10});auto* quest=entry?lookup(entry->handle):nullptr;
        uint32_t id=0;bool found=false;
        if(quest && *((uint8_t*)quest+4)==0x47){
            auto* locals=*(JipConditionLocals**)((char*)quest+0x5c);JipConditionLocals value{};SIZE_T got=0;
            if(locals && ReadProcessMemory(GetCurrentProcess(),locals,&value,sizeof(value),&got) && got==sizeof(value)){
                auto* node=value.variables;
                for(uint32_t n=0;node && n<4096;++n){
                    JipConditionNode nv{};if(!ReadProcessMemory(GetCurrentProcess(),node,&nv,sizeof(nv),&got) || got!=sizeof(nv))break;
                    JipConditionVariable variable{};
                    if(nv.variable && (!ReadProcessMemory(GetCurrentProcess(),nv.variable,&variable,sizeof(variable),&got) || got!=sizeof(variable)))break;
                    if(nv.variable && variable.id==1){double number=variable.number;if(number>=1 && number<=UINT32_MAX && number==double(uint32_t(number))){id=uint32_t(number);found=true;}break;}
                    node=nv.next;
                }
            }
        }
        const char* expected=i?"*WideSaveMarkerB":"*WideSaveMarkerA";
        const char* text=found?jipProbeStrings->get(id):nullptr;
        if(prepare && text && *text){jipProbeStrings->set(id,expected);text=jipProbeStrings->get(id);}
        bool ok=text && !strcmp(text,expected);passed=passed && ok;++checks;
        fprintf(logFile,"WIDE_SAVE_QUEST_STRING phase=%s slot=%u string_id=%u expected=%s actual=%s passed=%u\n",phase,slot,id,expected,text?text:"<missing>",ok);fflush(logFile);
    }
    if(prepare && !passed){fprintf(logFile,"WIDE_SAVE_PROBE_REJECTED phase=prepare reason=quest_string_not_initialized\n");fflush(logFile);return true;}
    uint32_t index=0;double value=0;
    for(auto& test:jipSaveProbeCases){
        uint32_t slot=fixtureSlots[test.slot==998?1:0];
        if(prepare){bool ok=jipMapProbeExpression(slot,test.writeExpression,value,"WIDE_SAVE_WRITE") && value==test.writeExpected;passed=passed && ok;fprintf(logFile,"WIDE_SAVE_WRITE_EXPECT index=%u expected=%.17g passed=%u\n",index,test.writeExpected,ok);fflush(logFile);}
        bool executed=jipMapProbeExpression(slot,test.readExpression,value,"WIDE_SAVE_READ");
        bool ok=executed && value==test.readExpected;passed=passed && ok;++checks;
        fprintf(logFile,"WIDE_SAVE_READ_EXPECT phase=%s index=%u expected=%.17g actual=%.17g executed=%u passed=%u\n",phase,index++,test.readExpected,value,executed,ok);fflush(logFile);
    }
    fprintf(logFile,"WIDE_SAVE_PROBE_COMPLETE phase=%s passed=%u checks=%u context=native_quest_strings_and_JIP_permanent_extended_owners codecs=unchanged\n",phase,passed,checks);fflush(logFile);*result=passed?1:0;return true;
}
static bool __cdecl prepareWideSave(WIDE_COMMAND_ARGS){return runWideSaveProbe(true,result);}
static bool __cdecl checkWideSave(WIDE_COMMAND_ARGS){return runWideSaveProbe(false,result);}
static WideCommandInfo wideSavePrepare={"WidePrepareSaveTest","",0,"Prepare permanent save markers (local diagnostic)",0,0,nullptr,prepareWideSave,nullptr,nullptr,0};
static WideCommandInfo wideSaveCheck={"WideCheckSaveTest","",0,"Read save markers without restoring them (local diagnostic)",0,0,nullptr,checkWideSave,nullptr,nullptr,0};
static bool traceWideStrings=false;
static bool traceStringOwners=false;
static bool wideStringSave=false;
static bool traceCoreArrays=false;
static bool traceArrayContents=false;
static void traceArrayImportCoverage(const char* phase,const std::vector<wide::NvseArrayState>& arrays);
static void traceCoreArrayState(const char* phase){
    if(!traceCoreArrays)return;
    try{
        wide::NvseArraySnapshot reader;std::vector<wide::NvseArrayState> arrays;
        if(!jipProbeArrays || !reader.bind(GetModuleHandleA("nvse_1_4.dll"),(void*)jipProbeArrays->create,jipProbeArrays->size,jipProbeArrays->lookup) || !reader.snapshot(arrays)){fprintf(logFile,"WIDE_ARRAY_SNAPSHOT_REJECTED phase=%s reason=version_layout_or_busy_lock\n",phase);fflush(logFile);return;}
        uint32_t permanent=0,opaque=0,opaqueRefs=0;
        for(auto& value:arrays){
            if(!value.temporary && !value.refs.empty())++permanent;
            bool extended=value.owner==253 || value.owner==254;if(extended && !value.temporary && !value.refs.empty())++opaque;
            for(auto ref:value.refs)if(ref==253 || ref==254)++opaqueRefs;
            if(extended)fprintf(logFile,"WIDE_ARRAY_NATIVE phase=%s id=%u owner_byte=%u temporary=%u elements=%u refs=%u key_type=%u packed=%u\n",phase,value.id,value.owner,value.temporary,value.elements,(uint32_t)value.refs.size(),value.keyType,value.packed);
        }
        fprintf(logFile,"WIDE_ARRAY_SNAPSHOT_SUMMARY phase=%s total=%u permanent=%u opaque_permanent=%u opaque_ref_occurrences=%u layout_checked_with_public_apis=1 scope=read_only\n",phase,(uint32_t)arrays.size(),permanent,opaque,opaqueRefs);fflush(logFile);
        traceArrayImportCoverage(phase,arrays);
    }catch(...){fprintf(logFile,"WIDE_ARRAY_SNAPSHOT_REJECTED phase=%s reason=exception\n",phase);fflush(logFile);}
}
static RuntimePatch stringApiCreateHook,stringExpressionAssignHook,stringUnusedIdHook;
struct StringOwnerState {
    wide::StringOwnerTracker tracker;SRWLOCK lock=SRWLOCK_INIT;
    uint32_t apiCreates=0,expressionAssignments=0,allocations=0;
};
static StringOwnerState& stringOwnerState(){static StringOwnerState value;return value;}
struct StringOwnerLock {SRWLOCK& lock;bool exclusive;StringOwnerLock(SRWLOCK& value,bool write):lock(value),exclusive(write){if(write)AcquireSRWLockExclusive(&lock);else AcquireSRWLockShared(&lock);}~StringOwnerLock(){if(exclusive)ReleaseSRWLockExclusive(&lock);else ReleaseSRWLockShared(&lock);}};
template<class T> static bool readStringOwnerValue(void* address,T& output){SIZE_T n=0;return address && ReadProcessMemory(GetCurrentProcess(),address,&output,sizeof(output),&n) && n==sizeof(output);}
static bool canonicalStringScriptOwner(void* script,uint32_t& slot,uint8_t& nativeByte){
    uint32_t id=0;if(!ready || !script || !readStringOwnerValue((char*)script+0xC,id) || !id)return false;
    nativeByte=id>>24;
    if(auto* key=registry.reverse(id)){slot=key->key.plugin+legacySlots;return slot<loadedCount;}
    if(nativeByte<legacySlots && nativeByte<loadedCount){slot=nativeByte;return true;}return false;
}
static uint32_t __cdecl observeStringUnusedId(){
    uint32_t id=((uint32_t(__cdecl*)())stringUnusedIdHook.trampoline)();
    if(ready)try{auto& state=stringOwnerState();StringOwnerLock guard(state.lock,true);state.tracker.allocated(id);++state.allocations;}catch(...){}return id;
}
static uint32_t __cdecl observeStringApiCreate(const char* text,void* script){
    uint32_t id=((uint32_t(__cdecl*)(const char*,void*))stringApiCreateHook.trampoline)(text,script),slot=0;uint8_t byte=0;
    if(id && canonicalStringScriptOwner(script,slot,byte)){
        try{auto& state=stringOwnerState();StringOwnerLock guard(state.lock,true);state.tracker.created(id,slot,byte);++state.apiCreates;}catch(...){}
    }return id;
}
static void* __cdecl observeStringExpressionAssign(void* output,uint32_t op,void* lhs,void* rhs,void* context){
    void* local=nullptr;double before=0;uint8_t rhsType=0;void* rhsLocal=nullptr;void* rhsString=nullptr;
    bool haveLocal=lhs && readStringOwnerValue((char*)lhs+0x10,local) && local && readStringOwnerValue((char*)local+8,before);
    bool existed=haveLocal && before>=1 && before<=UINT32_MAX && before==double(uint32_t(before)) && jipProbeStrings->get(uint32_t(before));
    bool moved=rhs && readStringOwnerValue((char*)rhs+8,rhsType) && rhsType==13 && readStringOwnerValue((char*)rhs+0x10,rhsLocal) && !rhsLocal && readStringOwnerValue((char*)rhs+0x14,rhsString) && rhsString;
    void* result=((void*(__cdecl*)(void*,uint32_t,void*,void*,void*))stringExpressionAssignHook.trampoline)(output,op,lhs,rhs,context);
    void* token=nullptr;void* script=nullptr;double after=0;uint32_t slot=0;uint8_t byte=0;
    if(haveLocal && readStringOwnerValue(output,token) && token && readStringOwnerValue((char*)local+8,after) && after>=1 && after<=UINT32_MAX && after==double(uint32_t(after)) && jipProbeStrings->get(uint32_t(after)) && context && readStringOwnerValue((char*)context+0x90,script) && canonicalStringScriptOwner(script,slot,byte)){
        try{auto& state=stringOwnerState();StringOwnerLock guard(state.lock,true);state.tracker.assigned(uint32_t(after),existed,moved,slot,byte);++state.expressionAssignments;}catch(...){}
    }return result;
}
static bool installStringOwnerTrace(){
    HMODULE module=GetModuleHandleA("nvse_1_4.dll");uint32_t base=(uint32_t)module;
    if(!jipProbeStrings || !wide::moduleMatchesSha256(module,"e82c5d348bac255a8ff4cf477df2e48149304b18f02b42b2a835c3cba71f3dfb") || (uint32_t)jipProbeStrings->create!=base+0xD4EF0)return false;
    const unsigned char create[]={0x55,0x8B,0xEC,0x8B,0x45,0x0C},assign[]={0x55,0x8B,0xEC,0x6A,0xFF},unused[]={0x55,0x8B,0xEC,0x51,0x56};
    // Complete assignment-rule neighbors identify the handler structurally.
    if(*(uint32_t*)(base+0x13BCFC)!=base+0xC0830 || memcmp((void*)(base+0x13BCF8),"\x0D\x02\x02",3) || memcmp((void*)(base+0x13BCEC),"\x0B\x00\x00",3) || memcmp((void*)(base+0x13BD04),"\x0C\x03\x03",3))return false;
    if(memcmp((void*)(base+0xD4EF0),create,sizeof(create)) || memcmp((void*)(base+0xC0830),assign,sizeof(assign)) || memcmp((void*)(base+0xD5090),unused,sizeof(unused)))return false;
    if(stringApiCreateHook.hook(base+0xD4EF0,create,sizeof(create),(void*)&observeStringApiCreate) && stringExpressionAssignHook.hook(base+0xC0830,assign,sizeof(assign),(void*)&observeStringExpressionAssign) && stringUnusedIdHook.hook(base+0xD5090,unused,sizeof(unused),(void*)&observeStringUnusedId))return true;
    stringUnusedIdHook.restore();stringExpressionAssignHook.restore();stringApiCreateHook.restore();return false;
}
struct ArrayOwnerState {wide::ArrayOwnerTracker tracker;wide::ArrayReferenceTracker references;SRWLOCK lock=SRWLOCK_INIT;uint32_t allocations=0,knownCreates=0,unknownCreates=0,referenceAdds=0,referenceRemoves=0,epoch=1;};
static ArrayOwnerState& arrayOwnerState(){static ArrayOwnerState value;return value;}
static void traceArrayOwnerCoverage(const std::vector<wide::NvseArrayState>& arrays,const std::unordered_set<uint32_t>& ids){
    auto& state=arrayOwnerState();StringOwnerLock guard(state.lock,false);uint32_t known=0,unknown=0;
    for(auto& a:arrays)if(ids.count(a.id)){
        wide::TrackedArrayOwner owner{};bool found=state.tracker.get(a.id,a.objectAddress,a.owner,owner);
        if(found)++known;else ++unknown;
        fprintf(logFile,"WIDE_ARRAY_FULL_CREATOR id=%u known=%u slot=%u owner_byte=%u\n",a.id,found,found?owner.slot:UINT32_MAX,a.owner);
        if(traceArrayReferences){auto refs=state.references.coverage(a.id,a.refs);fprintf(logFile,"WIDE_ARRAY_FULL_REF id=%u known=%u unknown=%u native_refs=%u byte_counts_match=%u lifecycle_complete=%u\n",a.id,refs.known,refs.unknown,(uint32_t)a.refs.size(),refs.byteCountsMatch,refs.lifecycleComplete);for(auto pair:refs.fullSlots)fprintf(logFile,"WIDE_ARRAY_REFERRER id=%u slot=%u count=%u\n",a.id,pair.first,pair.second);}
    }
    fprintf(logFile,"WIDE_ARRAY_CREATOR_COVERAGE known=%u unknown=%u allocations=%u known_creates=%u unknown_creates=%u scope=fixture_creators_only referrers=%s persistence=not_written\n",known,unknown,state.allocations,state.knownCreates,state.unknownCreates,traceArrayReferences?"observed_lifecycle":"untracked");fflush(logFile);
    if(traceArrayInternalCalls){fprintf(logFile,"WIDE_ARRAY_INTERNAL_CALLS foreach_remove=%u foreach_add=%u local_copy_add=%u foreach_cleanup=%u locals_bulk_remove=%u local_single_remove=%u scope=six_verified_calls\n",arrayInternalCallHits[0],arrayInternalCallHits[1],arrayInternalCallHits[2],arrayInternalCallHits[3],arrayInternalCallHits[4],arrayInternalCallHits[5]);fflush(logFile);}
    if(traceArraySelfMoves){fprintf(logFile,"WIDE_ARRAY_SELF_MOVES matched=%u missing_source=%u sites=%u,%u,%u,%u,%u,%u,%u,%u scope=eight_verified_move_sites\n",arraySelfMovesMatched,arraySelfMovesMissing,arraySelfMoveHits[0],arraySelfMoveHits[1],arraySelfMoveHits[2],arraySelfMoveHits[3],arraySelfMoveHits[4],arraySelfMoveHits[5],arraySelfMoveHits[6],arraySelfMoveHits[7]);fflush(logFile);}
    if(traceArrayPoolMoves){fprintf(logFile,"WIDE_ARRAY_POOL_MOVES calls=%ld references_moved=%ld rejected_batches=%ld metadata_errors=%ld scope=verified_nvse_pool_reallocation native_counts=unchanged\n",arrayPoolCalls,arrayPoolMoved,arrayPoolRejected,arrayPoolErrors);fflush(logFile);}
    if(traceArrayReferences){fprintf(logFile,"WIDE_ARRAY_REFERENCE_EVENTS adds=%u removes=%u divergent_removes=%u overwritten_bindings=%u incomplete_arrays=%u scope=observed_lifecycle_only persistence=not_written\n",state.referenceAdds,state.referenceRemoves,state.references.divergences(),state.references.overwrites(),state.references.incompleteArrays());fflush(logFile);}
}
static void traceArrayIssueInventoryNow(){
    try{
        auto& state=arrayOwnerState();std::vector<std::pair<uint32_t,wide::ArrayReferenceIssue>> issues;
        {StringOwnerLock guard(state.lock,false);issues=state.references.issues();}
        std::sort(issues.begin(),issues.end(),[](const auto& a,const auto& b){return a.first<b.first;});
        std::unordered_set<uint32_t> wanted;for(auto& row:issues)wanted.insert(row.first);
        wide::NvseArraySnapshot reader;std::vector<wide::NvseArrayState> live;
        bool ok=reader.bind(GetModuleHandleA("nvse_1_4.dll"),(void*)jipProbeArrays->create,jipProbeArrays->size,jipProbeArrays->lookup) && reader.snapshot(live,&wanted);
        if(!ok){fputs("WIDE_ARRAY_ISSUE_INVENTORY_REJECTED reason=native_snapshot_unavailable\n",logFile);fflush(logFile);return;}
        std::unordered_map<uint32_t,const wide::NvseArrayState*> byId;for(auto& a:live)byId[a.id]=&a;
        uint32_t present=0,absent=0,bindings=0,stale=0;StringOwnerLock guard(state.lock,false);
        // Enumerate the live map independently of recorded errors. An array
        // loaded before our observers can lack metadata without ever raising
        // an overwrite or divergence. Keep these gaps explicit.
        uint32_t creators=0,unknownCreators=0,unknownRefs=0,mismatches=0,tainted=0,complete=0,nativeRefs=0,knownRefs=0;
        uint32_t legacyCreators=0,generatedCreators=0,opaqueCreators=0,unresolvedOpaqueCreators=0;
        uint32_t legacyNativeRefs=0,generatedNativeRefs=0,opaqueNativeRefs=0;
        uint32_t unknownRefBytes[256]{};
        for(const auto& a:live){
            wide::TrackedArrayOwner owner{};bool known=state.tracker.get(a.id,a.objectAddress,a.owner,owner);
            auto refs=state.references.coverage(a.id,a.refs);
            if(known)++creators;else ++unknownCreators;
            unknownRefs+=refs.unknown;knownRefs+=refs.known;nativeRefs+=(uint32_t)a.refs.size();
            if(!refs.byteCountsMatch)++mismatches;
            if(!refs.lifecycleComplete)++tainted;
            bool covered=known && !refs.unknown && refs.byteCountsMatch && refs.lifecycleComplete;
            if(a.owner<legacySlots)++legacyCreators;
            else if(a.owner==255)++generatedCreators;
            else {++opaqueCreators;if(!known)++unresolvedOpaqueCreators;}
            for(auto byte:a.refs){if(byte<legacySlots)++legacyNativeRefs;else if(byte==255)++generatedNativeRefs;else ++opaqueNativeRefs;}
            for(const auto& binding:state.references.bindings(a.id))if(!binding.second.known)++unknownRefBytes[binding.second.nativeByte];
            if(a.owner==253 || a.owner==254){
                wide::ArrayAllocationOrigin origin{};bool observed=state.tracker.origin(a.id,a.objectAddress,a.owner,origin);
                fprintf(logFile,"WIDE_ARRAY_OPAQUE_IDENTITY id=%u creator_known=%u creator_slot=%u known_refs=%u unknown_refs=%u native_refs=%u byte_counts_match=%u lifecycle_complete=%u allocation_observed=%u caller_rva=%08X\n",a.id,known,known?owner.slot:UINT32_MAX,refs.known,refs.unknown,(uint32_t)a.refs.size(),refs.byteCountsMatch,refs.lifecycleComplete,observed,observed?origin.caller:0);
            }
            if(covered)++complete;
            else {
                fprintf(logFile,"WIDE_ARRAY_MAP_GAP id=%u temporary=%u owner_byte=%u creator_known=%u creator_slot=%u known_refs=%u unknown_refs=%u native_refs=%u byte_counts_match=%u lifecycle_complete=%u\n",a.id,a.temporary,a.owner,known,known?owner.slot:UINT32_MAX,refs.known,refs.unknown,(uint32_t)a.refs.size(),refs.byteCountsMatch,refs.lifecycleComplete);
                wide::ArrayAllocationOrigin origin{};bool observed=state.tracker.origin(a.id,a.objectAddress,a.owner,origin);
                fprintf(logFile,"WIDE_ARRAY_MAP_ORIGIN id=%u allocation_observed=%u caller_rva=%08X scope=allocation_site_only_not_owner_inference\n",a.id,observed,observed?origin.caller:0);
            }
        }
        fprintf(logFile,"WIDE_ARRAY_MAP_INVENTORY_COMPLETE live=%u tracked_creators=%u unknown_creators=%u known_refs=%u unknown_refs=%u native_refs=%u mismatched_arrays=%u tainted_arrays=%u covered_arrays=%u scope=current_live_map_metadata_not_all_path_certification persistence=not_written\n",(uint32_t)live.size(),creators,unknownCreators,knownRefs,unknownRefs,nativeRefs,mismatches,tainted,complete);
        fprintf(logFile,"WIDE_ARRAY_IDENTITY_KINDS legacy_creators=%u generated_creators=%u opaque_creators=%u unresolved_opaque_creators=%u legacy_native_refs=%u generated_native_refs=%u opaque_native_refs=%u scope=native_byte_categories_not_inferred_plugin_owners\n",legacyCreators,generatedCreators,opaqueCreators,unresolvedOpaqueCreators,legacyNativeRefs,generatedNativeRefs,opaqueNativeRefs);
        for(uint32_t byte=0;byte<256;++byte)if(unknownRefBytes[byte])fprintf(logFile,"WIDE_ARRAY_UNKNOWN_REF_BYTE owner_byte=%u count=%u scope=observed_bindings_only\n",byte,unknownRefBytes[byte]);
        for(auto& row:issues){auto found=byId.find(row.first);bool exists=found!=byId.end();const auto* a=exists?found->second:nullptr;
            if(exists)++present;else ++absent;
            auto refs=state.references.coverage(row.first,a?a->refs:std::vector<uint8_t>{});
            fprintf(logFile,"WIDE_ARRAY_ISSUE id=%u live=%u overwrites=%u divergences=%u first_caller_rva=%08X last_caller_rva=%08X known=%u unknown=%u native_refs=%u byte_counts_match=%u lifecycle_complete=%u\n",row.first,exists,row.second.overwrites,row.second.divergences,row.second.firstCaller,row.second.lastCaller,refs.known,refs.unknown,a?(uint32_t)a->refs.size():0,refs.byteCountsMatch,refs.lifecycleComplete);
            for(auto& cause:row.second.callers)fprintf(logFile,"WIDE_ARRAY_ISSUE_CAUSE id=%u caller_rva=%08X overwrites=%u divergences=%u\n",row.first,cause.first,cause.second.first,cause.second.second);
            for(auto& binding:state.references.bindings(row.first)){uint32_t at=uint32_t(binding.first>>1);bool dbl=binding.first&1;double d=0;uint32_t u=0;SIZE_T got=0;
                bool readable=dbl?ReadProcessMemory(GetCurrentProcess(),(void*)at,&d,sizeof(d),&got) && got==sizeof(d):ReadProcessMemory(GetCurrentProcess(),(void*)at,&u,sizeof(u),&got) && got==sizeof(u);
                bool matches=readable && (dbl?d==double(row.first):u==row.first);++bindings;if(!matches)++stale;
                fprintf(logFile,"WIDE_ARRAY_ISSUE_BINDING id=%u key=%016llX double=%u known=%u slot=%u readable=%u storage_matches=%u\n",row.first,(unsigned long long)binding.first,dbl,binding.second.known,binding.second.slot,readable,matches);
            }
        }
        fprintf(logFile,"WIDE_ARRAY_ISSUE_INVENTORY_COMPLETE issues=%u live=%u absent=%u bindings=%u stale_storage=%u scope=all_recorded_issue_ids_not_whole_map_certification\n",(uint32_t)issues.size(),present,absent,bindings,stale);fflush(logFile);
    }catch(...){fputs("WIDE_ARRAY_ISSUE_INVENTORY_REJECTED reason=exception\n",logFile);fflush(logFile);}
}
static RuntimePatch arrayPoolReallocHook;
static bool arrayHolderMatches(uint64_t key,uint32_t expected){
    if(key&1){double value=0;return readStringOwnerValue((void*)uint32_t(key>>1),value) && value==double(expected);}
    uint32_t value=0;return readStringOwnerValue((void*)uint32_t(key>>1),value) && value==expected;
}
static void* __fastcall observeArrayPoolRealloc(void* block,uint32_t oldBytes,uint32_t requestedBytes){
    uint32_t caller=(uint32_t)__builtin_return_address(0),base=(uint32_t)GetModuleHandleA("nvse_1_4.dll");
    wide::ArrayReferenceTracker::BlockBindings plan;uint32_t epoch=0;bool sourceMatches=true;
    if(ready){InterlockedIncrement(&arrayPoolCalls);
        if(block && requestedBytes>oldBytes)try{auto& state=arrayOwnerState();StringOwnerLock guard(state.lock,false);epoch=state.epoch;plan=state.references.blockBindings((uint32_t)block,oldBytes);for(const auto& row:plan)sourceMatches=sourceMatches && arrayHolderMatches(row.first,row.second.array);}catch(...){InterlockedIncrement(&arrayPoolErrors);auto& state=arrayOwnerState();StringOwnerLock guard(state.lock,true);state.references.poison();plan.clear();}
    }
    // Never retain our lock across the original allocator. Its output and
    // native byte copy/free behavior belong to xNVSE.
    void* result=((void*(__fastcall*)(void*,uint32_t,uint32_t))arrayPoolReallocHook.trampoline)(block,oldBytes,requestedBytes);
    if(result && result!=block && !plan.empty())try{
        auto& state=arrayOwnerState();StringOwnerLock guard(state.lock,true);if(state.epoch!=epoch)return result;
        bool copied=sourceMatches;
        for(const auto& row:plan){auto key=wide::ArrayReferenceTracker::storage((uint32_t)result+uint32_t((row.first>>1)-(uint32_t)block),row.first&1);copied=copied && arrayHolderMatches(key,row.second.array);}
        bool moved=state.references.relocateBlock(plan,(uint32_t)block,(uint32_t)result,oldBytes,caller-base,copied);
        if(moved){InterlockedExchangeAdd(&arrayPoolMoved,(LONG)plan.size());}else InterlockedIncrement(&arrayPoolRejected);
        fprintf(logFile,"WIDE_ARRAY_POOL_RELOCATION caller_rva=%08X old=%08X new=%08X old_bytes=%u requested_bytes=%u tracked=%u copied_values_match=%u moved=%u\n",caller-base,(uint32_t)block,(uint32_t)result,oldBytes,requestedBytes,(uint32_t)plan.size(),copied,moved);fflush(logFile);
    }catch(...){InterlockedIncrement(&arrayPoolErrors);auto& state=arrayOwnerState();StringOwnerLock guard(state.lock,true);state.references.poison();}
    return result;
}
static bool installArrayPoolMoves(){
    HMODULE module=GetModuleHandleA("nvse_1_4.dll");uint32_t base=(uint32_t)module;
    if(!traceArrayReferences || !wide::moduleMatchesSha256(module,"e82c5d348bac255a8ff4cf477df2e48149304b18f02b42b2a835c3cba71f3dfb"))return false;
    unsigned char expected[sizeof(wide::arrayPoolReallocSignature)];memcpy(expected,wide::arrayPoolReallocSignature,sizeof(expected));
    for(auto offset:wide::arrayPoolReallocRelocations){uint32_t value;memcpy(&value,expected+offset,4);value+=base-0x10000000;memcpy(expected+offset,&value,4);}
    if(memcmp((void*)(base+0x6B140),expected,sizeof(expected)))return false;
    if(arrayPoolReallocHook.hook(base+0x6B140,expected,8,(void*)&observeArrayPoolRealloc))return true;
    arrayPoolReallocHook.restore();return false;
}
static RuntimePatch arrayNativeCreateHook,arrayListCreateHook,arrayConstructCreateHook,arrayApiCreateHook,arrayApiStringMapHook,arrayApiMapHook;
static RuntimePatch arrayCopyCommandHook,arrayDeepCopyCommandHook,arrayTeleportLinksHook;
struct ArrayCreationContext {void* script=nullptr;uint32_t returnRva=0,secondReturnRva=0;};
static thread_local ArrayCreationContext arrayCreationContext;
struct ArrayCreationScope {
    ArrayCreationContext prior;
    ArrayCreationScope(void* script,uint32_t rva,uint32_t second=0):prior(arrayCreationContext){arrayCreationContext={script,rva,second};}
    ~ArrayCreationScope(){arrayCreationContext=prior;}
};
static void* __stdcall observeArrayNativeCreate(uint32_t key,uint32_t packed,uint32_t owner){
    uint32_t caller=(uint32_t)__builtin_return_address(0),base=(uint32_t)GetModuleHandleA("nvse_1_4.dll");
    void* object=((void*(__stdcall*)(uint32_t,uint32_t,uint32_t))arrayNativeCreateHook.trampoline)(key,packed,owner);
    if(ready && object)try{
        uint32_t id=0,slot=0;uint8_t byte=0,actual=0;
        if(!readStringOwnerValue((char*)object+0x10,id) || !readStringOwnerValue((char*)object+0x14,actual))return object;
        // Other plugin UDFs may run within a creator command. Accept only
        // that creator's exact verified call, never just the current scope.
        bool known=arrayCreationContext.script && (caller==base+arrayCreationContext.returnRva || (arrayCreationContext.secondReturnRva && caller==base+arrayCreationContext.secondReturnRva)) && canonicalStringScriptOwner(arrayCreationContext.script,slot,byte) && byte==uint8_t(owner) && actual==byte;
        auto& state=arrayOwnerState();StringOwnerLock guard(state.lock,true);
        const auto* nt=(const IMAGE_NT_HEADERS*)(base+((const IMAGE_DOS_HEADER*)base)->e_lfanew);
        uint32_t originRva=caller>=base && caller-base<nt->OptionalHeader.SizeOfImage?caller-base:0;
        state.tracker.allocated(id,(uint32_t)object,actual,originRva);if(traceArrayReferences)state.references.allocated(id);++state.allocations;
        known=known && state.tracker.created(id,(uint32_t)object,slot,byte);
        if(known)++state.knownCreates;else ++state.unknownCreates;
        if(known && slot>=legacySlots && state.knownCreates<=64){fprintf(logFile,"WIDE_ARRAY_CREATOR id=%u slot=%u owner_byte=%u caller_rva=%08X scope=verified_creation_call\n",id,slot,byte,caller-base);fflush(logFile);}
    }catch(...){}
    return object;
}
static bool __cdecl observeArrayList(WIDE_COMMAND_ARGS){ArrayCreationScope scope(scriptObj,0x21A65);return ((CommandExecute)arrayListCreateHook.trampoline)(WIDE_PASS_ARGS);}
static bool __cdecl observeArrayConstruct(WIDE_COMMAND_ARGS){ArrayCreationScope scope(scriptObj,0x1F8BF);return ((CommandExecute)arrayConstructCreateHook.trampoline)(WIDE_PASS_ARGS);}
static bool __cdecl observeArrayCopyCommand(WIDE_COMMAND_ARGS){ArrayCreationScope scope(scriptObj,0x61DF);return ((CommandExecute)arrayCopyCommandHook.trampoline)(WIDE_PASS_ARGS);}
static bool __cdecl observeArrayDeepCopyCommand(WIDE_COMMAND_ARGS){ArrayCreationScope scope(scriptObj,0x61DF);return ((CommandExecute)arrayDeepCopyCommandHook.trampoline)(WIDE_PASS_ARGS);}
static bool __cdecl observeArrayTeleportLinks(WIDE_COMMAND_ARGS){ArrayCreationScope scope(scriptObj,0x357F3,0x3586C);return ((CommandExecute)arrayTeleportLinksHook.trampoline)(WIDE_PASS_ARGS);}
static void* __cdecl observeArrayApiCreate(const void* values,uint32_t count,void* script){ArrayCreationScope scope(script,0x8F63);return ((void*(__cdecl*)(const void*,uint32_t,void*))arrayApiCreateHook.trampoline)(values,count,script);}
static void* __cdecl observeArrayApiStringMap(const char** keys,const void* values,uint32_t count,void* script){ArrayCreationScope scope(script,0x8FD9);return ((void*(__cdecl*)(const char**,const void*,uint32_t,void*))arrayApiStringMapHook.trampoline)(keys,values,count,script);}
static void* __cdecl observeArrayApiMap(const double* keys,const void* values,uint32_t count,void* script){ArrayCreationScope scope(script,0x9041);return ((void*(__cdecl*)(const double*,const void*,uint32_t,void*))arrayApiMapHook.trampoline)(keys,values,count,script);}
static bool installArrayOwnerTrace(){
    uint32_t base=(uint32_t)GetModuleHandleA("nvse_1_4.dll");
    if(!commands || !jipProbeArrays || !wide::moduleMatchesSha256((HMODULE)base,"e82c5d348bac255a8ff4cf477df2e48149304b18f02b42b2a835c3cba71f3dfb"))return false;
    auto* list=commands->getName("ar_List");
    auto* construct=commands->getName("ar_Construct");
    auto* copy=commands->getName("ar_Copy");auto* deepCopy=commands->getName("ar_DeepCopy");auto* teleport=commands->getName("GetCurrentQuestObjectiveTeleportLinks");
    if(!copy || (uint32_t)copy->execute!=base+0x21260 || !deepCopy || (uint32_t)deepCopy->execute!=base+0x21290 || !teleport || (uint32_t)teleport->execute!=base+0x357D0)return false;
    if(!list || (uint32_t)list->execute!=base+0x21A30 || !construct || (uint32_t)construct->execute!=base+0x1F790 || (uint32_t)jipProbeArrays->create!=base+0x8F40)return false;
    // Complete installed command body proves scriptObj at EBP+18,
    // owner byte at script+0F and the exact native Create return site.
    const unsigned char constructCall[]={0x8B,0x45,0x18,0x8A,0x40,0x0F,0x88,0x45,0xF8,0xFF,0x75,0xF8,0xFF,0x75,0xFC,0x51,0xE8,0xD1,0x86,0xFE,0xFF};
    if(memcmp((void*)(base+0x1F8AA),constructCall,sizeof(constructCall)))return false;
    const unsigned char constructEntry[]={0x55,0x8B,0xEC,0x8B,0x45,0x20};
    const unsigned char copyEntry[]={0x55,0x8B,0xEC,0x8B,0x55,0x0C};
    const unsigned char copyCreate[]={0xFF,0x75,0x08,0x0F,0xB6,0x46,0x16,0x50,0x0F,0xB6,0x46,0x15,0x50,0xE8,0xB1,0x1D,0,0};
    const unsigned char teleportRoot[]={0x8A,0x43,0x0F,0x88,0x44,0x24,0x14,0xFF,0x74,0x24,0x14,0x6A,0x01,0x6A,0x01,0xE8,0x9D,0x27,0xFD,0xFF};
    const unsigned char teleportChild[]={0x8A,0x43,0x0F,0x88,0x44,0x24,0x18,0xFF,0x74,0x24,0x18,0x6A,0x01,0x6A,0x01,0xE8,0x24,0x27,0xFD,0xFF};
    if(memcmp((void*)(base+0x61CD),copyCreate,sizeof(copyCreate)) || memcmp((void*)(base+0x357DF),teleportRoot,sizeof(teleportRoot)) || memcmp((void*)(base+0x35858),teleportChild,sizeof(teleportChild)))return false;
    const unsigned char native[]={0x55,0x8B,0xEC,0x6A,0xFF},api[]={0x55,0x8B,0xEC,0x83,0xE4,0xF8},map[]={0x55,0x8B,0xEC,0x8B,0x45,0x14};
    struct Site {RuntimePatch* patch;uint32_t rva;const unsigned char* bytes;uint32_t length;void* callback;};
    Site sites[]={{&arrayNativeCreateHook,0x7F90,native,sizeof(native),(void*)&observeArrayNativeCreate},
                  {&arrayListCreateHook,0x21A30,native,sizeof(native),(void*)&observeArrayList},
                  {&arrayConstructCreateHook,0x1F790,constructEntry,sizeof(constructEntry),(void*)&observeArrayConstruct},
                  {&arrayCopyCommandHook,0x21260,copyEntry,sizeof(copyEntry),(void*)&observeArrayCopyCommand},
                  {&arrayDeepCopyCommandHook,0x21290,copyEntry,sizeof(copyEntry),(void*)&observeArrayDeepCopyCommand},
                  {&arrayTeleportLinksHook,0x357D0,api,sizeof(api),(void*)&observeArrayTeleportLinks},
                  {&arrayApiCreateHook,0x8F40,api,sizeof(api),(void*)&observeArrayApiCreate},
                  {&arrayApiStringMapHook,0x8FC0,map,sizeof(map),(void*)&observeArrayApiStringMap},
                  {&arrayApiMapHook,0x9020,api,sizeof(api),(void*)&observeArrayApiMap}};
    for(auto& s:sites)if(memcmp((void*)(base+s.rva),s.bytes,s.length))return false;
    for(auto& s:sites)if(!s.patch->hook(base+s.rva,s.bytes,s.length,s.callback)){for(auto& rollback:sites)rollback.patch->restore();return false;}
    return true;
}
static RuntimePatch arrayAddReferenceHook,arrayRemoveReferenceHook,arrayDoubleReferenceHook,arrayAssignReferenceHook;
struct ArrayReferenceContext {uint64_t key=0;uint32_t returnRva=0,slot=UINT32_MAX;uint8_t byte=0;bool known=false;};
static thread_local ArrayReferenceContext arrayReferenceContext;
static thread_local ArrayReferenceContext arrayPendingReferenceContext;
struct ArrayReferenceScope {ArrayReferenceContext prior;explicit ArrayReferenceScope(ArrayReferenceContext value):prior(arrayReferenceContext){arrayReferenceContext=value;}~ArrayReferenceScope(){arrayReferenceContext=prior;}};
struct ArrayNativeReferenceAlias {uint32_t* storage=nullptr;uint64_t key=0;uint32_t slot=UINT32_MAX;uint8_t byte=0;bool known=false;};
static thread_local ArrayNativeReferenceAlias arrayNativeReferenceAlias;
struct ArrayNativeReferenceScope {ArrayNativeReferenceAlias prior;ArrayNativeReferenceScope(uint32_t* storage,uint64_t key,uint32_t slot,uint8_t byte,bool known):prior(arrayNativeReferenceAlias){arrayNativeReferenceAlias={storage,key,slot,byte,known};}~ArrayNativeReferenceScope(){arrayNativeReferenceAlias=prior;}};
static void __stdcall observeArrayRemoveReference(uint32_t* storage,uint32_t owner){
    uint32_t caller=(uint32_t)__builtin_return_address(0),base=(uint32_t)GetModuleHandleA("nvse_1_4.dll"),before=0;
    bool read=readStringOwnerValue(storage,before);
    uint64_t key=wide::ArrayReferenceTracker::storage((uint32_t)storage,false);
    auto pending=arrayPendingReferenceContext;arrayPendingReferenceContext={};bool known=false;uint32_t slot=UINT32_MAX;
    if(pending.key && caller==base+pending.returnRva){key=pending.key;known=pending.known && pending.byte==uint8_t(owner);slot=pending.slot;}
    if(caller==base+0x80AC && arrayNativeReferenceAlias.storage==storage){key=arrayNativeReferenceAlias.key;known=arrayNativeReferenceAlias.known && arrayNativeReferenceAlias.byte==uint8_t(owner);slot=arrayNativeReferenceAlias.slot;}
    ((void(__stdcall*)(uint32_t*,uint32_t))arrayRemoveReferenceHook.trampoline)(storage,owner);
    if(ready && read)try{auto& state=arrayOwnerState();StringOwnerLock guard(state.lock,true);wide::TrackedArrayReference prior{};bool existed=state.references.find(key,prior);state.references.removed(key,before,caller-base,known,slot,uint8_t(owner));++state.referenceRemoves;
        if(existed && prior.array!=before && state.references.divergences()<=32){fprintf(logFile,"WIDE_ARRAY_REMOVE_DIVERGENCE caller_rva=%08X storage=%08X logical_key=%016llX actual_target=%u tracked_target=%u tracked_known=%u tracked_slot=%u native_byte=%u\n",caller-base,(uint32_t)storage,(unsigned long long)key,before,prior.array,prior.known,prior.slot,uint8_t(owner));fflush(logFile);}
    }catch(...){}
}
static void __stdcall observeArrayAddReference(uint32_t* storage,uint32_t target,uint32_t owner){
    uint32_t base=(uint32_t)GetModuleHandleA("nvse_1_4.dll"),caller=(uint32_t)__builtin_return_address(0);
    uint64_t key=wide::ArrayReferenceTracker::storage((uint32_t)storage,false);bool known=false;uint32_t slot=UINT32_MAX;
    auto pending=arrayPendingReferenceContext;arrayPendingReferenceContext={};
    if(pending.key && caller==base+pending.returnRva){key=pending.key;known=pending.known && pending.byte==uint8_t(owner);slot=pending.slot;}
    else if(arrayReferenceContext.key && caller==base+arrayReferenceContext.returnRva){key=arrayReferenceContext.key;known=arrayReferenceContext.known && arrayReferenceContext.byte==uint8_t(owner);slot=arrayReferenceContext.slot;}
    else if(ready && (caller==base+0x4736 || caller==base+0x4752)){
        // Verified ArrayElement::SetArray: owningArray ID at storage-4.
        // Never attribute the referrer using the referenced child's creator.
        uint32_t parent=0;
        if(readStringOwnerValue((char*)storage-4,parent) && parent){
            void* object=((void*(__stdcall*)(uint32_t))(base+0x9CF0))(parent);uint8_t byte=0;
            if(object && readStringOwnerValue((char*)object+0x14,byte) && byte==uint8_t(owner)){
                auto& state=arrayOwnerState();StringOwnerLock guard(state.lock,false);wide::TrackedArrayOwner creator{};
                known=state.tracker.get(parent,(uint32_t)object,byte,creator);if(known)slot=creator.slot;
            }
        }
    }
    ArrayNativeReferenceScope alias(storage,key,slot,uint8_t(owner),known);
    ((void(__stdcall*)(uint32_t*,uint32_t,uint32_t))arrayAddReferenceHook.trampoline)(storage,target,owner);
    uint32_t after=0;
    if(ready && target && readStringOwnerValue(storage,after) && after==target)try{
        auto& state=arrayOwnerState();StringOwnerLock guard(state.lock,true);wide::TrackedArrayReference prior{};bool existed=state.references.find(key,prior);state.references.added(key,target,uint8_t(owner),known,slot,caller-base);++state.referenceAdds;
        if(existed && prior.array!=target && state.references.overwrites()<=32){fprintf(logFile,"WIDE_ARRAY_ADD_OVERWRITE caller_rva=%08X storage=%08X logical_key=%016llX new_target=%u tracked_target=%u tracked_known=%u tracked_slot=%u new_known=%u new_slot=%u\n",caller-base,(uint32_t)storage,(unsigned long long)key,target,prior.array,prior.known,prior.slot,known,slot);fflush(logFile);}
    }catch(...){}
}
static void __stdcall observeArrayDoubleReference(double* storage,uint32_t target,uint32_t owner){
    ArrayReferenceScope scope({wide::ArrayReferenceTracker::storage((uint32_t)storage,true),0x82D2,UINT32_MAX,uint8_t(owner),false});
    ((void(__stdcall*)(double*,uint32_t,uint32_t))arrayDoubleReferenceHook.trampoline)(storage,target,owner);
}
static void* __cdecl observeArrayAssignment(void* output,uint32_t op,void* lhs,void* rhs,void* context){
    void* local=nullptr;void* script=nullptr;uint32_t slot=UINT32_MAX;uint8_t byte=0;
    bool known=lhs && readStringOwnerValue((char*)lhs+0x10,local) && local && context && readStringOwnerValue((char*)context+0x90,script) && canonicalStringScriptOwner(script,slot,byte);
    ArrayReferenceScope scope({local?wide::ArrayReferenceTracker::storage((uint32_t)local+8,true):0,0xC0E02,slot,byte,known});
    uint32_t scriptId=0;double before=0,after=0;
    bool witness=false;
    if(arrayReleaseProbe && known && readStringOwnerValue((char*)script+0xc,scriptId)){
        auto* entry=registry.reverse(scriptId);witness=entry && entry->key.local==0xd40 && slot==saveFixtureSlot(1) && readStringOwnerValue((char*)local+8,before);
    }
    void* value=((void*(__cdecl*)(void*,uint32_t,void*,void*,void*))arrayAssignReferenceHook.trampoline)(output,op,lhs,rhs,context);
    if(witness && readStringOwnerValue((char*)local+8,after))try{
        auto& state=arrayOwnerState();StringOwnerLock guard(state.lock,false);wide::TrackedArrayReference ref{};
        bool exists=state.references.find(arrayReferenceContext.key,ref);auto& w=arrayReleaseWitness;
        if(before==0 && after>=1 && after<=UINT32_MAX && after==double(uint32_t(after))){
            ++w.acquisitions;w.array=uint32_t(after);w.slot=slot;w.key=arrayReferenceContext.key;w.acquisitionKnown=exists && ref.known && ref.slot==slot && ref.array==w.array;
            fprintf(logFile,"WIDE_ARRAY_RELEASE_ACQUIRE slot=%u array=%u known=%u key=%016llX\n",slot,w.array,w.acquisitionKnown,(unsigned long long)w.key);
        }
        if(before>=1 && before<=UINT32_MAX && before==double(uint32_t(before)) && after==0){
            ++w.releases;w.removed=!exists && w.key==arrayReferenceContext.key && w.array==uint32_t(before);
            fprintf(logFile,"WIDE_ARRAY_RELEASE_DROP slot=%u array=%u binding_absent=%u same_key=%u\n",slot,uint32_t(before),!exists,w.key==arrayReferenceContext.key);
        }fflush(logFile);
    }catch(...){}
    return value;
}
static RuntimePatch arrayInternalCallPatches[6];
static void __cdecl captureArrayInternalReference(uint32_t* frame,uint32_t kind){
    arrayPendingReferenceContext={};if(kind>=6)return;
    // pushad: EDI, ESI, EBP, original ESP, EBX, EDX, ECX, EAX.
    uint32_t local=0;void* script=nullptr;bool read=false;
    if(kind<4 && kind!=2){local=frame[kind==0?4:1];read=readStringOwnerValue((void*)(frame[0]+0x20),script);}
    else if(kind==2){void* list=nullptr;read=readStringOwnerValue((void*)(frame[2]-8),local) && readStringOwnerValue((void*)(frame[2]-0x10),list) && list && readStringOwnerValue(list,script);}
    else{local=frame[0];void* list=nullptr;read=kind==4?readStringOwnerValue((void*)(frame[2]-0x14),list):(list=(void*)frame[4],list!=nullptr);read=read && list && readStringOwnerValue(list,script);}
    uint32_t slot=UINT32_MAX;uint8_t byte=0;bool known=read && canonicalStringScriptOwner(script,slot,byte);
    if(local)arrayPendingReferenceContext={wide::ArrayReferenceTracker::storage(local+8,true),kind==0?0x46E2Bu:kind==1?0x46E6Fu:kind==2?0x7749Du:kind==3?0x90B91u:kind==4?0x8676Fu:0x8698Cu,slot,byte,known};
    ++arrayInternalCallHits[kind];
}
static bool installArrayInternalCalls(){
    uint32_t base=(uint32_t)GetModuleHandleA("nvse_1_4.dll");
    if(!traceArrayReferences || !wide::moduleMatchesSha256((HMODULE)base,"e82c5d348bac255a8ff4cf477df2e48149304b18f02b42b2a835c3cba71f3dfb"))return false;
    const uint32_t sites[]={0x46E26,0x46E6A,0x77498,0x90B8C,0x8676A,0x86987},targets[]={0x81D0,0x8080,0x8080,0x81D0,0x81D0,0x81D0};
    const unsigned char before0[]={0xFF,0x75,0xF0,0x89,0x45,0x0C,0x8D,0x45,0x0C,0x50};
    const unsigned char before1[]={0xFF,0x75,0xF0,0x89,0x45,0x0C,0x8D,0x45,0x0C,0xFF,0x77,0x08,0x50};
    const unsigned char before2[]={0x50,0x8D,0x45,0xEC,0x50};
    if(memcmp((void*)(base+sites[0]-sizeof(before0)),before0,sizeof(before0)) || memcmp((void*)(base+sites[1]-sizeof(before1)),before1,sizeof(before1)) || memcmp((void*)(base+sites[2]-sizeof(before2)),before2,sizeof(before2)))return false;
    const unsigned char before3[]={0x8B,0x47,0x20,0x0F,0xB6,0x40,0x0F,0x50,0x8D,0x45,0xF0,0x50};
    if(memcmp((void*)(base+sites[3]-sizeof(before3)),before3,sizeof(before3)))return false;
    const unsigned char before4[]={0x8B,0x45,0xEC,0x8B,0x00,0x0F,0xB6,0x40,0x0F,0x50,0x8D,0x45,0xF0,0x50};
    const unsigned char before5[]={0x8B,0x03,0x0F,0xB6,0x40,0x0F,0x50,0x8D,0x45,0xEC,0x50};
    if(memcmp((void*)(base+sites[4]-sizeof(before4)),before4,sizeof(before4)) || memcmp((void*)(base+sites[5]-sizeof(before5)),before5,sizeof(before5)))return false;
    unsigned char expected[6][5];void* bridges[6]{};
    for(uint32_t i=0;i<6;++i){expected[i][0]=0xE8;*(uint32_t*)(expected[i]+1)=targets[i]-sites[i]-5;if(memcmp((void*)(base+sites[i]),expected[i],5))return false;}
    for(uint32_t i=0;i<6;++i){
        bridges[i]=VirtualAlloc(nullptr,256,MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);
        if(!bridges[i]){for(auto p:bridges)if(p)VirtualFree(p,0,MEM_RELEASE);return false;}
        auto code=wide::buildArrayReferenceCallBridge((uint32_t)bridges[i],(uint32_t)&captureArrayInternalReference,i,base+targets[i]);memcpy(bridges[i],code.data(),code.size());FlushInstructionCache(GetCurrentProcess(),bridges[i],code.size());
    }
    for(uint32_t i=0;i<6;++i){unsigned char replacement[5]={0xE8};*(uint32_t*)(replacement+1)=(uint32_t)bridges[i]-base-sites[i]-5;
        if(!arrayInternalCallPatches[i].replace(base+sites[i],expected[i],replacement,5)){for(auto& p:arrayInternalCallPatches)p.restore();for(auto p:bridges)VirtualFree(p,0,MEM_RELEASE);return false;}
    }return true;
}
static RuntimePatch arraySelfMovePatches[8];
static void __cdecl observeArraySelfMove(uint32_t* frame,uint32_t kind){
    if(kind>=8)return;uint32_t source=0,dest=0;
    if(kind<4){source=frame[2]-(kind==0 || kind==2?0x58:0x54);dest=frame[6];}
    else if(kind==4){source=frame[6]-24;dest=frame[1]-24;}
    else if(kind==5){source=frame[6]-24;dest=frame[1];}
    else if(kind==6){source=frame[6];dest=frame[5];}
    else{source=frame[6];dest=frame[4]+0x18;}
    ++arraySelfMoveHits[kind];uint8_t type=0;uint32_t id=0;
    if(!source || !dest || !readStringOwnerValue((void*)(dest+8),type) || type!=4 || !readStringOwnerValue((void*)(dest+0x10),id) || !id)return;
    try{auto& state=arrayOwnerState();StringOwnerLock guard(state.lock,true);
        bool matched=state.references.moved(wide::ArrayReferenceTracker::storage(source+0x10,false),wide::ArrayReferenceTracker::storage(dest+0x10,false),id,0x494D);
        if(matched)++arraySelfMovesMatched;else ++arraySelfMovesMissing;
    }catch(...){}
}
static bool installArraySelfMoves(){
    uint32_t base=(uint32_t)GetModuleHandleA("nvse_1_4.dll");
    if(!traceArrayReferences || !wide::moduleMatchesSha256((HMODULE)base,"e82c5d348bac255a8ff4cf477df2e48149304b18f02b42b2a835c3cba71f3dfb"))return false;
    const uint32_t sites[]={0x3E7A9,0x3EEAA,0x42F84,0x4334B,0x438F2,0x45B8F,0x45927,0x45530};
    const unsigned char op[][3]={{0xC7,0x01,0},{0xC7,0x01,0},{0xC7,0x01,0},{0xC7,0x01,0},{0xC7,0x46,0xE8},{0xC7,0x06,0},{0xC7,0x02,0},{0xC7,0x43,0x18}};
    for(auto& prefix:arraySelfMovePrefixes)if(memcmp((void*)(base+prefix.rva),prefix.bytes,prefix.length))return false;
    std::vector<unsigned char> expected[8];void* bridges[8]{};
    for(uint32_t i=0;i<8;++i){expected[i].assign(op[i],op[i]+(i==4 || i==7?3:2));uint32_t vtable=base+0x10838C;for(uint32_t j=0;j<4;++j)expected[i].push_back(uint8_t(vtable>>(j*8)));if(memcmp((void*)(base+sites[i]),expected[i].data(),expected[i].size()))return false;}
    for(uint32_t i=0;i<8;++i){bridges[i]=VirtualAlloc(nullptr,256,MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);if(!bridges[i]){for(auto p:bridges)if(p)VirtualFree(p,0,MEM_RELEASE);return false;}
        auto code=wide::buildArrayReferenceMoveBridge((uint32_t)bridges[i],(uint32_t)&observeArraySelfMove,i,expected[i],base+sites[i]+(uint32_t)expected[i].size());memcpy(bridges[i],code.data(),code.size());FlushInstructionCache(GetCurrentProcess(),bridges[i],code.size());
    }
    for(uint32_t i=0;i<8;++i){std::vector<unsigned char> replacement(expected[i].size(),0x90);replacement[0]=0xE9;*(uint32_t*)(replacement.data()+1)=(uint32_t)bridges[i]-base-sites[i]-5;
        if(!arraySelfMovePatches[i].replace(base+sites[i],expected[i].data(),replacement.data(),(uint32_t)replacement.size())){for(auto& p:arraySelfMovePatches)p.restore();for(auto p:bridges)VirtualFree(p,0,MEM_RELEASE);return false;}
    }return true;
}
static bool installArrayReferenceTrace(){
    uint32_t base=(uint32_t)GetModuleHandleA("nvse_1_4.dll");
    if(!traceArrayOwners || !wide::moduleMatchesSha256((HMODULE)base,"e82c5d348bac255a8ff4cf477df2e48149304b18f02b42b2a835c3cba71f3dfb"))return false;
    if(memcmp((void*)(base+0x13BD28),"\x0E\x06\x06",3) || *(uint32_t*)(base+0x13BD2C)!=base+0xC0DC0)return false;
    const unsigned char ref[]={0x55,0x8B,0xEC,0x64,0xA1,0,0,0,0},dbl[]={0x55,0x8B,0xEC,0x56,0x8B,0x75,0x08},assign[]={0x55,0x8B,0xEC,0x83,0xEC,0x08};
    struct Site {RuntimePatch* patch;uint32_t rva;const unsigned char* bytes;uint32_t length;void* callback;};
    Site sites[]={{&arrayAddReferenceHook,0x8080,ref,sizeof(ref),(void*)&observeArrayAddReference},
                  {&arrayRemoveReferenceHook,0x81D0,ref,sizeof(ref),(void*)&observeArrayRemoveReference},
                  {&arrayDoubleReferenceHook,0x82B0,dbl,sizeof(dbl),(void*)&observeArrayDoubleReference},
                  {&arrayAssignReferenceHook,0xC0DC0,assign,sizeof(assign),(void*)&observeArrayAssignment}};
    for(auto& s:sites)if(memcmp((void*)(base+s.rva),s.bytes,s.length))return false;
    for(auto& s:sites)if(!s.patch->hook(base+s.rva,s.bytes,s.length,s.callback)){for(auto& rollback:sites)rollback.patch->restore();return false;}
    return true;
}
// Read-only diagnostic: hashes all strings and exposes the two known test locals.
// It cannot restore a value or certify general string ownership.
static void traceWideStringState(const char* phase){
    if(!traceWideStrings || !jipProbeStrings)return;
    try{
        wide::NvseStringSnapshot reader;std::vector<wide::NvseStringState> values;
        if(!reader.bind(GetModuleHandleA("nvse_1_4.dll"),jipProbeStrings->get,(void*)jipProbeStrings->set,(void*)jipProbeStrings->create) || !reader.snapshot(values)){
            fprintf(logFile,"WIDE_STRING_TRACE_REJECTED phase=%s reason=version_layout_or_read\n",phase);fflush(logFile);return;
        }
        uint32_t permanent=0,wideOwners=0;
        for(const auto& value:values){
            if(!value.temporary && !value.cache){++permanent;if(value.owner==253 || value.owner==254)++wideOwners;}
            if(value.owner==253 || value.owner==254)fprintf(logFile,"WIDE_STRING_NATIVE phase=%s id=%u owner_byte=%u temporary=%u cache=%u length=%u crc=%08X\n",phase,value.id,value.owner,value.temporary,value.cache,value.length,value.crc);
        }
        fprintf(logFile,"WIDE_STRING_TRACE_SUMMARY phase=%s total=%u permanent=%u opaque_owner_permanent=%u layout_checked_with_public_getter=1\n",phase,(uint32_t)values.size(),permanent,wideOwners);
        if(traceStringOwners){
            auto& state=stringOwnerState();StringOwnerLock guard(state.lock,false);uint32_t known=0,unknown=0;
            for(auto value:values)if(!value.temporary && !value.cache && (value.owner==253 || value.owner==254)){
                wide::TrackedStringOwner owner{};bool tracked=state.tracker.get(value.id,value.owner,owner);
                if(tracked)++known;else ++unknown;
                fprintf(logFile,"WIDE_STRING_FULL_OWNER phase=%s id=%u known=%u slot=%u owner_byte=%u\n",phase,value.id,tracked,tracked?owner.slot:UINT32_MAX,value.owner);
            }
            fprintf(logFile,"WIDE_STRING_OWNER_COVERAGE phase=%s known_opaque=%u unknown_opaque=%u api_creates=%u expression_assignments=%u allocations=%u scope=creation_and_expression_paths_only\n",phase,known,unknown,state.apiCreates,state.expressionAssignments,state.allocations);fflush(logFile);
        }
        for(uint32_t i=0;i<2;++i){
            uint32_t slot=saveFixtureSlot(i);auto* entry=slot>=legacySlots && slot<loadedCount?registry.find({slot-legacySlots,0xC10}):nullptr;auto* quest=entry?lookup(entry->handle):nullptr;bool found=false;double number=0;const char* text=nullptr;
            if(quest && *((uint8_t*)quest+4)==0x47){
                auto* locals=*(JipConditionLocals**)((char*)quest+0x5C);JipConditionLocals value{};SIZE_T got=0;
                if(locals && ReadProcessMemory(GetCurrentProcess(),locals,&value,sizeof(value),&got) && got==sizeof(value)){
                    std::unordered_set<JipConditionNode*> seen;
                    for(auto* node=value.variables;node && seen.size()<4096 && seen.insert(node).second;){
                        JipConditionNode item{};JipConditionVariable variable{};
                        if(!ReadProcessMemory(GetCurrentProcess(),node,&item,sizeof(item),&got) || got!=sizeof(item))break;
                        if(item.variable && ReadProcessMemory(GetCurrentProcess(),item.variable,&variable,sizeof(variable),&got) && got==sizeof(variable) && variable.id==1){
                            found=true;number=variable.number;if(number>=1 && number<=UINT32_MAX && number==double(uint32_t(number)))text=jipProbeStrings->get(uint32_t(number));break;
                        }node=item.next;
                    }
                }
            }
            fprintf(logFile,"WIDE_STRING_QUEST_LOCAL phase=%s slot=%u found=%u raw=%.17g string_present=%u value=%s\n",phase,slot,found,number,text!=nullptr,text?text:"<missing>");
        }
        // Known saved marker IDs are diagnostic inputs from the independently
        // inspected original Autosave - 3, never used to synthesize values.
        for(uint32_t id:{5928u,5927u}){const char* text=jipProbeStrings->get(id);fprintf(logFile,"WIDE_STRING_SAVED_MARKER_ID phase=%s id=%u present=%u value=%s\n",phase,id,text!=nullptr,text?text:"<missing>");}
        fflush(logFile);
    }catch(...){fprintf(logFile,"WIDE_STRING_TRACE_FAILED phase=%s\n",phase);fflush(logFile);}
}
struct SaveIdentityState {
    bool present=false,valid=false;uint32_t missingPlugins=0,missingForms=0;
    wide::SaveIdentities identities;
    std::unordered_map<uint32_t,uint32_t> savedToCurrent;
    wide::JipSave jip;bool jipPresent=false,jipValid=false,jipRestored=false;
    wide::ScriptLinkSave scriptLinks;bool scriptLinksPresent=false,scriptLinksValid=false,scriptLinksRestored=false;
    wide::TimerSave timers;bool timersPresent=false,timersValid=false,timersRestored=false;
    std::vector<uint32_t> slots;
};
static bool wideJipSave=false;
static wide::JipSaveRuntime& jipSaveRuntime(){static wide::JipSaveRuntime runtime;return runtime;}
// Construct only when a save callback runs, after engine startup.
static SaveIdentityState& saveIdentityState(){static SaveIdentityState state;return state;}
#include "jip_script_link_probe.h"
static bool queueJipScriptLinkProbe(double* result){
    auto& state=jipScriptLinkProbeState();*result=0;
    if(!ready || !wideJipScriptLinks || state.queued || loadedCount!=1024)return true;
    state.queued=true;state.requested=GetTickCount();*result=1;
    fprintf(logFile,"WIDE_JIP_SCRIPT_LINK_PROBE_QUEUED mode=%u\n",jipScriptLinkProbeMode);fflush(logFile);return true;
}
static bool runTimerPersistenceChecks(){
    auto& state=saveIdentityState();bool passed=!timerRestoreOnly || state.timersRestored;
    uint32_t slots[]={saveFixtureSlot(0),saveFixtureSlot(1),252,saveFixtureSlot(0)};
    const char* names[]={"WideSavedTimer","WideSavedTimer","WideSavedTimer","_WideSavedPublic"};double expected[]={111,222,777,888};
    for(unsigned i=0;i<4;++i){double value=0;char expression[160];
        if(!timerRestoreOnly){snprintf(expression,sizeof(expression),"AuxTimerStart \"%s\" %.0f 39",names[i],expected[i]);
            passed=jipMapProbeExpression(slots[i],expression,value,"WIDE_TIMER_PERSIST") && value==1 && passed;}
        for(const char* command:{"AuxTimerTimeToCountdown","AuxTimerTimeLeft","AuxTimerPaused"}){snprintf(expression,sizeof(expression),"%s \"%s\"",command,names[i]);
            bool called=jipMapProbeExpression(slots[i],expression,value,"WIDE_TIMER_PERSIST");double want=!strcmp(command,"AuxTimerPaused")?1:expected[i];
            bool ok=called && value==want;passed=passed && ok;
            fprintf(logFile,"WIDE_TIMER_PERSIST_CASE slot=%u name=%s command=%s expected=%.17g actual=%.17g passed=%u\n",slots[i],names[i],command,want,value,ok);fflush(logFile);}
    }
    fprintf(logFile,"WIDE_TIMER_PERSIST_COMPLETE phase=%s passed=%u restore_record=%u cases=12\n",timerRestoreOnly?"restore":"seed",passed,state.timersRestored);fflush(logFile);return passed;
}
static bool wideNativeSaveRefs=false;
static bool fixedOrderWideStrings=false,coreStringPreloadActive=false,coreStringGateChecked=false,coreStringGateAccepted=false;
static bool wideStringLoad=false;
struct StringRestoreState {wide::StringRestoreCatalog catalog;size_t next=0;bool checked=false,valid=false;};
static StringRestoreState& stringRestoreState(){static StringRestoreState state;return state;}
static uint32_t coreStringOwnersRestored=0;
static RuntimePatch coreStringOwnerPatch;
static bool fixedOrderWideArrays=false;
static bool wideArrayReorder=false;
static bool wideArrayBoundary=false;
struct CoreArrayLoadState {bool checked=false,valid=false;wide::ArrayGate gate;wide::ArrayLoadStream stream;std::vector<uint32_t> slots;std::unordered_map<uint32_t,uint32_t> forms;uint32_t owners=0,refs=0,formsMapped=0,formsMissing=0;};
static CoreArrayLoadState& coreArrayLoadState(){static CoreArrayLoadState state;return state;}
static bool remapCoreArrayValue(uint32_t saved,uint32_t& mapped){
    auto& state=coreArrayLoadState();
    if(saved<0x800){mapped=saved;return true;}
    if(saved>>24==253 || saved>>24==254){auto it=state.forms.find(saved);if(it==state.forms.end())return false;mapped=it->second;return true;}
    if(wideArrayBoundary && saved>>24<253){uint32_t slot=saved>>24,local=saved&0xFFFFFF;
        if(slot>=state.slots.size())return false;slot=state.slots[slot];
        if(slot<legacySlots){mapped=(slot<<24)|local;return true;}
        auto* entry=registry.find({slot-legacySlots,local});if(!entry)return false;mapped=entry->handle;return true;}
    if(!saveSerialization->resolveRef(saved,&mapped))mapped=0;return true;
}
static void traceArrayImportCoverage(const char* phase,const std::vector<wide::NvseArrayState>& arrays){
    if(!fixedOrderWideArrays)return;auto& state=coreArrayLoadState();if(!state.valid)return;uint32_t passed=0;
    for(size_t i=0;i<state.gate.opaqueIds.size();++i){uint32_t id=state.gate.opaqueIds[i],expected=state.gate.opaqueElements[i];const wide::NvseArrayState* found=nullptr;for(auto& value:arrays)if(value.id==id){found=&value;break;}bool ok=found && !found->temporary && (found->owner==253 || found->owner==254) && found->elements==expected;if(ok)++passed;fprintf(logFile,"WIDE_ARRAY_IMPORT_ID phase=%s id=%u present=%u expected_elements=%u actual_elements=%u passed=%u\n",phase,id,found!=nullptr,expected,found?found->elements:0,ok);}
    fprintf(logFile,"WIDE_ARRAY_IMPORT_COVERAGE phase=%s passed=%u expected=%u scope=saved_ID_owner_and_element_count_only\n",phase,passed,(uint32_t)state.gate.opaqueIds.size());fflush(logFile);
    if(traceArrayContents && (!strcmp(phase,"preload") || !strcmp(phase,"load"))){
        std::unordered_set<uint32_t> ids;for(auto& sample:state.gate.contents)ids.insert(sample.id);
        wide::NvseArraySnapshot reader;std::vector<wide::NvseArrayState> values;
        if(!reader.bind(GetModuleHandleA("nvse_1_4.dll"),(void*)jipProbeArrays->create,jipProbeArrays->size,jipProbeArrays->lookup) || !reader.snapshot(values,&ids)){fprintf(logFile,"WIDE_ARRAY_CONTENT_REJECTED phase=%s reason=layout_or_busy_lock\n",phase);fflush(logFile);return;}
        uint32_t passedArrays=0,totalElements=0,passedElements=0,numeric=0,strings=0,forms=0,extendedForms=0,nested=0;
        auto remap=[](uint32_t saved,uint32_t& mapped){return remapCoreArrayValue(saved,mapped);};
        for(auto& sample:state.gate.contents){
            const wide::NvseArrayState* found=nullptr;for(auto& value:values)if(value.id==sample.id){found=&value;break;}
            wide::ArrayContentComparison comparison;comparison.passed=false;comparison.reason="array_missing";
            if(found){wide::ArrayContent actual;actual.id=found->id;actual.owner=found->owner;actual.key=found->keyType;actual.packed=found->packed;actual.elements=found->contents;comparison=wide::compareArrayContents(sample,actual,remap);}
            totalElements+=(uint32_t)sample.elements.size();if(comparison.passed){++passedArrays;passedElements+=comparison.checked;}
            numeric+=comparison.numeric;strings+=comparison.strings;forms+=comparison.forms;extendedForms+=comparison.extendedForms;nested+=comparison.nested;
            fprintf(logFile,"WIDE_ARRAY_CONTENT phase=%s id=%u present=%u passed=%u elements=%u first_failure=%u reason=%s\n",phase,sample.id,found!=nullptr,comparison.passed,(uint32_t)sample.elements.size(),comparison.firstFailure,comparison.reason);
        }
        fprintf(logFile,"WIDE_ARRAY_CONTENT_SUMMARY phase=%s arrays_passed=%u arrays_expected=%u elements_in_passed_arrays=%u elements_expected=%u numeric=%u strings=%u forms=%u extended_forms=%u nested=%u scope=saved_keys_and_values_before_gameplay\n",phase,passedArrays,(uint32_t)state.gate.contents.size(),passedElements,totalElements,numeric,strings,forms,extendedForms,nested);fflush(logFile);
    }
}
static void prepareCoreArrayGate(){
    auto& state=coreArrayLoadState();if(state.checked)return;state.checked=true;const char* path=saveSerialization->savePath();
    try{
        std::unique_ptr<FILE,decltype(&fclose)> file(path?fopen(path,"rb"):nullptr,&fclose);
        if(file){
            std::vector<unsigned char> bytes;unsigned char buffer[8192];bool good=true;
            for(;;){size_t n=fread(buffer,1,sizeof(buffer),file.get());if(!n){if(ferror(file.get()))good=false;break;}if(n>wide::maxIdentityBytes-bytes.size()){good=false;break;}bytes.insert(bytes.end(),buffer,buffer+n);}
            std::vector<std::string> current;for(uint32_t i=0;i<loadedCount;++i)current.emplace_back((char*)loadedFiles[i]+0x20);
            wide::ArrayRestoreCatalog catalog;
            state.valid=good && (!(wideArrayReorder || wideArrayBoundary) || wide::buildArrayRestoreCatalog(bytes.data(),bytes.size(),current,catalog,true,wideArrayBoundary)) && wide::validateFixedOrderArraySave(bytes.data(),bytes.size(),(wideArrayReorder || wideArrayBoundary)?catalog.savedPlugins:current,state.gate);
            if(state.valid){
                state.slots=catalog.slots;
                if(wideArrayBoundary){state.stream.entries=catalog.stream;for(auto& sample:state.gate.contents)sample.owner=catalog.contents.at(sample.id).owner;}
                if(wideArrayBoundary){fprintf(logFile,"WIDE_ARRAY_BYTE_MIGRATION owners_changed=%u ref_bytes_changed=%u scope=validated_native_stream_plan\n",catalog.nativeOwnersChanged,catalog.nativeRefsChanged);fflush(logFile);}
                for(auto form:state.gate.identities.forms){uint32_t slot=(wideArrayReorder || wideArrayBoundary)?catalog.slots.at(form.slot):form.slot;uint32_t handle=0;if(slot<legacySlots)handle=(slot<<24)|form.local;else{auto* entry=registry.find({slot-legacySlots,form.local});if(entry)handle=entry->handle;}if(handle)state.forms.emplace(form.handle,handle);}
            }
        }
    }catch(...){state.valid=false;state.forms.clear();}
    fprintf(logFile,"WIDE_ARRAY_LOAD_GATE valid=%u arrays=%u opaque_arrays=%u opaque_refs=%u opaque_form_elements=%u manifest_crc=%08X path=%s scope=%s\n",state.valid,state.gate.arrays,(uint32_t)state.gate.opaqueIds.size(),state.gate.opaqueRefs,state.gate.opaqueForms,state.gate.manifestCrc,path?path:"unavailable",wideArrayBoundary?"full_identity_native_byte_migration":wideArrayReorder?"byte_preserving_opaque_permutation":"identical_full_plugin_order");fflush(logFile);
}
static uint32_t resolveArrayOwnerByte(uint32_t owner,bool reference){
    if(coreStringPreloadActive){prepareCoreArrayGate();auto& state=coreArrayLoadState();if(state.valid && (owner==253 || owner==254)){if(reference)++state.refs;else ++state.owners;return owner;}}
    if(owner==255)return 255;uint32_t mapped=0;return saveSerialization->resolveRef(owner<<24,&mapped)?mapped>>24:255;
}
static uint32_t __cdecl resolveCoreArrayOwner(uint32_t owner){
    if(coreStringPreloadActive && wideArrayBoundary){prepareCoreArrayGate();auto& state=coreArrayLoadState();uint8_t mapped=255;
        if(!state.valid || !state.stream.owner((uint8_t)owner,mapped))stop("array owner stream differs from validated identity catalog");++state.owners;return mapped;}
    return resolveArrayOwnerByte(owner,false);
}
static uint32_t __cdecl resolveCoreArrayReference(uint32_t owner){return resolveArrayOwnerByte(owner,true);}
static uint32_t __cdecl resolveCoreArrayReferenceContext(uint32_t owner,uint32_t id,uint32_t ordinal){
    if(coreStringPreloadActive && wideArrayBoundary){auto& state=coreArrayLoadState();uint8_t mapped=255;
        if(!state.valid || !state.stream.reference(id,ordinal,(uint8_t)owner,mapped))stop("array reference stream differs from validated identity catalog");++state.refs;return mapped;}
    return resolveArrayOwnerByte(owner,true);
}
static uint32_t __cdecl resolveCoreArrayForm(uint32_t saved){
    if(coreStringPreloadActive && wideArrayBoundary){prepareCoreArrayGate();uint32_t mapped=0;if(!coreArrayLoadState().valid || !remapCoreArrayValue(saved,mapped)){++coreArrayLoadState().formsMissing;return 0;}++coreArrayLoadState().formsMapped;return mapped;}
    if(coreStringPreloadActive && (saved>>24==253 || saved>>24==254)){
        prepareCoreArrayGate();auto& state=coreArrayLoadState();auto it=state.forms.find(saved);
        if(state.valid && it!=state.forms.end()){++state.formsMapped;return it->second;}
        ++state.formsMissing;return 0;
    }
    uint32_t mapped=0;return saveSerialization->resolveRef(saved,&mapped)?mapped:0;
}
static RuntimePatch coreArrayPatches[3];
static bool installFixedOrderArrays(){
    HMODULE module=GetModuleHandleA("nvse_1_4.dll");uint32_t base=(uint32_t)module;
    if(!wide::moduleMatchesSha256(module,"e82c5d348bac255a8ff4cf477df2e48149304b18f02b42b2a835c3cba71f3dfb"))return false;
    std::vector<unsigned char> expected[3];void* bridges[3]{};
    for(unsigned i=0;i<3;++i){auto& s=arrayPatchSignatures[i];expected[i].assign(s.bytes,s.bytes+s.length);for(uint32_t j=0;j<s.relocCount;++j){uint32_t value;memcpy(&value,expected[i].data()+s.reloc[j],4);value+=base-0x10000000;memcpy(expected[i].data()+s.reloc[j],&value,4);}if(memcmp((void*)(base+s.rva),expected[i].data(),s.length))return false;}
    bool good=true;
    for(unsigned i=0;i<3 && good;++i){
        auto& s=arrayPatchSignatures[i];bridges[i]=VirtualAlloc(nullptr,128,MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);if(!bridges[i]){good=false;break;}
        uint32_t at=(uint32_t)bridges[i],resume=base+s.rva+s.length;
        auto code=i==0?wide::buildArrayOwnerBridge(at,(uint32_t)&resolveCoreArrayOwner,resume):i==1?wide::buildArrayRefBridge(at,wideArrayBoundary?(uint32_t)&resolveCoreArrayReferenceContext:(uint32_t)&resolveCoreArrayReference,base+0x14BCB0,resume,wideArrayBoundary):wide::buildArrayFormBridge(at,(uint32_t)&resolveCoreArrayForm,resume);
        if(code.size()>128){good=false;break;}memcpy(bridges[i],code.data(),code.size());FlushInstructionCache(GetCurrentProcess(),bridges[i],code.size());
        std::vector<unsigned char> patch(s.length,0x90);patch[0]=0xE9;uint32_t delta=at-(base+s.rva+5);memcpy(patch.data()+1,&delta,4);
        good=coreArrayPatches[i].replace(base+s.rva,expected[i].data(),patch.data(),s.length);
    }
    if(!good){for(auto& patch:coreArrayPatches)patch.restore();for(auto bridge:bridges)if(bridge)VirtualFree(bridge,0,MEM_RELEASE);return false;}
    return true;
}
static uint32_t __cdecl resolveCoreStringOwner(uint32_t owner){
    if(coreStringPreloadActive && wideStringLoad){
        auto& restore=stringRestoreState();
        if(!restore.checked){
            restore.checked=true;const char* path=saveSerialization->savePath();
            try{
                std::unique_ptr<FILE,decltype(&fclose)> file(path?fopen(path,"rb"):nullptr,&fclose);
                if(file){
                    std::vector<unsigned char> bytes;unsigned char buffer[8192];bool good=true;
                    for(;;){size_t n=fread(buffer,1,sizeof(buffer),file.get());if(!n){if(ferror(file.get()))good=false;break;}if(n>wide::maxIdentityBytes-bytes.size()){good=false;break;}bytes.insert(bytes.end(),buffer,buffer+n);}
                    std::vector<std::string> current;for(uint32_t i=0;i<loadedCount;++i)current.emplace_back((char*)loadedFiles[i]+0x20);
                    restore.valid=good && wide::buildStringRestoreCatalog(bytes.data(),bytes.size(),current,restore.catalog);
                }
            }catch(...){restore.valid=false;}
            fprintf(logFile,"WIDE_STRING_RESTORE_CATALOG valid=%u strings=%u manifest_crc=%08X owner_crc=%08X path=%s\n",restore.valid,(uint32_t)restore.catalog.entries.size(),restore.catalog.manifestCrc,restore.catalog.ownerCrc,path?path:"unavailable");fflush(logFile);
        }
        if(restore.valid){
            if(restore.next>=restore.catalog.entries.size() || restore.catalog.entries[restore.next].savedByte!=owner)stop("core string stream differs from validated owner catalog");
            auto entry=restore.catalog.entries[restore.next++];
            try{auto& state=stringOwnerState();StringOwnerLock guard(state.lock,true);state.tracker.created(entry.id,entry.slot,entry.currentByte);}catch(...){stop("core string owner tracking allocation failed");}
            if(entry.slot>=legacySlots){fprintf(logFile,"WIDE_STRING_OWNER_RESTORED id=%u slot=%u owner_byte=%u\n",entry.id,entry.slot,entry.currentByte);fflush(logFile);}
            return entry.currentByte;
        }
        // Older saves retain the existing exact-order gate. A malformed or
        // absent new record never supplies inferred per-string identities.
    }
    if(coreStringPreloadActive && (owner==253 || owner==254)){
        if(!coreStringGateChecked){
            coreStringGateChecked=true;uint32_t strings=0,crc=0;const char* path=saveSerialization->savePath();
            try{
                FILE* file=path?fopen(path,"rb"):nullptr;
                if(file){
                    std::vector<unsigned char> bytes;unsigned char buffer[8192];bool good=true;
                    for(;;){size_t n=fread(buffer,1,sizeof(buffer),file);if(!n){if(ferror(file))good=false;break;}if(n>wide::maxIdentityBytes-bytes.size()){good=false;break;}bytes.insert(bytes.end(),buffer,buffer+n);}fclose(file);
                    std::vector<std::string> current;for(uint32_t i=0;i<loadedCount;++i)current.emplace_back((char*)loadedFiles[i]+0x20);
                    coreStringGateAccepted=good && wide::validateFixedOrderStringSave(bytes.data(),bytes.size(),current,strings,crc);
                }
            }catch(...){coreStringGateAccepted=false;}
            fprintf(logFile,"WIDE_CORE_STRING_GATE accepted=%u opaque_strings=%u manifest_crc=%08X path=%s scope=identical_full_plugin_order\n",coreStringGateAccepted,strings,crc,path?path:"unavailable");fflush(logFile);
        }
        if(coreStringGateAccepted){++coreStringOwnersRestored;return owner;}
    }
    uint32_t mapped=0;return saveSerialization->resolveRef(owner<<24,&mapped)?mapped>>24:255;
}
static bool installFixedOrderStrings(){
    HMODULE nvse=GetModuleHandleA("nvse_1_4.dll");uint32_t base=(uint32_t)nvse;
    if(!wide::moduleMatchesSha256(nvse,"e82c5d348bac255a8ff4cf477df2e48149304b18f02b42b2a835c3cba71f3dfb") || (uint32_t)saveSerialization->resolveRef!=base+0xD1FE0 || (uint32_t)saveSerialization->savePath!=base+0xD2030)return false;
    unsigned char expected[]={0x3A,0x05,0,0,0,0,0x73,0xA8,0x8A,0x81,0,0,0,0,0x3C,0xFF,0x74,0x9E};
    *(uint32_t*)(expected+2)=base+0x147F41;*(uint32_t*)(expected+10)=base+0x147F48;
    uint32_t site=base+0xD4756;if(memcmp((void*)site,expected,sizeof(expected)))return false;
    // Owner is ECX. Keep normal native STVR insertion, specific saved IDs,
    // allocators, used IDs, cache and lock handling in the original reader.
    unsigned char code[27];
    void* bridge=VirtualAlloc(nullptr,sizeof(code),MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);if(!bridge)return false;
    wide::buildCoreStringOwnerBridge(code,(uint32_t)bridge,(uint32_t)&resolveCoreStringOwner,base+0xD4706,base+0xD4768);
    memcpy(bridge,code,sizeof(code));FlushInstructionCache(GetCurrentProcess(),bridge,sizeof(code));
    unsigned char patch[sizeof(expected)];memset(patch,0x90,sizeof(patch));patch[0]=0xE9;*(uint32_t*)(patch+1)=(uint32_t)bridge-site-5;
    return coreStringOwnerPatch.replace(site,expected,patch,sizeof(patch));
}
static RuntimePatch nativeSaveRefHook;
static RuntimePatch stewieSaveRefPatch;
static uint32_t nativeSaveRefMapped=0,nativeSaveRefMissing=0;
static void countNativeSaveRef(uint32_t saved,uint32_t current,bool intercepted){
    if(intercepted){
        if(current)++nativeSaveRefMapped;else ++nativeSaveRefMissing;
        if(!current || nativeSaveRefMapped<=4){fprintf(logFile,"WIDE_NATIVE_SAVE_REF saved=%08X current=%08X mapped=%u missing=%u\n",saved,current,nativeSaveRefMapped,nativeSaveRefMissing);fflush(logFile);}
    }
}
static uint32_t __fastcall remapNativeSaveRef(void* context,void*,uint32_t saved){
    auto& state=saveIdentityState();bool intercepted=false;
    uint32_t current=wide::remapNativeSavedRef(saved,state.valid,state.savedToCurrent,
        [&](uint32_t id){return ((uint32_t(__thiscall*)(void*,uint32_t))nativeSaveRefHook.trampoline)(context,id);},intercepted);
    countNativeSaveRef(saved,current,intercepted);
    return current;
}
static uint32_t __fastcall remapStewieSaveRef(void* context,uint32_t saved){
    auto& state=saveIdentityState();bool intercepted=false;
    uint32_t current=wide::remapNativeSavedRef(saved,state.valid,state.savedToCurrent,
        [&](uint32_t id){uint32_t owner=id>>24;if(owner==255)return id;
            uint32_t mapped=((unsigned char*)context)[0x44+owner];return mapped==255?0:((mapped<<24)|(id&0xFFFFFF));},intercepted);
    countNativeSaveRef(saved,current,intercepted);return current;
}
static bool installNativeSaveRefs(){
    if(!wide::moduleMatchesSha256(GetModuleHandleA(nullptr),"518c87f58a6c4d9826e9ef8fbb7f4213882fa70822675610d45aea2464502a57"))return false;
    const unsigned char expected[]={0x55,0x8B,0xEC,0x83,0xEC,0x08};
    HMODULE stewie=supportedStewie?GetModuleHandleA("nvse_stewie_tweaks.dll"):nullptr;
    const unsigned char inlineBytes[]={0x8B,0xC6,0xC1,0xF8,0x18,0x3C,0xFF,0x74,0x21,0x8B,0x54,0x24,0x14,0x0F,0xB6,0xC0,0x8A,0x44,0x10,0x44,0x3C,0xFF,0x75,0x04,0x33,0xF6,0xEB,0x1B,0x0F,0xB6,0xC0,0x81,0xE6,0xFF,0xFF,0xFF,0x00,0xC1,0xE0,0x18,0x0B,0xF0};
    uint32_t site=stewie?(uint32_t)stewie+0x311B4:0;
    if(stewie && (!wide::moduleHasImageRange(stewie,0x311B4+sizeof(inlineBytes)) || memcmp((void*)site,inlineBytes,sizeof(inlineBytes))))return false;
    // Preserve loop ordinal ECX, pass original context at old ESP+14 and ESI
    // saved ID, then resume before the original nonzero/map-insertion logic.
    unsigned char code[22];
    void* bridge=nullptr;
    if(stewie){
        bridge=VirtualAlloc(nullptr,sizeof(code),MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);if(!bridge)return false;
        wide::buildStewieSavedRefBridge(code,(uint32_t)bridge,(uint32_t)&remapStewieSaveRef,site+sizeof(inlineBytes));
        memcpy(bridge,code,sizeof(code));FlushInstructionCache(GetCurrentProcess(),bridge,sizeof(code));
    }
    if(!nativeSaveRefHook.hook(0x846D80,expected,sizeof(expected),(void*)&remapNativeSaveRef)){if(bridge)VirtualFree(bridge,0,MEM_RELEASE);return false;}
    if(stewie){
        unsigned char patch[sizeof(inlineBytes)];memset(patch,0x90,sizeof(patch));patch[0]=0xE9;*(uint32_t*)(patch+1)=(uint32_t)bridge-site-5;
        if(!stewieSaveRefPatch.replace(site,inlineBytes,patch,sizeof(patch))){stewieSaveRefPatch.restore();nativeSaveRefHook.restore();return false;}
        fprintf(logFile,"WIDE_STEWIE_SAVE_REFS_ACTIVE rva=000311B4 bytes=%u scope=inline_form_array_remap\n",(uint32_t)sizeof(inlineBytes));fflush(logFile);
    }
    return true;
}
static void __cdecl resetSaveIdentity(void*){saveIdentityState()=SaveIdentityState{};}
static bool writeStringSave(){
    if(!wideStringSave)return true;
    wide::NvseStringSnapshot reader;std::vector<wide::NvseStringState> values;
    if(!reader.bind(GetModuleHandleA("nvse_1_4.dll"),jipProbeStrings->get,(void*)jipProbeStrings->set,(void*)jipProbeStrings->create) || !reader.snapshot(values))return false;
    wide::StringSave saved;saved.plugins=loadedCount;uint32_t opaque=0,unknown=0;
    {
        auto& state=stringOwnerState();StringOwnerLock guard(state.lock,false);
        for(auto value:values){
            if(value.temporary || value.owner==255)continue;
            if(value.cache || value.length>=0x4000)return false;
            uint32_t slot=value.owner;
            if(value.owner==253 || value.owner==254){
                ++opaque;wide::TrackedStringOwner owner{};
                if(!state.tracker.get(value.id,value.owner,owner)){++unknown;continue;}slot=owner.slot;
            }
            if(slot>=loadedCount)return false;
            saved.owners.push_back({value.id,(uint16_t)slot,(uint16_t)value.length,value.crc});
        }
    }
    if(unknown){fprintf(logFile,"WIDE_STRING_SAVE_REJECTED reason=incomplete_owner_coverage known_opaque=%u unknown_opaque=%u core_strings=unchanged\n",opaque-unknown,unknown);fflush(logFile);return false;}
    std::sort(saved.owners.begin(),saved.owners.end(),[](auto a,auto b){return a.id<b.id;});
    std::vector<unsigned char> bytes;
    if(!wide::encodeStringSave(saved,bytes) || !saveSerialization->writeRecord(wide::stringSaveRecord,wide::stringSaveVersion,bytes.data(),(uint32_t)bytes.size()))return false;
    fprintf(logFile,"WIDE_STRING_SAVE_WRITTEN strings=%u opaque_owners=%u bytes=%u crc=%08X scope=full_owner_metadata_and_text_fingerprints reader_enabled=%u\n",(uint32_t)saved.owners.size(),opaque,(uint32_t)bytes.size(),wide::identityCrc(bytes.data(),bytes.size()-4),wideStringLoad);fflush(logFile);return true;
}
static bool writeArraySave(uint32_t manifestCrc){
    wide::NvseArraySnapshot reader;std::vector<wide::NvseArrayState> values;
    if(!reader.bind(GetModuleHandleA("nvse_1_4.dll"),(void*)jipProbeArrays->create,jipProbeArrays->size,jipProbeArrays->lookup) || !reader.snapshot(values,nullptr,true))return false;
    wide::ArrayIdentitySave saved;saved.plugins=loadedCount;saved.manifestCrc=manifestCrc;
    uint32_t opaqueOwners=0,opaqueRefs=0;auto& state=arrayOwnerState();
    {
        StringOwnerLock guard(state.lock,false);
        for(const auto& a:values){
            if(a.temporary || a.refs.empty())continue;
            wide::ArraySavedIdentity entry{};entry.id=a.id;entry.nativeOwner=a.owner;
            if(a.owner<legacySlots)entry.creator=a.owner;
            else if(a.owner==255)entry.creator=wide::arrayGeneratedContext;
            else {
                wide::TrackedArrayOwner owner{};
                if(!state.tracker.get(a.id,a.objectAddress,a.owner,owner)){fprintf(logFile,"WIDE_ARRAY_SAVE_REJECTED id=%u reason=unknown_opaque_creator\n",a.id);return false;}
                entry.creator=(uint16_t)owner.slot;++opaqueOwners;
            }
            uint32_t native[256]{},observed[256]{};for(auto byte:a.refs)++native[byte];
            for(uint32_t byte=0;byte<256;++byte)if(native[byte] && (byte<legacySlots || byte==255))entry.refs.push_back({byte==255?wide::arrayGeneratedContext:(uint16_t)byte,(uint8_t)byte,native[byte]});
            if(native[253] || native[254]){
                auto coverage=state.references.coverage(a.id,a.refs);
                if(!coverage.lifecycleComplete){fprintf(logFile,"WIDE_ARRAY_SAVE_REJECTED id=%u reason=opaque_reference_lifecycle_tainted\n",a.id);return false;}
                for(const auto& binding:state.references.bindings(a.id)){
                    const auto& ref=binding.second;if(ref.nativeByte!=253 && ref.nativeByte!=254)continue;
                    if(!ref.known){fprintf(logFile,"WIDE_ARRAY_SAVE_REJECTED id=%u reason=unknown_opaque_referrer\n",a.id);return false;}
                    ++observed[ref.nativeByte];
                    auto it=std::find_if(entry.refs.begin(),entry.refs.end(),[&](const auto& old){return old.slot==ref.slot && old.nativeByte==ref.nativeByte;});
                    if(it==entry.refs.end())entry.refs.push_back({(uint16_t)ref.slot,ref.nativeByte,1});else ++it->count;
                }
                for(const auto& ref:state.references.imported(a.id))if(ref.nativeByte==253 || ref.nativeByte==254){
                    observed[ref.nativeByte]+=ref.count;
                    auto it=std::find_if(entry.refs.begin(),entry.refs.end(),[&](const auto& old){return old.slot==ref.slot && old.nativeByte==ref.nativeByte;});
                    if(it==entry.refs.end())entry.refs.push_back({(uint16_t)ref.slot,ref.nativeByte,ref.count});else it->count+=ref.count;
                }
                if(observed[253]!=native[253] || observed[254]!=native[254]){fprintf(logFile,"WIDE_ARRAY_SAVE_REJECTED id=%u reason=opaque_reference_counts_mismatch\n",a.id);return false;}
                opaqueRefs+=native[253]+native[254];
            }
            wide::ArrayContent content;content.id=a.id;content.owner=a.owner;content.key=a.keyType;content.packed=a.packed;content.elements=a.contents;
            if(content.elements.size()!=a.elements)return false;
            std::vector<unsigned char> core;if(!wide::encodeArrayCorePayload(content,a.refs,core))return false;
            entry.coreRecordCrc=wide::identityCrc(core.data(),core.size());saved.arrays.push_back(std::move(entry));
        }
    }
    std::vector<unsigned char> bytes;
    if(!wide::encodeArrayIdentities(saved,bytes) || !saveSerialization->writeRecord(wide::arrayIdentityRecord,wide::arrayIdentityVersion,bytes.data(),(uint32_t)bytes.size()))return false;
    fprintf(logFile,"WIDE_ARRAY_SAVE_WRITTEN arrays=%u opaque_creators=%u opaque_refs=%u bytes=%u manifest_crc=%08X scope=metadata_only core_record_match=offline_validation_pending reader_enabled=%u\n",(uint32_t)saved.arrays.size(),opaqueOwners,opaqueRefs,(uint32_t)bytes.size(),manifestCrc,wideArrayLoad);fflush(logFile);return true;
}
static void __cdecl writeSaveIdentity(void*){
    try {
        if(!ready || !loadedCount)throw "loader_not_ready";
        wide::SaveIdentities identities;
        for(uint32_t i=0;i<loadedCount;++i)identities.plugins.emplace_back((char*)loadedFiles[i]+0x20);
        for(auto entry:registry.snapshot()){
            uint32_t slot=entry.key.plugin+legacySlots;
            if(slot>=loadedCount)throw "registry_owner_out_of_range";
            identities.forms.push_back({entry.handle,(uint16_t)slot,entry.key.local});
        }
        std::vector<unsigned char> payload;
        if(!wide::encodeIdentities(identities,payload) || !saveSerialization->writeRecord(wide::saveIdentityRecord,wide::saveIdentityVersion,payload.data(),(uint32_t)payload.size()))throw "identity_record_write_failed";
        uint32_t manifestCrc=wide::identityCrc(payload.data(),payload.size()-4);
        fprintf(logFile,"WIDE_SAVE_IDENTITY_WRITTEN plugins=%u forms=%u bytes=%u version=1\n",loadedCount,(uint32_t)identities.forms.size(),(uint32_t)payload.size());fflush(logFile);
        if(wideStringSave && !writeStringSave()){fputs("WIDE_STRING_SAVE_WRITE_FAILED full_owner_roundtrip=not_certified\n",logFile);fflush(logFile);}
        if(wideJipSave){
            wide::JipSave snapshot;
            if(!jipSaveRuntime().bind(GetModuleHandleA("jip_nvse.dll")) || !jipSaveRuntime().snapshot(loadedCount,snapshot) || !wide::encodeJipSave(snapshot,loadedCount,payload) || !saveSerialization->writeRecord(wide::jipSaveRecord,wide::jipSaveVersion,payload.data(),(uint32_t)payload.size()))throw "JIP_record_write_failed";
            fprintf(logFile,"WIDE_JIP_SAVE_WRITTEN aux_owners=%u ref_owners=%u bytes=%u version=1 scope=all_permanent_maps\n",(uint32_t)snapshot.aux.size(),(uint32_t)snapshot.refs.size(),(uint32_t)payload.size());fflush(logFile);
        }
        if(wideJipScriptLinks){
            wide::ScriptLinkSave snapshot;
            if(!jipScriptLinkRuntime().snapshot(loadedCount,snapshot) || !wide::encodeScriptLinkSave(snapshot,loadedCount,payload) || !saveSerialization->writeRecord(wide::jipScriptLinkRecord,wide::jipScriptLinkVersion,payload.data(),uint32_t(payload.size())))throw "JIP_script_link_record_write_failed";
            fprintf(logFile,"WIDE_JIP_SCRIPT_LINK_SAVE_WRITTEN variables=%u links=%u bytes=%u version=1\n",uint32_t(snapshot.variables.size()),uint32_t(snapshot.links.size()),uint32_t(payload.size()));fflush(logFile);
        }
        if(wideShowOffTimers){
            wide::TimerSave snapshot;
            if(!showOffTimerRuntime.snapshot(snapshot) || !wide::encodeTimerSave(snapshot,loadedCount,payload) || !saveSerialization->writeRecord(wide::timerSaveRecord,wide::timerSaveVersion,payload.data(),uint32_t(payload.size())))throw "timer_record_write_failed";
            fprintf(logFile,"WIDE_TIMER_SAVE_WRITTEN owners=%u bytes=%u version=1 scope=all_permanent_timers\n",uint32_t(snapshot.owners.size()),uint32_t(payload.size()));fflush(logFile);
        }
        if(wideArraySave && !writeArraySave(manifestCrc)){fputs("WIDE_ARRAY_SAVE_WRITE_FAILED full_owner_roundtrip=not_certified\n",logFile);fflush(logFile);}
    }catch(...){fputs("WIDE_SAVE_WRITE_FAILED compatibility=not_certified\n",logFile);fflush(logFile);}
}
static bool restoreJipSave(SaveIdentityState& state){
    if(!wideJipSave || !state.valid || !state.jipValid)return false;
    wide::JipSave mapped;
    auto ref=[&](uint32_t saved,uint32_t& output)->bool{
        if(saved<0x800){output=saved;return true;}
        uint32_t result=0,slot=saved>>24,local=saved&0xFFFFFF;
        bool ok=false;
        if(slot==255)ok=saveSerialization->resolveRef(saved,&result) && result;
        else if(slot>=253){auto it=state.savedToCurrent.find(saved);if(it!=state.savedToCurrent.end()){result=it->second;ok=true;}}
        else if(slot<state.slots.size() && state.slots[slot]!=UINT32_MAX){
            slot=state.slots[slot];if(slot<legacySlots){result=(slot<<24)|local;ok=true;}
            else{auto* entry=registry.find({slot-legacySlots,local});if(entry){result=entry->handle;ok=true;}}
        }
        if(!ok){fprintf(logFile,"WIDE_JIP_SAVE_MISSING_REFERENCE saved=%08X\n",saved);fflush(logFile);return false;}output=result;return true;
    };
    if(!wide::remapJipSave(state.jip,state.slots,loadedCount,ref,mapped)){
        fprintf(logFile,"WIDE_JIP_SAVE_REJECTED reason=used_owner_reference_or_collision missing_registry_keys=%u\n",state.missingForms);fflush(logFile);return false;
    }
    if(!jipSaveRuntime().bind(GetModuleHandleA("jip_nvse.dll")) || !jipSaveRuntime().replace(mapped,loadedCount)){fputs("WIDE_JIP_SAVE_REJECTED reason=native_staging\n",logFile);fflush(logFile);return false;}
    fprintf(logFile,"WIDE_JIP_SAVE_RESTORED aux_owners=%u ref_owners=%u scope=all_permanent_maps core_strings=not_migrated\n",(uint32_t)mapped.aux.size(),(uint32_t)mapped.refs.size());fflush(logFile);return true;
}
static bool restoreTimerSave(SaveIdentityState& state){
    if(!wideShowOffTimers || !state.valid || !state.timersValid)return false;
    wide::TimerSave mapped;
    auto ref=[&](uint32_t saved,uint32_t& output){
        if(saved<0x800){output=saved;return true;}uint32_t s=saved>>24,local=saved&0xFFFFFF;
        if(s==255)return saveSerialization->resolveRef(saved,&output) && output;
        if(s>=253){auto found=state.savedToCurrent.find(saved);if(found==state.savedToCurrent.end())return false;output=found->second;return true;}
        if(s>=state.slots.size() || state.slots[s]==UINT32_MAX)return false;s=state.slots[s];
        if(s<legacySlots){output=(s<<24)|local;return true;}auto* entry=registry.find({s-legacySlots,local});if(!entry)return false;output=entry->handle;return true;
    };
    bool ok=wide::remapTimerSave(state.timers,state.slots,loadedCount,ref,mapped) && showOffTimerRuntime.replace(mapped);
    fprintf(logFile,"WIDE_TIMER_SAVE_RESTORE passed=%u owners=%u scope=permanent_timers\n",ok,uint32_t(mapped.owners.size()));fflush(logFile);return ok;
}
static bool restoreJipScriptLinks(SaveIdentityState& state){
    if(!wideJipScriptLinks || !state.valid || !state.scriptLinksValid)return false;
    auto ref=[&](uint32_t saved,uint32_t& output){
        if(saved<0x800){output=saved;return true;}uint32_t slot=saved>>24,local=saved&0xffffff;
        if(slot==255)return saveSerialization->resolveRef(saved,&output) && output;
        if(slot>=253){auto found=state.savedToCurrent.find(saved);if(found==state.savedToCurrent.end())return false;output=found->second;return true;}
        if(slot>=state.slots.size() || state.slots[slot]==UINT32_MAX)return false;slot=state.slots[slot];
        if(slot<legacySlots){output=(slot<<24)|local;return true;}auto* entry=registry.find({slot-legacySlots,local});if(!entry)return false;output=entry->handle;return true;
    };
    wide::ScriptLinkSave mapped;bool ok=wide::remapScriptLinkSave(state.scriptLinks,state.slots,loadedCount,ref,mapped) && jipScriptLinkRuntime().restore(mapped,loadedCount);
    fprintf(logFile,"WIDE_JIP_SCRIPT_LINK_SAVE_RESTORE passed=%u variables=%u links=%u allocation_failure_rollback=unsupported\n",ok,uint32_t(mapped.variables.size()),uint32_t(mapped.links.size()));fflush(logFile);return ok;
}
static bool restoreArrayIdentities(const char* phase){
    if(!wideArrayLoad || arrayIdentityRestored)return true;
    auto reject=[&](const char* why,uint32_t id=0){fprintf(logFile,"WIDE_ARRAY_RESTORE_REJECTED phase=%s id=%u reason=%s engine_arrays=unchanged\n",phase,id,why);fflush(logFile);return false;};
    try{
        const char* path=saveSerialization->savePath();std::unique_ptr<FILE,decltype(&fclose)> file(path?fopen(path,"rb"):nullptr,&fclose);
        if(!file)return reject("save_path_unavailable");
        std::vector<unsigned char> bytes;unsigned char buffer[8192];
        for(;;){size_t n=fread(buffer,1,sizeof(buffer),file.get());if(!n){if(ferror(file.get()))return reject("save_read_failed");break;}if(n>wide::maxIdentityBytes-bytes.size())return reject("save_size_limit");bytes.insert(bytes.end(),buffer,buffer+n);}
        std::vector<std::string> current;for(uint32_t i=0;i<loadedCount;++i)current.emplace_back((char*)loadedFiles[i]+0x20);
        wide::ArrayRestoreCatalog catalog;if(!wide::buildArrayRestoreCatalog(bytes.data(),bytes.size(),current,catalog,wideArrayReorder,wideArrayBoundary))return reject("metadata_absent_invalid_or_unsupported_order");
        std::unordered_set<uint32_t> wanted;for(const auto& a:catalog.owners.arrays)if(a.creator!=wide::arrayGeneratedContext)wanted.insert(a.id);
        wide::NvseArraySnapshot reader;std::vector<wide::NvseArrayState> live;
        if(!reader.bind(GetModuleHandleA("nvse_1_4.dll"),(void*)jipProbeArrays->create,jipProbeArrays->size,jipProbeArrays->lookup) || !reader.snapshot(live,&wanted))return reject("native_snapshot_unavailable");
        std::unordered_map<uint32_t,const wide::NvseArrayState*> byId;for(const auto& a:live)byId.emplace(a.id,&a);
        auto remap=[](uint32_t saved,uint32_t& mapped){return remapCoreArrayValue(saved,mapped);};
        auto& state=arrayOwnerState();StringOwnerLock guard(state.lock,true);
        auto creators=state.tracker;auto references=state.references;uint32_t restored=0,refsRestored=0,opaque=0,elements=0;
        for(const auto& saved:catalog.owners.arrays){
            // Native loading discards FF references and may discard or
            // reassign generated-owned arrays. Preserve that legacy policy.
            if(saved.creator==wide::arrayGeneratedContext)continue;
            auto found=byId.find(saved.id);if(found==byId.end())return reject("saved_plugin_array_missing",saved.id);
            const auto& a=*found->second;if(a.owner!=saved.nativeOwner)return reject("native_owner_mismatch",saved.id);
            wide::ArrayContent actual;actual.id=a.id;actual.owner=a.owner;actual.key=a.keyType;actual.packed=a.packed;actual.elements=a.contents;
            auto comparison=wide::compareArrayContents(catalog.contents.at(a.id),actual,remap);
            if(!comparison.passed)return reject(comparison.reason,saved.id);
            uint32_t expected[256]{},native[256]{};std::vector<wide::ImportedArrayReference> imported;
            for(const auto& ref:saved.refs)if(ref.slot!=wide::arrayGeneratedContext){expected[ref.nativeByte]+=ref.count;imported.push_back({ref.slot,ref.nativeByte,ref.count});}
            for(auto byte:a.refs)++native[byte];
            for(uint32_t byte=0;byte<256;++byte)if(expected[byte]!=native[byte])return reject("native_reference_count_mismatch",saved.id);
            if(!creators.created(a.id,a.objectAddress,saved.creator,a.owner) || !references.importReferences(a.id,imported))return reject("existing_tracking_conflict",saved.id);
            ++restored;refsRestored+=(uint32_t)a.refs.size();elements+=comparison.checked;if(saved.creator>=legacySlots)++opaque;
        }
        state.tracker=std::move(creators);state.references=std::move(references);arrayIdentityRestored=true;
        fprintf(logFile,"WIDE_ARRAY_OWNER_REMAP enabled=%u moved_creators=%u moved_ref_occurrences=%u scope=%s\n",wideArrayReorder,catalog.movedCreators,catalog.movedRefs,wideArrayBoundary?"full_identity_native_byte_migration":"opaque_permutation_legacy_slots_fixed native_bytes=unchanged");
        fprintf(logFile,"WIDE_ARRAY_RESTORE_COMPLETE phase=%s arrays=%u refs=%u opaque_creators=%u elements=%u generated_rows_skipped=%u manifest_crc=%08X scope=validated_plugin_owned_arrays native_counts=unchanged holder_addresses=not_deserialized\n",phase,restored,refsRestored,opaque,elements,catalog.generatedRows,catalog.owners.manifestCrc);fflush(logFile);return true;
    }catch(...){return reject("exception");}
}
static void readSaveIdentity(const char* phase){
    resetSaveIdentity(nullptr);auto& state=saveIdentityState();
    try {
        const char* source=saveSerialization->savePath?saveSerialization->savePath():nullptr;
        fprintf(logFile,"WIDE_SAVE_SOURCE phase=%s path=%s\n",phase,source?source:"unavailable");fflush(logFile);
        uint32_t type=0,version=0,length=0;bool rejected=false;
        std::vector<unsigned char> jipBytes,timerBytes,scriptLinkBytes;bool jipRejected=false,timersRejected=false,scriptLinksRejected=false;
        while(saveSerialization->nextRecord(&type,&version,&length)){
            if(type==wide::jipScriptLinkRecord){
                if(state.scriptLinksPresent){scriptLinksRejected=true;continue;}state.scriptLinksPresent=true;
                if(version!=wide::jipScriptLinkVersion || length>wide::maxIdentityBytes || length<20){scriptLinksRejected=true;continue;}
                scriptLinkBytes.resize(length);if(saveSerialization->readData(scriptLinkBytes.data(),length)!=length)scriptLinksRejected=true;continue;
            }
            if(type==wide::timerSaveRecord){
                if(state.timersPresent){timersRejected=true;continue;}state.timersPresent=true;
                if(version!=wide::timerSaveVersion || length>wide::maxIdentityBytes || length<16){timersRejected=true;continue;}
                timerBytes.resize(length);if(saveSerialization->readData(timerBytes.data(),length)!=length)timersRejected=true;continue;
            }
            if(type==wide::jipSaveRecord){
                if(state.jipPresent){jipRejected=true;continue;}state.jipPresent=true;
                if(version!=wide::jipSaveVersion || length>wide::maxIdentityBytes || length<20){jipRejected=true;continue;}
                jipBytes.resize(length);if(saveSerialization->readData(jipBytes.data(),length)!=length)jipRejected=true;
                if(!jipRejected){fprintf(logFile,"WIDE_SAVE_RECORD_SOURCE phase=%s type=WJIP version=%u bytes=%u crc=%08X\n",phase,version,length,wide::identityCrc(jipBytes.data(),length-4));fflush(logFile);}continue;
            }
            if(type!=wide::saveIdentityRecord)continue;
            if(state.present){rejected=true;continue;}
            state.present=true;
            if(version!=wide::saveIdentityVersion || length>wide::maxIdentityBytes || length<16){rejected=true;continue;}
            std::vector<unsigned char> bytes(length);
            if(saveSerialization->readData(bytes.data(),length)!=length || !wide::decodeIdentities(bytes.data(),bytes.size(),state.identities)){rejected=true;continue;}
            fprintf(logFile,"WIDE_SAVE_RECORD_SOURCE phase=%s type=WIDM version=%u bytes=%u crc=%08X\n",phase,version,length,wide::identityCrc(bytes.data(),length-4));fflush(logFile);
            state.valid=true;
        }
        if(rejected)state.valid=false;
        if(!state.valid){fprintf(logFile,"WIDE_SAVE_IDENTITY_READ phase=%s present=%u valid=0 legacy_records=unchanged\n",phase,state.present);fflush(logFile);return;}
        std::vector<std::string> current;
        for(uint32_t i=0;i<loadedCount;++i)current.emplace_back((char*)loadedFiles[i]+0x20);
        auto& slots=state.slots;
        if(!wide::identitySlotMap(state.identities.plugins,current,slots,state.missingPlugins))throw "ambiguous_current_names";
        for(auto form:state.identities.forms){
            uint32_t slot=slots[form.slot],handle=0;
            if(slot==UINT32_MAX){++state.missingForms;continue;}
            if(slot<legacySlots)handle=(slot<<24)|form.local;
            else {auto* entry=registry.find({slot-legacySlots,form.local});if(entry)handle=entry->handle;}
            if(!handle){++state.missingForms;continue;}
            state.savedToCurrent.emplace(form.handle,handle);
        }
        fprintf(logFile,"WIDE_SAVE_IDENTITY_READ phase=%s present=1 valid=1 plugins=%u forms=%u mapped=%u missing_plugins=%u missing_forms=%u native_and_private_values=not_restored\n",phase,(uint32_t)slots.size(),(uint32_t)state.identities.forms.size(),(uint32_t)state.savedToCurrent.size(),state.missingPlugins,state.missingForms);fflush(logFile);
        state.jipValid=state.jipPresent && !jipRejected && wide::decodeJipSave(jipBytes.data(),jipBytes.size(),(uint32_t)state.identities.plugins.size(),state.jip);
        state.timersValid=state.timersPresent && !timersRejected && wide::decodeTimerSave(timerBytes.data(),timerBytes.size(),uint32_t(state.identities.plugins.size()),state.timers);
        state.scriptLinksValid=state.scriptLinksPresent && !scriptLinksRejected && wide::decodeScriptLinkSave(scriptLinkBytes.data(),scriptLinkBytes.size(),uint32_t(state.identities.plugins.size()),state.scriptLinks);
        if(!strcmp(phase,"load") && state.scriptLinksValid)state.scriptLinksRestored=restoreJipScriptLinks(state);
        fprintf(logFile,"WIDE_JIP_SCRIPT_LINK_SAVE_READ phase=%s present=%u valid=%u restored=%u enabled=%u\n",phase,state.scriptLinksPresent,state.scriptLinksValid,state.scriptLinksRestored,wideJipScriptLinks);fflush(logFile);
        if(!strcmp(phase,"load") && state.timersValid)state.timersRestored=restoreTimerSave(state);
        fprintf(logFile,"WIDE_TIMER_SAVE_READ phase=%s present=%u valid=%u restored=%u enabled=%u\n",phase,state.timersPresent,state.timersValid,state.timersRestored,wideShowOffTimers);fflush(logFile);
        if(!strcmp(phase,"load") && state.jipValid)state.jipRestored=restoreJipSave(state);
        fprintf(logFile,"WIDE_JIP_SAVE_READ phase=%s present=%u valid=%u restored=%u enabled=%u\n",phase,state.jipPresent,state.jipValid,state.jipRestored,wideJipSave);fflush(logFile);
        if(wideArrayLoad)restoreArrayIdentities(phase);
        traceWideStringState(phase);
        traceCoreArrayState(phase);
    }catch(...){state.valid=false;state.savedToCurrent.clear();fprintf(logFile,"WIDE_SAVE_IDENTITY_READ_FAILED phase=%s\n",phase);fflush(logFile);}
}
static void __cdecl preloadSaveIdentity(void*){
    coreStringPreloadActive=false;
    if(wideArrayBoundary){auto& state=coreArrayLoadState();fprintf(logFile,"WIDE_ARRAY_STREAM_COMPLETE valid=%u consumed=%u expected=%u complete=%u refs=%u\n",state.valid,(uint32_t)state.stream.consumed(),(uint32_t)state.stream.entries.size(),state.stream.complete(),state.refs);fflush(logFile);if(!state.valid || !state.stream.complete())stop("array identity stream did not complete");}
    if(fixedOrderWideArrays){auto& state=coreArrayLoadState();fprintf(logFile,"WIDE_ARRAY_LOAD_SUMMARY valid=%u opaque_owners=%u opaque_refs=%u extended_forms_mapped=%u extended_forms_missing=%u\n",state.valid,state.owners,state.refs,state.formsMapped,state.formsMissing);fflush(logFile);}
    if(wideStringLoad){auto& state=stringRestoreState();bool complete=state.valid && state.next==state.catalog.entries.size();fprintf(logFile,"WIDE_STRING_RESTORE_SUMMARY valid=%u consumed=%u expected=%u complete=%u\n",state.valid,(uint32_t)state.next,(uint32_t)state.catalog.entries.size(),complete);fflush(logFile);if(state.valid && !complete)stop("native string reader did not consume validated owner catalog");}
    if(fixedOrderWideStrings){fprintf(logFile,"WIDE_CORE_STRING_LOAD_SUMMARY accepted=%u restored_owners=%u\n",coreStringGateAccepted,coreStringOwnersRestored);fflush(logFile);}
    nativeSaveRefMapped=nativeSaveRefMissing=0;readSaveIdentity("preload");
}
static void __cdecl loadSaveIdentity(void*){
    fprintf(logFile,"WIDE_NATIVE_SAVE_REF_SUMMARY enabled=%u mapped=%u missing=%u\n",wideNativeSaveRefs,nativeSaveRefMapped,nativeSaveRefMissing);fflush(logFile);
    readSaveIdentity("load");
}
static bool __cdecl checkSaveIdentity(WIDE_COMMAND_ARGS){
    auto& state=saveIdentityState();bool ok=ready && state.present && state.valid && !state.missingPlugins && !state.missingForms;
    fprintf(logFile,"WIDE_SAVE_IDENTITY_CHECK passed=%u present=%u valid=%u saved_plugins=%u current_plugins=%u forms=%u mapped=%u missing_plugins=%u missing_forms=%u scope=identity_metadata_only\n",ok,state.present,state.valid,(uint32_t)state.identities.plugins.size(),loadedCount,(uint32_t)state.identities.forms.size(),(uint32_t)state.savedToCurrent.size(),state.missingPlugins,state.missingForms);fflush(logFile);*result=ok?1:0;return true;
}
static WideCommandInfo wideIdentityCheck={"WideCheckSaveIdentity","",0,"Check full saved plugin/FormID identities; values not migrated yet",0,0,nullptr,checkSaveIdentity,nullptr,nullptr,0};
static bool __fastcall getWideModINIPath(void* output,void* script) {
    // Match ShowOff's GetOverridingModIdx: the last TESFile in the form's
    // modification list, rather than the canonical first owner of the FormID.
    auto* node=(MasterNode*)((char*)script+0x10);
    while(node->next)node=node->next;
    MasterBinding file;
    if(!ready || !node->data || !binding(node->data,file) || !file.wide)
        return ((bool(__fastcall*)(void*,void*))showOffIniHook.trampoline)(output,script);
    const char* name=(char*)node->data+0x20;
    std::string path=name;
    if(path.size()<3)return false;
    path.replace(path.size()-3,3,"ini");
    // Preserve the installed DLL's MSVC string allocator and layout. Never
    // pass this DLL's libc++ std::string across the plugin ABI.
    ((void*(__thiscall*)(void*,const char*,uint32_t))((uint32_t)showOffModule+0x1CF0))(output,path.c_str(),(uint32_t)path.size());
    fprintf(logFile,"WIDE_SHOWOFF_INI file=%s path=%s\n",name,path.c_str());fflush(logFile);
    return true;
}
static bool installShowOffINI() {
    showOffModule=GetModuleHandleA("ShowOffNVSE.dll");if(!showOffModule)return false;
    // Updated installed build 37CB22C5...EE7EF3E, disassembled and compared
    // with IniToNVSE::GetModINIPath in SO_fn_Files.cpp.
    const unsigned char entry[]={0x8B,0x42,0x14,0x83,0xC2,0x10};
    const unsigned char assign[]={0x55,0x8B,0xEC,0x51,0x53,0x56,0x8B,0xF1};
    if(!wide::moduleHasImageRange(showOffModule,0x1CDD0+sizeof(entry)) ||
       memcmp((void*)((uint32_t)showOffModule+0x1CF0),assign,sizeof(assign)))return false;
    return showOffIniHook.hook((uint32_t)showOffModule+0x1CDD0,entry,sizeof(entry),(void*)&getWideModINIPath);
}
static bool identity(void* pointer,WideFileIdentity& out) {
    MasterBinding self;if(!binding(pointer,self) || !self.wide)return false;
    auto* file=(unsigned char*)pointer;out.owner=self.owner;out.masterCount=*(uint32_t*)(file+0x3FC);
    if(out.masterCount>255)stop("file has more than 255 disk masters");
    auto** masters=*(void***)(file+0x400);
    if(out.masterCount && !masters)stop("wide file master table missing");
    for(uint32_t i=0;i<out.masterCount;i++)if(!binding(masters[i],out.masters[i])) {
        fprintf(logFile,"UNBOUND_MASTER file=%s pointer=%p record=%08X master_slot=%u master_pointer=%p master_name=%s\n",
            file+0x20,pointer,*(uint32_t*)(file+0x24C),i,masters[i],masters[i]?(char*)masters[i]+0x20:"<null>");fflush(logFile);
        stop("master is absent from active wide order");
    }
    return true;
}
static uint32_t translate(void* file,uint32_t raw) {
    const uint32_t suppliedRaw=raw;
    WideFileIdentity f;if(!identity(file,f))stop("wide file identity unavailable");
    // The native GetNthMaster path falls back to the current file when the
    // selector is absent. Official DeadMoney.esm contains such an RDWT entry
    // (03001AE7 in REGN 01013DA2). Match that established engine behavior.
    if((raw>>24)>f.masterCount)raw=(f.masterCount<<24)|(raw&0xFFFFFF);
    uint32_t id=0;if(!resolveDiskForm(registry,f,raw,occupied,id)) {
        fprintf(logFile,"BAD_DISK_ID file=%s raw=%08X masters=%u owner=%u\n",(char*)file+0x20,raw,f.masterCount,f.owner);fflush(logFile);
        stop("invalid disk selector or opaque handle exhaustion");
    }
    // Optional diagnostic for the one identity still absent in the real-mod
    // control. Observe its creation without changing translation or lookup.
    if(traceUnresolvedOrigin && (raw&0xFFFFFF)==0x01B0D0) {
        auto* e=registry.reverse(id);
        if(e && e->key.plugin+legacySlots<loadedCount &&
           !_stricmp((char*)loadedFiles[e->key.plugin+legacySlots]+0x20,"Eliza.esp")) {
            static volatile LONG reports=0;
            if(InterlockedIncrement(&reports)<=64) {
                fprintf(logFile,"UNRESOLVED_ORIGIN file=%s supplied=%08X normalized=%08X handle=%08X record=%08X caller=%p\n",
                    (char*)file+0x20,suppliedRaw,raw,id,*(uint32_t*)((char*)file+0x24C),__builtin_return_address(0));
                void* frames[16]{};USHORT count=CaptureStackBackTrace(0,16,frames,nullptr);
                for(USHORT i=0;i<count;++i) {
                    HMODULE module=nullptr;char modulePath[MAX_PATH]{};
                    GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,(const char*)frames[i],&module);
                    if(module)GetModuleFileNameA(module,modulePath,MAX_PATH);
                    const char* name=strrchr(modulePath,'\\');
                    fprintf(logFile,"UNRESOLVED_ORIGIN_FRAME %u %p %s+%08X\n",i,frames[i],name?name+1:modulePath,(uint32_t)frames[i]-(uint32_t)module);
                }
                fflush(logFile);
            }
        }
    }
    return id;
}
static bool __fastcall loadOne(void* dh,void*,void* file,bool base) {
    wide::faults::stage("engine_loading_plugin_see_last_NATIVE_LOAD_BEGIN_in_loader_log");
    InterlockedExchange(&wide::faults::pluginCount,loadedCount);
    fprintf(logFile,"NATIVE_LOAD_BEGIN=%s\n",(char*)file+0x20);fflush(logFile);
    bool result=((bool(__thiscall*)(void*,void*,bool))perFileHook.trampoline)(dh,file,base);
    fprintf(logFile,"NATIVE_LOAD_END=%s result=%u wide_keys=%u\n",(char*)file+0x20,result,registry.count);fflush(logFile);return result;
}
static bool wideFile(void* f) {std::lock_guard<std::recursive_mutex> guard(ownerLock);auto it=owners.find(f);return it!=owners.end() && it->second>=legacySlots;}
static void __fastcall setIndex(void* f,void*,uint32_t index) {
    std::lock_guard<std::recursive_mutex> guard(ownerLock);
    if(cloningSource) {
        auto it=owners.find(cloningSource);if(it!=owners.end()){owners[f]=it->second;index=it->second<legacySlots?it->second:0xFD;}
    }else if(loading) {
        if(!loadedCount || loadedCount>maxFiles || loadedFiles[loadedCount-1]!=f)stop("normal loader insertion sequence/capacity");
        uint32_t slot=loadedCount-1;owners[f]=slot;
        auto* dh=*(unsigned char**)0x11C3F2C;
        if(slot<legacySlots)*(void**)(dh+0x21C+slot*4)=f;
        *(uint32_t*)(dh+0x218)=loadedCount<legacySlots?loadedCount:legacySlots;
        index=slot<legacySlots?slot:0xFD;
        fprintf(logFile,"FILE=%u:%s\n",slot,(const char*)f+0x20);fflush(logFile);
    }
    ((void(__thiscall*)(void*,uint32_t))indexSetter.trampoline)(f,index);
}
static void* __fastcall cloneFile(void* source,void*,uint32_t thread) {
    void* previous=cloningSource;cloningSource=source;
    auto* result=((void*(__thiscall*)(void*,uint32_t))cloneHook.trampoline)(source,thread);
    cloningSource=previous;
    {std::lock_guard<std::recursive_mutex> guard(ownerLock);if(result)if(auto it=owners.find(source);it!=owners.end())owners[result]=it->second;}
    return result;
}
static bool __fastcall buildMasters(void* file,void*,void* suppliedList,bool warn) {
    // Threaded file clones rebuild masters after startup. Their ordinary
    // DataHandler list is the bounded ABI view; use the full active list here.
    void* list=ready && !masterLookupList.empty()?masterLookupList.data():suppliedList;
    return ((bool(__thiscall*)(void*,void*,bool))masterBuilderHook.trampoline)(file,list,warn);
}
static bool __fastcall readHeader(void* pointer,void*) {
    if(!wideFile(pointer))return ((bool(__thiscall*)(void*))header.trampoline)(pointer);
    auto* f=(unsigned char*)pointer;auto* stream=*(void**)(f+0x10);if(!stream)return false;
    if(((uint32_t(__thiscall*)(void*,void*,uint32_t))0xB00650)(stream,f+0x240,24)!=24){memset(f+0x240,0,24);return false;}
    if(f[0x299])((void(__thiscall*)(void*))0x470650)(f+0x240);
    uint32_t type=*(uint32_t*)(f+0x240);
    if(type!=0x50555247 && type!=0x34534554)*(uint32_t*)(f+0x24C)=translate(f,*(uint32_t*)(f+0x24C));
    return true;
}
static void __cdecl fixEmbedded(uint32_t* id,void* f) {
    // Native save loading has a distinct compact-ID translation state. Leave
    // that state to the original routine; this module only changes file input.
    uint32_t raw=*id;
    if(wideWeaponProjectileRefs && wideFile(f) &&
       (uint32_t)__builtin_return_address(0)==0x51E4EB &&
       !(*(void**)0x11DE45C && ((bool(__thiscall*)(void*))0x47C850)(*(void**)0x11DE45C))) {
        DWORD savedError=GetLastError();uint32_t candidate[4]{};SIZE_T got=0;
        if(ReadProcessMemory(GetCurrentProcess(),(void*)raw,candidate,sizeof(candidate),&got) && got==sizeof(candidate) &&
           candidate[0]==0x10251AC && (candidate[1]&255)==51 && lookup(candidate[3])==(void*)raw) {
            // TESObjectWEAP::InitItem can inherit an already linked projectile
            // through GetProjectile. Its next lookup requires that object's
            // registered runtime ID rather than a disk-ID reconstruction.
            *id=candidate[3];
            static volatile LONG reports=0;
            if(InterlockedIncrement(&reports)<=64) {
                fprintf(logFile,"WEAPON_PROJECTILE_REFERENCE_REUSED file=%s pointer=%08X id=%08X\n",(char*)f+0x20,raw,*id);
                fflush(logFile);
            }
            SetLastError(savedError);return;
        }
        SetLastError(savedError);
    }
    if(wideResponseRefs && dialogueDepth && wideFile(f) &&
       ((uint32_t)__builtin_return_address(0)==0x617A03 || (uint32_t)__builtin_return_address(0)==0x617C41)) {
        DWORD savedError=GetLastError();uint32_t candidate[4]{};SIZE_T got=0;
        if(ReadProcessMemory(GetCurrentProcess(),(void*)raw,candidate,sizeof(candidate),&got) && got==sizeof(candidate) &&
           candidate[0]==0x1049D0C && (candidate[1]&255)==72 && lookup(candidate[3])==(void*)raw) {
            // This slot already contains a registered idle pointer. The
            // initializer's next operation expects a runtime FormID for its
            // native lookup, not another disk-selector reconstruction.
            *id=candidate[3];static uint32_t reported=0;if(reported++<128){fprintf(logFile,"RESPONSE_WIDE_REFERENCE_REUSED source=%p pointer=%08X id=%08X\n",dialogueSource,raw,*id);fflush(logFile);}
            SetLastError(savedError);return;
        }
        SetLastError(savedError);
    }
    if(!wideFile(f) || (*(void**)0x11DE45C && ((bool(__thiscall*)(void*))0x47C850)(*(void**)0x11DE45C))) {
        ((void(__cdecl*)(uint32_t*,void*))embedded.trampoline)(id,f);
    }else {
        *id=translate(f,*id);
        if(traceUnresolvedOrigin && (raw&0xFFFFFF)==0x01B0D0) {
            auto* e=registry.reverse(*id);
            if(e && e->key.plugin+legacySlots<loadedCount &&
               !_stricmp((char*)loadedFiles[e->key.plugin+legacySlots]+0x20,"Eliza.esp")) {
                void* caller=__builtin_return_address(0);
                fprintf(logFile,"UNRESOLVED_EMBEDDED_CALLER address=%p raw=%08X\n",caller,raw);
                for(size_t i=0;i<codeBridges.size();++i)
                    if((uint32_t)caller>=(uint32_t)codeBridges[i] && (uint32_t)caller<(uint32_t)codeBridges[i]+64)
                        fprintf(logFile,"UNRESOLVED_BRIDGE index=%u base=%p offset=%u\n",(unsigned)i,codeBridges[i],(uint32_t)caller-(uint32_t)codeBridges[i]);
                fflush(logFile);
            }
        }
    }
    if(traceDialogue && dialogueDepth) {
        DWORD savedError=GetLastError();void* resolved=lookup(*id);
        uint32_t candidate[4]{};SIZE_T got=0;bool livePointer=false;
        if(ReadProcessMemory(GetCurrentProcess(),(void*)raw,candidate,sizeof(candidate),&got) && got==sizeof(candidate))livePointer=lookup(candidate[3])==(void*)raw;
        fprintf(logFile,"DIALOGUE_REFERENCE source=%p file=%s raw=%08X runtime=%08X resolved=%p type=%u\n",dialogueSource,f?(char*)f+0x20:"<null>",raw,*id,resolved,resolved?*((unsigned char*)resolved+4):0);
        if(livePointer)fprintf(logFile,"RESPONSE_LIVE_POINTER_AS_ID pointer=%08X vtable=%08X type=%u actual_id=%08X\n",raw,candidate[0],candidate[1]&255,candidate[3]);
        else if(got==sizeof(candidate))fprintf(logFile,"RESPONSE_POINTER_CANDIDATE pointer=%08X vtable=%08X type=%u actual_id=%08X\n",raw,candidate[0],candidate[1]&255,candidate[3]);
        fflush(logFile);SetLastError(savedError);
    }
}
static uint32_t __fastcall getLocal(void* f,void*) {
    auto* e=registry.reverse(*(uint32_t*)((unsigned char*)f+0xC));
    return e?e->key.local:((uint32_t(__thiscall*)(void*))localGetter.trampoline)(f);
}
static bool __fastcall compareLocal(void* f,void*,uint32_t id) {
    auto* e=registry.reverse(id);return getLocal(f,nullptr)==(e?e->key.local:id&0xFFFFFF);
}
// Optional explicit order supports MO2's virtual Data directory. No copying of
// real plugins or alteration of plugins.txt is needed. Construct all missing
// TESFiles first, so the original native master-resolution pass sees them.
static void selectOrder(unsigned char* dh) {
    if(orderFile.empty())return;
    FILE* in=fopen(orderFile.c_str(),"rb");if(!in)stop("explicit order file unreadable");
    std::vector<std::string> names;char line[1024];
    while(fgets(line,sizeof(line),in)) {
        if(!strchr(line,'\n') && !feof(in))stop("order line exceeds limit");
        auto n=strcspn(line,"\r\n");line[n]=0;char* s=line;
        if(names.empty() && (unsigned char)s[0]==0xEF && (unsigned char)s[1]==0xBB && (unsigned char)s[2]==0xBF)s+=3;
        while(*s==' ' || *s=='\t')++s;if(!*s || *s=='#')continue;if(*s=='*')++s;
        if(!*s || strlen(s)>=260 || strpbrk(s,"\\/:"))stop("invalid plugin filename in explicit order");
        for(auto& name:names)if(!lstrcmpiA(name.c_str(),s))stop("duplicate plugin filename");
        names.emplace_back(s);if(names.size()>maxFiles)stop("explicit order exceeds 1024 plugins");
    }
    fclose(in);if(names.empty())stop("explicit order empty");
    struct Node {unsigned char* data;Node* next;};auto* head=(Node*)(dh+0x210);
    std::unordered_map<std::string,unsigned char*> discovered;
    std::vector<unsigned char*> inactive;
    auto lower=[](std::string s){for(char& c:s)if(c>='A' && c<='Z')c+=32;return s;};
    for(auto* node=head;node;node=node->next)if(node->data) {
        discovered.emplace(lower((const char*)node->data+0x20),node->data);inactive.push_back(node->data);
        ((void(__thiscall*)(void*,bool))0x471D00)(node->data,false);
    }
    using Alloc=void*(__cdecl*)(uint32_t);std::vector<unsigned char*> selected;
    for(auto& name:names) {
        unsigned char* f=nullptr;auto it=discovered.find(lower(name));
        if(it!=discovered.end())f=it->second;
        else {
            f=(unsigned char*)((Alloc)0x401000)(0x42C);if(!f)stop("TESFile allocation");
            std::string directory="Data\\";
            if(!additionalDirectory.empty() && GetFileAttributesA((directory+name).c_str())==INVALID_FILE_ATTRIBUTES)directory=additionalDirectory+"\\";
            ((void*(__thiscall*)(void*,const char*,const char*,uint32_t))0x470710)(f,directory.c_str(),name.c_str(),0);
            if(*(uint32_t*)f)stop("TESFile constructor could not open explicit plugin");
        }
        ((void(__thiscall*)(void*,bool))0x471D00)(f,true);selected.push_back(f);
    }
    // Reuse existing list nodes. Allocate only a deficit. Native list ownership
    // remains in the engine heap, including inactive discovered files.
    for(auto* f:inactive)if(std::find(selected.begin(),selected.end(),f)==selected.end())selected.push_back(f);
    Node* node=head;
    for(size_t i=0;i<selected.size();i++) {
        node->data=selected[i];if(i+1<selected.size()) {
            if(!node->next){node->next=(Node*)((Alloc)0x401000)(sizeof(Node));if(!node->next)stop("order node allocation");*node->next={};}
            node=node->next;
        }else if(node->next)stop("unexpected excess discovered list nodes");
    }
}
static void __fastcall loadFiles(void* handler,void*,bool reload) {
    if(loadedCount || registry.count)stop("repeated LoadFiles needs an identity/lifetime reset implementation");
    auto* dh=(unsigned char*)handler;selectOrder(dh);loading=true;
    ((void(__thiscall*)(void*,bool))orchestration.trampoline)(handler,reload);
    loading=false;
    for(uint32_t i=0;i<registry.count;i++)registry.entries[i].form=lookup(registry.entries[i].handle);
    masterLookupList.resize(loadedCount);
    for(uint32_t i=0;i<loadedCount;i++)masterLookupList[i]={loadedFiles[i],i+1<loadedCount?&masterLookupList[i+1]:nullptr};
    // Legacy extensions often compile their own 256-pointer active-file cache
    // by walking DH.modInfoList directly. Keep that ABI view bounded; all files
    // remain in loadedFiles and their native master/source pointers stay valid.
    // Keep the detached tail alive for the duration of this process.
    struct Node {void* data;Node* next;};auto* node=(Node*)(dh+0x210);uint32_t nodes=0;
    while(node){nodes++;if(nodes==legacySlots){node->next=nullptr;break;}node=node->next;}
    // Waiting for the first game loop lets menu scripts populate byte-owned
    // timer maps. Install after all forms/master lists exist and before return
    // to UI/script initialization; retain the installer's empty-map guard.
    if(wideShowOffTimers && timerInstallAfterPluginLoad && !timerRuntimeInstalled){
        wide::faults::stage("installing_ShowOff_timers_after_plugin_load");
        if(!showOffTimerRuntime.install(GetModuleHandleA("ShowOffNVSE.dll"),supScriptOwner,loadedCount,logFile))stop("post-plugin-load ShowOff timer adapter preflight mismatch");
        timerRuntimeInstalled=true;
        fputs("WIDE_SHOWOFF_TIMERS_ACTIVE phase=after_plugin_load_before_menu_scripts bridges=13 width_sites=15 full_owner_save=WTMR legacy_save=legacy_public_subset\n",logFile);fflush(logFile);
    }
    wide::faults::stage("plugins_loaded_before_first_game_loop");
    ready=true;fprintf(logFile,"NORMAL_LOAD_COMPLETE files=%u legacy=%u wide_forms=%u\n",loadedCount,*(uint32_t*)(dh+0x218),registry.count);fflush(logFile);
}
static bool __cdecl commandCount(WIDE_COMMAND_ARGS) {
    if(!ready)return commandChanges[0].original(WIDE_PASS_ARGS);*result=loadedCount;return true;
}
static int findSlot(const char* name) {
    for(uint32_t i=0;i<loadedCount;i++)if(!lstrcmpiA(name,(char*)loadedFiles[i]+0x20))return (int)i;return -1;
}
static bool __cdecl commandIndex(WIDE_COMMAND_ARGS) {
    if(!ready)return commandChanges[1].original(WIDE_PASS_ARGS);char name[512]{};*result=255;
    if(scripts->extract(params,scriptData,offset,scriptObj,eventList,name)){int slot=findSlot(name);if(slot>=0)*result=slot<(int)legacySlots?slot:256+slot-legacySlots;}
    return true;
}
static bool __cdecl commandLoaded(WIDE_COMMAND_ARGS) {
    if(!ready)return commandChanges[2].original(WIDE_PASS_ARGS);char name[512]{};*result=0;
    if(scripts->extract(params,scriptData,offset,scriptObj,eventList,name))*result=findSlot(name)>=0;return true;
}
static bool __cdecl commandSource(WIDE_COMMAND_ARGS) {
    if(!ready)return commandChanges[3].original(WIDE_PASS_ARGS);void* form=nullptr;*result=-1;
    if(!scripts->extract(params,scriptData,offset,scriptObj,eventList,&form))return true;if(!form)form=thisObj;
    if(form){uint32_t id=*(uint32_t*)((char*)form+0xC);auto* e=registry.reverse(id);*result=e?e->key.plugin+256:id>>24;}return true;
}
static bool __cdecl commandLocal(WIDE_COMMAND_ARGS) {
    if(!ready)return commandChanges[4].original(WIDE_PASS_ARGS);void* form=nullptr;*result=-1;
    if(!scripts->extract(params,scriptData,offset,scriptObj,eventList,&form))return true;if(!form)form=thisObj;
    if(form)*result=getLocal(form,nullptr);return true;
}
static bool __cdecl commandBuild(WIDE_COMMAND_ARGS) {
    if(!ready)return commandChanges[5].original(WIDE_PASS_ARGS);*result=0;uint32_t slot=0,local=0;
    if(!scripts->extract(params,scriptData,offset,scriptObj,eventList,&slot,&local))return true;local&=0xFFFFFF;
    uint32_t id=0;if(slot<legacySlots || slot==255)id=slot<<24|local;
    else if(slot>=256 && loadedCount>legacySlots && slot-256<loadedCount-legacySlots && local>=0x800){auto* e=registry.intern({slot-256,local},occupied);if(e)id=e->handle;}
    // Preserve the reference-return ABI: a DWORD in the double result storage.
    memcpy(result,&id,sizeof(id));return true;
}
static uint32_t jipHexLocal(const char* text) {
    // Match JIP's reverse HexToUInt scan, including partial suffix parsing
    // and x86 shift-count wrapping, before its 24-bit local-ID mask.
    uint32_t value=0,shift=0;
    for(size_t n=strlen(text);n;n--) {
        unsigned char c=(unsigned char)text[n-1];uint32_t digit;
        if(c>='0' && c<='9')digit=c-'0';
        else {c|=0x20;if(c<'a' || c>'f')break;digit=c-'a'+10;}
        value+=digit<<(shift&31);shift+=4;
    }
    return value&0xFFFFFF;
}
static bool __cdecl commandJIPForm(WIDE_COMMAND_ARGS) {
    if(!ready)return jipFormChange.original(WIDE_PASS_ARGS);
    char name[512]{},localText[512]{};
    if(!scripts->extract(params,scriptData,offset,scriptObj,eventList,name,localText))return true;
    uint32_t local=jipHexLocal(localText),id=0;
    if(!lstrcmpiA(name,"NONE"))id=0xFF000000|local;
    else {
        int slot=findSlot(name);if(slot<0){fprintf(logFile,"JIP_FORM_LOOKUP file=%s local=%06X status=missing_plugin\n",name,local);fflush(logFile);return true;}
        if(slot<(int)legacySlots)id=(uint32_t)slot<<24|local;
        else {auto* entry=registry.find({(uint32_t)slot-legacySlots,local});if(entry)id=entry->handle;}
    }
    auto* form=id?lookup(id):nullptr;
    if(form)memcpy(result,&id,sizeof(id));
    static LONG reported=0;
    if(InterlockedIncrement(&reported)<=128 || (!lstrcmpiA(name,"Fallout3.esm") && local==0x14E86)) {
        fprintf(logFile,"JIP_FORM_LOOKUP file=%s local=%06X handle=%08X form=%p type=%u\n",name,local,id,form,form?*((unsigned char*)form+4):0);fflush(logFile);
    }
    return true;
}
static bool installJIPFormLookup() {
    auto* command=commands->getName(jipFormChange.name);
    auto* parent=command?commands->getParent(command):nullptr;
    fprintf(logFile,"JIP_COMMAND_CHECK parent=%s params=%u return_type=%u\n",parent?parent->name:"<none>",command?command->numParams:0,command?commands->getReturnType(command):0);fflush(logFile);
    if(!command || !command->execute || command->numParams!=2 || commands->getReturnType(command)!=1 || !parent || lstrcmpiA(parent->name,"JIP LN NVSE"))return false;
    jipFormChange.original=command->execute;
    return jipFormChange.patch.replace((uint32_t)&command->execute,(unsigned char*)&jipFormChange.original,(unsigned char*)&jipFormChange.callback,4);
}
static bool installCommands() {
    if(!commands || commands->version<2 || !scripts || !scripts->extract) {
        fprintf(logFile,"COMMAND_API_ERROR table=%p version=%u script=%p extractor=%p\n",commands,commands?commands->version:0,scripts,scripts?(void*)scripts->extract:nullptr);fflush(logFile);return false;
    }
    for(auto& change:commandChanges){
        auto* command=commands->getName(change.name);
        auto* parent=command?commands->getParent(command):nullptr;
        fprintf(logFile,"COMMAND_CHECK name=%s pointer=%p execute=%p parent=%s params=%u return_type=%u\n",change.name,command,command?(void*)command->execute:nullptr,parent?parent->name:"core",command?command->numParams:0,command?commands->getReturnType(command):0);fflush(logFile);
        if(!command || !command->execute)return false;change.original=command->execute;
    }
    for(auto& change:commandChanges) {
        auto* command=commands->getName(change.name);
        if(!change.patch.replace((uint32_t)&command->execute,(unsigned char*)&change.original,(unsigned char*)&change.callback,4)) {
            for(auto& rollback:commandChanges)rollback.patch.restore();return false;
        }
    }return true;
}
static WideStatus __cdecl countAPI(uint32_t* n){if(!n)return WideInvalidArgument;if(!ready)return WideNotReady;*n=loadedCount;return WideOK;}
static WideStatus __cdecl fileAPI(uint32_t slot,WideFileKey* key,char* name,uint32_t size) {
    if(!key || !name || !size)return WideInvalidArgument;if(!ready)return WideNotReady;
    if(slot>=loadedCount)return WideNotFound;const char* s=(char*)loadedFiles[slot]+0x20;
    if(strlen(s)+1>size)return WideBufferTooSmall;strcpy(name,s);
    *key=slot<legacySlots?WideFileKey{WideLegacyFile,slot}:WideFileKey{WideExtendedFile,slot-legacySlots};return WideOK;
}
static WideStatus __cdecl findAPI(const char* name,WideFileKey* key) {
    if(!name || !*name || !key)return WideInvalidArgument;if(!ready)return WideNotReady;
    for(uint32_t i=0;i<loadedCount;i++)if(!lstrcmpiA(name,(char*)loadedFiles[i]+0x20)) {
        *key=i<legacySlots?WideFileKey{WideLegacyFile,i}:WideFileKey{WideExtendedFile,i-legacySlots};return WideOK;
    }return WideNotFound;
}
static WideStatus __cdecl resolveAPI(const WideFileKey* key,uint32_t local,uint32_t* handle) {
    if(!key || !handle || local>0xFFFFFF || key->domain>WideFixed)return WideInvalidArgument;if(!ready)return WideNotReady;
    uint32_t id=0;
    if(key->domain==WideExtendedFile) {
        if(local<0x800)return WideInvalidArgument;if(loadedCount<=legacySlots || key->owner>=loadedCount-legacySlots)return WideNotFound;
        auto* e=registry.find({key->owner,local});if(!e)return WideNotFound;id=e->handle;
    }else if(key->domain==WideLegacyFile) {
        if(local<0x800)return WideInvalidArgument;if(key->owner>=legacySlots || key->owner>=loadedCount)return WideNotFound;id=key->owner<<24|local;
    }else {
        if(key->owner!=UINT32_MAX || (key->domain==WideFixed && local>=0x800))return WideInvalidArgument;
        id=key->domain==WideFixed?local:0xFF000000|local;
    }
    if(!lookup(id))return WideNotFound;*handle=id;return WideOK;
}
static WideStatus __cdecl identifyAPI(uint32_t id,WideFileKey* key,uint32_t* local) {
    if(!key || !local)return WideInvalidArgument;if(!ready)return WideNotReady;if(!lookup(id))return WideNotFound;
    if(auto* e=registry.reverse(id)){*key={WideExtendedFile,e->key.plugin};*local=e->key.local;return WideOK;}
    *local=id&0xFFFFFF;
    if(id<0x800)*key={WideFixed,UINT32_MAX};else if(id>=0xFF000000)*key={WideGenerated,UINT32_MAX};
    else {if((id>>24)>=legacySlots || (id>>24)>=loadedCount)return WideNotFound;*key={WideLegacyFile,id>>24};}
    return WideOK;
}
static const WidePluginAPIv2 api={sizeof(WidePluginAPIv2),2,countAPI,fileAPI,findAPI,resolveAPI,identifyAPI};
extern "C" __declspec(dllexport) const void* __cdecl WidePlugin_GetInterface(uint32_t version,uint32_t size){return version==2 && size>=sizeof(api)?&api:nullptr;}
static bool fixupBridge(RuntimePatch& patch,uint32_t site,const unsigned char* expected,uint32_t n,int fileOffset,int idOffset,uint32_t resume) {
    // Preserve all registers and flags. Translate the known DWORD stack local,
    // then skip the original byte-selector reconstruction block.
    unsigned char b[]={0x9C,0x60,0xFF,0xB5,0,0,0,0,0x8D,0x85,0,0,0,0,0x50,0xB8,0,0,0,0,0xFF,0xD0,0x83,0xC4,8,0x61,0x9D,0xE9,0,0,0,0};
    *(int*)(b+4)=fileOffset;*(int*)(b+10)=idOffset;*(uint32_t*)(b+16)=(uint32_t)&fixEmbedded;
    void* bridge=VirtualAlloc(nullptr,sizeof(b),MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);if(!bridge)return false;
    *(uint32_t*)(b+28)=resume-((uint32_t)bridge+sizeof(b));memcpy(bridge,b,sizeof(b));
    FlushInstructionCache(GetCurrentProcess(),bridge,sizeof(b));codeBridges.push_back(bridge);
    return patch.hook(site,expected,n,bridge);
}
static bool install() {
    for(auto& site:loaderPatchSites)if(memcmp((void*)site.address,site.expected,site.length))return false;
    struct HookSpec {RuntimePatch* patch;uint32_t at,n;unsigned char bytes[16];void* callback;};
    HookSpec hooks[]={
        {&orchestration,0x463070,5,{0x55,0x8B,0xEC,0x6A,0xFF},(void*)&loadFiles},
        {&indexSetter,0x473210,7,{0x55,0x8B,0xEC,0x51,0x89,0x4D,0xFC},(void*)&setIndex},
        {&header,0x472BC0,6,{0x55,0x8B,0xEC,0x83,0xEC,0x0C},(void*)&readHeader},
        {&embedded,0x485D50,10,{0x55,0x8B,0xEC,0x51,0x8B,0x0D,0x5C,0xE4,0x1D,0x01},(void*)&fixEmbedded},
        {&localGetter,0x485BC0,7,{0x55,0x8B,0xEC,0x51,0x89,0x4D,0xFC},(void*)&getLocal},
        {&localCompare,0x485BE0,5,{0x55,0x8B,0xEC,0x51,0x56},(void*)&compareLocal},
        {&cloneHook,0x473AE0,5,{0x55,0x8B,0xEC,0x6A,0xFF},(void*)&cloneFile},
        {&perFileHook,0x467780,9,{0x55,0x8B,0xEC,0x81,0xEC,0x50,0x01,0x00,0x00},(void*)&loadOne},
        {&masterBuilderHook,0x471870,6,{0x55,0x8B,0xEC,0x83,0xEC,0x24},(void*)&buildMasters}};
    for(auto& h:hooks)if(memcmp((void*)h.at,h.bytes,h.n))return false;
    const unsigned char onam[]={0x8B,0x85,0xA8,0xFE,0xFF,0xFF};
    const unsigned char group[]={0x8B,0x4D,0xC4,0xC1,0xE9,0x18};
    if(memcmp((void*)0x468102,onam,sizeof(onam)) || memcmp((void*)0x461F5F,group,sizeof(group)))return false;
    for(auto& site:loaderPatchSites) {
        unsigned char replacement[16];memcpy(replacement,site.replacement,site.length);
        *(uint32_t*)(replacement+site.displacement)=site.table?(uint32_t)loadedFiles:(uint32_t)&loadedCount;
        operandPatches.emplace_back();if(!operandPatches.back().replace(site.address,site.expected,replacement,site.length))goto rollback;
    }
    for(auto& h:hooks)if(!h.patch->hook(h.at,h.bytes,h.n,h.callback))goto rollback;
    if(!fixupBridge(onamPatch,0x468102,onam,sizeof(onam),8,-0x158,0x468169))goto rollback;
    if(!fixupBridge(groupSearchPatch,0x461F5F,group,sizeof(group),-0x2C,-0x3C,0x461FA6))goto rollback;
    return true;
rollback:
    groupSearchPatch.restore();onamPatch.restore();for(auto& h:hooks)h.patch->restore();for(auto& p:operandPatches)p.restore();return false;
}
static void onMessage(Message* m) {
    if(m->type==6)wide::faults::stage("pre_load_game");
    if(m->type==8)wide::faults::stage("post_load_game");
    if(m->type==14)wide::faults::stage("new_game");
    if(m->type==4)wide::faults::stage("save_game");
    if(m->type==1 || m->type==7)wide::faults::stage("exit_message");
    if(timerCallbackProbeCommand && (m->type==6 || m->type==14) && timerCallbackProbeState().active){timerCallbackProbeState().passed=false;finishTimerCallbackProbe();}
    if(wideJipAddedVariables && (m->type==6 || m->type==14))jipAddedVariablesRuntime.clear();
    if(wideJipScriptLinks && (m->type==6 || m->type==14))jipLinkOwnersRuntime.clear();
    if(jipScriptLinkProbeMode && (m->type==6 || m->type==14))jipScriptLinkProbeState().queued=false;
    if(traceStringOwners && wide::replacesCoreOwnership(m->type)){auto& state=stringOwnerState();AcquireSRWLockExclusive(&state.lock);state.tracker.clear();state.apiCreates=state.expressionAssignments=state.allocations=0;ReleaseSRWLockExclusive(&state.lock);}
    if(traceArrayOwners && wide::replacesCoreOwnership(m->type)){auto& state=arrayOwnerState();StringOwnerLock guard(state.lock,true);++state.epoch;state.tracker.clear();state.references.clear();arrayIdentityRestored=false;arrayReleaseWitness={};arrayPendingReferenceContext={};memset(arrayInternalCallHits,0,sizeof(arrayInternalCallHits));memset(arraySelfMoveHits,0,sizeof(arraySelfMoveHits));arraySelfMovesMatched=arraySelfMovesMissing=0;arrayPoolCalls=arrayPoolMoved=arrayPoolRejected=arrayPoolErrors=0;state.allocations=state.knownCreates=state.unknownCreates=state.referenceAdds=state.referenceRemoves=0;}
    if(m->type==14 && (traceArrayOwners || traceStringOwners)){fputs("WIDE_NEW_GAME_OWNERSHIP_PRESERVED reason=core_clean_retains_referenced_objects allocation_hooks_invalidate_reused_ids\n",logFile);fflush(logFile);}
    if(m->type==6){coreStringPreloadActive=true;coreStringGateChecked=coreStringGateAccepted=false;coreStringOwnersRestored=0;if(wideStringLoad)stringRestoreState()=StringRestoreState{};if(fixedOrderWideArrays)coreArrayLoadState()=CoreArrayLoadState{};}
    if(m->type==8 || m->type==14)coreStringPreloadActive=false;
    if(m->type==14 && ready){fputs("GAMEPLAY_EVENT=NewGame\n",logFile);fflush(logFile);}
    if(m->type==8 && ready){fprintf(logFile,"GAMEPLAY_POST_LOAD_SUCCESS=%u\n",m->data!=nullptr);fflush(logFile);}
    if(m->type==9) {
        wide::faults::refreshModules();wide::faults::stage("startup_preflight");
        try {if(!wide::startup::run(startupModule,startupIniPath,orderFile,additionalDirectory,logFile))ExitProcess(91);}
        catch(const std::exception& e){stop(e.what());}
        catch(...){stop("unexpected startup preflight failure");}
        // xNVSE has finished loading native plugins here. Probe module names
        // now, rather than during our own NVSEPlugin_Load (load order varies).
        {
            bool jip=wide::optionalAdapterSupported("jip_nvse.dll",wide::jipOriginalHash,logFile,wide::jipPPHash);
            bool sup=wide::optionalAdapterSupported("supNVSE.dll","61b0f1760a643ee749c785bf989f22b18f7b445891d2595f55445281c8a22e6c",logFile);
            bool showoff=wide::optionalAdapterSupported("ShowOffNVSE.dll","37cb22c5288fedd0d57196c8c2f6bbaba5a1dafd9ce58f14dac9410dbee7ef3e",logFile);
            bool stewie=wide::optionalAdapterSupported("nvse_stewie_tweaks.dll","c19007b47f39df2ce07cfc1add1a27090302cf35e1673ba35bee61cb5800db95",logFile);
            supportedStewie=stewie && optionalAdaptersEnabled;
            if(!optionalAdaptersEnabled){
                wideJIPFormLookup=wideJipPrivateMaps=wideJipSave=wideJipAddedVariables=wideJipScriptLinks=false;
                supLegacyCacheGuard=supWideHudOwners=false;
                wideShowOffIni=showOffRandomOwners=wideShowOffTimers=false;
                wideStewieModNames=traceStewieLocale=traceShowOffTimer=false;
                fputs("OPTIONAL_ADAPTERS_DISABLED source=OptionalAdaptersEnabled core_loader_retained=1\n",logFile);fflush(logFile);
            }else if(autoDetectOptionalAdapters){
                wideJIPFormLookup=wideJipPrivateMaps=wideJipSave=wideJipAddedVariables=wideJipScriptLinks=jip;
                supLegacyCacheGuard=supWideHudOwners=sup;
                wideShowOffIni=showOffRandomOwners=wideShowOffTimers=showoff;
                wideStewieModNames=stewie;
            }else{
                if(!jip)wideJIPFormLookup=wideJipPrivateMaps=wideJipSave=wideJipAddedVariables=wideJipScriptLinks=false;
                if(!sup)supLegacyCacheGuard=supWideHudOwners=false;
                if(!showoff)wideShowOffIni=showOffRandomOwners=wideShowOffTimers=false;
                if(!stewie)wideStewieModNames=false;
            }
            if(!stewie)traceStewieLocale=false;
            if(!showoff)traceShowOffTimer=false;
            if(jip && !wideSaveIdentity)stop("auto-detected JIP adapter requires core save identity");
            if(showoff && !wideSaveIdentity)stop("auto-detected ShowOff timer adapter requires core save identity");
            fprintf(logFile,"OPTIONAL_ADAPTER_DETECTION jip=%u sup=%u showoff=%u stewie=%u source=loaded_dll_names_and_build_fingerprints\n",
                    jip,sup,showoff,stewie);fflush(logFile);
            wide::showOptionalAdapterWarnings();
            wide::faults::counts(loadedCount,(wideJIPFormLookup || wideJipPrivateMaps || wideJipSave || wideJipAddedVariables || wideJipScriptLinks?1:0) |
                (supLegacyCacheGuard || supWideHudOwners?2:0) | (wideShowOffIni || showOffRandomOwners || wideShowOffTimers?4:0) |
                (wideStewieModNames || supportedStewie?8:0));
        }
        wide::faults::stage("installing_runtime_hooks_see_loader_ACTIVE_markers");
        if((traceOverflow || traceStewieLocale) && !installOverflowCapture())stop("exception capture setup failed");
        if(traceStewieLocale) {
            stewieDiagnosticModule=GetModuleHandleA("nvse_stewie_tweaks.dll");
            const unsigned char expected[]={0x55,0x8B,0xEC,0x6A,0xFF};
            if(!stewieDiagnosticModule || !stewieFacetHook.hook((uint32_t)stewieDiagnosticModule+0xEE20,expected,5,(void*)&observeStewieFacet))stop("Stewie locale diagnostic signature mismatch");
            localeSnapshot("post-plugin-load");
        }
        if(wideStewieModNames) {
            auto module=GetModuleHandleA("nvse_stewie_tweaks.dll");
            unsigned char expected[]={0x83,0x3D,0,0,0,0,0};
            *(uint32_t*)(expected+2)=(uint32_t)module+0xFED50;
            if(!module || !stewieModNameHook.hook((uint32_t)module+0x3E70,expected,sizeof(expected),(void*)&stewieModName))stop("Stewie filename adapter signature mismatch");
            fputs("WIDE_STEWIE_MOD_NAMES_ACTIVE\n",logFile);fflush(logFile);
        }
        if(traceRuntime && !installRuntimeTrace())stop("local runtime trace signature mismatch");
        if(traceNvseFastFail || traceShowOffTimer) {
            char ini[MAX_PATH]{},path[MAX_PATH]{};
            GetModuleFileNameA(GetModuleHandleA("WideNormalLoader.dll"),ini,sizeof(ini));
            char* suffix=strrchr(ini,'.');if(!suffix)stop("fastfail diagnostic INI path missing");strcpy(suffix,".ini");
            GetPrivateProfileStringA("WideLoader","LogFile","",path,sizeof(path),ini);
            if(!path[0])stop("diagnostic log path missing");
            if(traceNvseFastFail && !wide::installNvseFastFailCapture(path,logFile))stop("xNVSE fastfail diagnostic version/signature/setup mismatch");
            if(traceShowOffTimer && !wide::installShowOffTimerCapture(path,logFile))stop("ShowOff timer diagnostic version/signature/setup mismatch");
        }
        if(supHudProbeCommand) {
            auto* command=commands->getName(supHudProbe.longName);
            if(!command || command->opcode!=0x7F01 || command->execute!=probeSupHud)stop("SUP HUD probe opcode collision");
        }
        if(showOffRandomProbeCommand){auto* command=commands->getName(showOffRandomProbe.longName);if(!command || command->opcode!=0x7F02 || command->execute!=probeShowOffRandom)stop("ShowOff random probe opcode collision");}
        if(jipPrivateMapsProbeCommand){auto* command=commands->getName(jipMapProbe.longName);if(!command || command->opcode!=0x7F03 || command->execute!=probeJipPrivateMaps)stop("JIP private maps probe opcode collision");}
        if(jipValuesProbeCommand){auto* command=commands->getName(jipValuesProbe.longName);if(!command || command->opcode!=0x7F04 || command->execute!=probeJipValues)stop("JIP values probe opcode collision");}
        if(jipDialogueCaptureCommand){auto* command=commands->getName(jipDialogueCapture.longName);if(!command || command->opcode!=0x7F05 || command->execute!=captureJipDialogue)stop("JIP dialogue capture opcode collision");}
        if(jipDialogueProbeCommand){auto* command=commands->getName(jipDialogueProbe.longName);if(!command || command->opcode!=0x7F06 || command->execute!=probeJipDialogue)stop("JIP dialogue probe opcode collision");}
        if(wideSaveProbeCommands){auto* a=commands->getName(wideSavePrepare.longName);auto* b=commands->getName(wideSaveCheck.longName);if(!a || !b || a->opcode!=0x7F07 || b->opcode!=0x7F08 || a->execute!=prepareWideSave || b->execute!=checkWideSave)stop("save probe opcode collision");}
        if(wideSaveIdentity){auto* c=commands->getName(wideIdentityCheck.longName);if(!c || c->opcode!=0x7F09 || c->execute!=checkSaveIdentity)stop("save identity opcode collision");}
        if(persistentArrayProbeCommand){auto* c=commands->getName(persistentArrayCheck.longName);if(!c || c->opcode!=0x7F0A || c->execute!=checkPersistentArrays)stop("persistent array opcode collision");}
        if(combinedProbeCommand){auto* c=commands->getName(combinedCompatibilityProbe.longName);if(!c || c->opcode!=0x7F0B || c->execute!=probeCombinedCompatibility)stop("combined compatibility opcode collision");}
        if(!install()){fputs("HOOK_CONFLICT_OR_UNSUPPORTED_RUNTIME: no normal-loader changes activated\n",logFile);fflush(logFile);}
        else {
            if(wideNativeSaveRefs){
                if(!installNativeSaveRefs())stop("native save FormID adapter runtime/signature mismatch");
                fputs("WIDE_NATIVE_SAVE_REFS_ACTIVE site=00846D80 scope=FD_FE_form_array_entries legacy_and_generated_use_original\n",logFile);fflush(logFile);
            }
            if(fixedOrderWideStrings){
                if(!installFixedOrderStrings())stop("fixed-order core string reader runtime/signature mismatch");
                fputs("WIDE_CORE_STRING_READER_ACTIVE scope=identical_full_plugin_order_only\n",logFile);fflush(logFile);
            }
            if(traceStringOwners){if(!installStringOwnerTrace())stop("string owner trace version/signature/layout mismatch");fputs("WIDE_STRING_OWNER_TRACE_ACTIVE api_create=C9BB0 expression_assign=B5B70 unused_id=C9D50 persistence=not_written\n",logFile);fflush(logFile);}
            if(traceArrayOwners){
                if(!installArrayOwnerTrace()){
                    // Creator tracing is diagnostic only. A new xNVSE build
                    // may move command wrappers without changing the core
                    // array reader. Do not abort startup for this probe;
                    // disable the dependent observers and keep core restore.
                    traceArrayOwners=traceArrayReferences=traceArrayInternalCalls=traceArraySelfMoves=traceArrayPoolMoves=false;
                    traceArrayIssueInventory=traceArrayContents=false;
                    fputs("WIDE_ARRAY_CREATOR_TRACE_DISABLED reason=unsupported_xnvse_layout core_adapters_retained=1\n",logFile);fflush(logFile);
                } else {
                    fputs("WIDE_ARRAY_CREATOR_TRACE_ACTIVE scope=ar_List_and_public_create_APIs persistence=not_written\n",logFile);fflush(logFile);
                }
            }
            if(traceArrayReferences){if(!installArrayReferenceTrace())stop("array reference trace version/signature mismatch");fputs("WIDE_ARRAY_REFERENCE_TRACE_ACTIVE scope=script_assignment_and_known_parent_array_elements persistence=not_written\n",logFile);fflush(logFile);}
            if(traceArrayPoolMoves){if(!installArrayPoolMoves())stop("array pool relocation signature mismatch");fputs("WIDE_ARRAY_POOL_MOVE_ADAPTER_ACTIVE rva=0005B300 abi=fastcall_entry8\n",logFile);fflush(logFile);}
            if(traceArraySelfMoves){if(!installArraySelfMoves())stop("self-owning array move signature mismatch");fputs("WIDE_ARRAY_SELF_MOVE_ADAPTERS_ACTIVE sites=8\n",logFile);fflush(logFile);}
            if(traceArrayInternalCalls){if(!installArrayInternalCalls())stop("array internal call bridge signature mismatch");fputs("WIDE_ARRAY_INTERNAL_CALL_BRIDGES_ACTIVE calls=6 scope=foreach_and_script_local_lifecycle\n",logFile);fflush(logFile);}
            if(fixedOrderWideArrays){if(!installFixedOrderArrays())stop("fixed-order core array reader runtime/signature mismatch");fputs("WIDE_ARRAY_READER_ACTIVE owner=8806 refs=8893 forms=8C72 scope=identical_full_plugin_order\n",logFile);fflush(logFile);}
            if(supLegacyCacheGuard) {
                if(!installSupLegacyCacheGuard())stop("SUP legacy cache guard version/signature mismatch");
                fputs("SUP_LEGACY_CACHE_GUARD_ACTIVE\n",logFile);fflush(logFile);
            }
            if(supWideHudOwners) {
                if(!supLegacyCacheGuard || !supHudRuntime.install(GetModuleHandleA("supNVSE.dll"),commands,supScriptOwner,supFilename))stop("SUP HUD ownership adapters version/signature/preflight mismatch");
                fputs("SUP_WIDE_HUD_OWNERS_ACTIVE commands=36 transfers=37 native_entries=14\n",logFile);fflush(logFile);
            }
            if(showOffRandomOwners){
                if(!showOffRandomRuntime.install(GetModuleHandleA("ShowOffNVSE.dll"),commands,supScriptOwner))stop("ShowOff random owner version/signature/preflight mismatch");
                fputs("SHOWOFF_WIDE_RANDOM_OWNERS_ACTIVE commands=6 transfers=4\n",logFile);fflush(logFile);
            }
            if(wideShowOffTimers){
                if(!wideSaveIdentity)stop("ShowOff timer adapter requires save identity channel");
                if(timerInstallAfterPluginLoad){fputs("WIDE_SHOWOFF_TIMERS_DEFERRED until=plugin_load_complete_before_menu_scripts\n",logFile);fflush(logFile);}
                else if(timerInstallAfterMenu){fputs("WIDE_SHOWOFF_TIMERS_DEFERRED until=first_game_loop\n",logFile);fflush(logFile);}
                else {
                    if(!showOffTimerRuntime.install(GetModuleHandleA("ShowOffNVSE.dll"),supScriptOwner,maxFiles,logFile))stop("ShowOff timer adapter version/signature/preflight mismatch");
                    timerRuntimeInstalled=true;fputs("WIDE_SHOWOFF_TIMERS_ACTIVE bridges=13 width_sites=15 full_owner_save=WTMR legacy_save=legacy_public_subset\n",logFile);fflush(logFile);
                }
            }
            if(wideJipPrivateMaps){
                if(!jipPrivateMapsRuntime.install(GetModuleHandleA("jip_nvse.dll"),commands,supScriptOwner))stop("JIP private map owner version/signature/preflight mismatch");
                fputs("JIP_WIDE_PRIVATE_MAPS_ACTIVE owner_calls=21 narrowing_sites=21\n",logFile);fflush(logFile);
            }
            if(wideJipAddedVariables){
                if(!jipAddedVariablesRuntime.install(GetModuleHandleA("jip_nvse.dll"),commands,supScriptOwner))stop("JIP added variable adapter version/signature/preflight mismatch");
                fputs("WIDE_JIP_ADDED_VARIABLES_ACTIVE scope=observed_runtime_author_ownership persistence=pending\n",logFile);fflush(logFile);
            }
            if(wideJipScriptLinks){
                if(!jipLinkOwnersRuntime.install(GetModuleHandleA("jip_nvse.dll"),commands,supScriptOwner))stop("JIP linked reference owner adapter preflight mismatch");
                if(!jipScriptLinkRuntime().bind(GetModuleHandleA("jip_nvse.dll"),lookup,
                    [](uint32_t v,uint8_t b,uint32_t& o){return jipAddedVariablesRuntime.variableOwner(v,b,o);},
                    [](uint32_t s,uint32_t t,uint8_t b,uint32_t& o){return jipLinkOwnersRuntime.owner(s,t,b,o);},
                    [](void* s,void* l,uint32_t id,const std::string& n,uint32_t o){return jipAddedVariablesRuntime.restoreVariable(s,l,id,n,o);},
                    [](void* s,void* t,uint32_t o){return jipLinkOwnersRuntime.restore(s,t,o);}))stop("JIP script/link save runtime preflight mismatch");
                if(!jipScriptLinkRuntime().installSaveFilter([](){stop("JIP native save author filter rejected ambiguous or invalid data");}))stop("JIP script/link save filter signature mismatch");
                fputs("WIDE_JIP_SCRIPT_LINK_ACTIVE companion=WJSL runtime_validation=pending\n",logFile);fflush(logFile);
            }
            if(!installCommands())stop("xNVSE ownership command adapters could not be installed");
            if((wideVoiceIds || traceDialogueResults) && !installVoiceDiagnostics())stop("voice filename/dialogue diagnostic signature mismatch");
            if(traceDialogue || wideResponseRefs) {
                const unsigned char expected[]={0x55,0x8B,0xEC,0x6A,0xFF};
                if(!dialogueLinkHook.hook(0x617580,expected,sizeof(expected),(void*)&traceDialogueLink))stop("dialogue link diagnostic signature mismatch");
                fputs("DIALOGUE_LINK_TRACE_ACTIVE\n",logFile);fflush(logFile);
            }
            // Diagnostic only: this RVA was disassembled in the local xNVSE
            // DLL A8DCB0C0...49211F5. Log arguments before the original parser.
            // No function is rejected or altered by this observer.
            if(traceFunctions) {
                auto nvse=GetModuleHandleA("nvse_1_4.dll");const unsigned char expected[]={0x55,0x8B,0xEC,0x6A,0xFF};
                if(!nvse || !functionInfoHook.hook((uint32_t)nvse+0x75C80,expected,sizeof(expected),(void*)&traceFunctionInfo))stop("local xNVSE function diagnostic signature mismatch");
            }
            if(wideLambdaIds) {
                auto nvse=GetModuleHandleA("nvse_1_4.dll");
                if(!nvse || !installWideLambda(nvse))stop("local xNVSE lambda allocation signature mismatch");
                fputs("WIDE_LAMBDA_GENERATED_IDS_ACTIVE\n",logFile);fflush(logFile);
            }
            if(wideShowOffIni) {
                if(!installShowOffINI())stop("local ShowOff INI adapter signature mismatch");
                fputs("WIDE_SHOWOFF_INI_ACTIVE\n",logFile);fflush(logFile);
            }
            if(wideJIPFormLookup) {
                if(!installJIPFormLookup())stop("JIP GetFormFromMod adapter ABI mismatch");
                fputs("WIDE_JIP_FORM_LOOKUP_ACTIVE\n",logFile);fflush(logFile);
            }
            fputs("NORMAL_LOADER_HOOKS_ACTIVE\nXNVSE_COMMAND_ADAPTERS=6\n",logFile);fflush(logFile);
        }
    }
    if((m->type==1 || m->type==7) && ready){fprintf(logFile,"NATIVE_EXIT_MESSAGE=%u\n",m->type);fflush(logFile);}
    if(m->type==20 && ready) {
        wide::faults::stage("game_loop");
        if(jipScriptLinkProbeMode)advanceJipScriptLinkProbe();
        if(timerCallbackProbeCommand)advanceTimerCallbackProbe();
        if(wideShowOffTimers && !timerInstallAfterPluginLoad && timerInstallAfterMenu && !timerRuntimeInstalled){
            if(!showOffTimerRuntime.install(GetModuleHandleA("ShowOffNVSE.dll"),supScriptOwner,loadedCount,logFile))stop("deferred ShowOff timer adapter preflight mismatch");
            timerRuntimeInstalled=true;fputs("WIDE_SHOWOFF_TIMERS_ACTIVE phase=first_game_loop bridges=13 width_sites=15 full_owner_save=WTMR legacy_save=legacy_public_subset\n",logFile);fflush(logFile);
        }
        if(!loopLogged) {
            wide::faults::refreshModules();
            loopLogged=true;firstLoop=GetTickCount();uint32_t verified=0,unresolved=0;
            auto identities=registry.snapshot();FILE* missing=dumpUnresolved?fopen(unresolvedReport.c_str(),"wb"):nullptr;
            if(dumpUnresolved && !missing)stop("unresolved identity report could not be opened");
            if(missing)fputs("handle,owner_slot,local,filename\n",missing);
            for(auto& e:identities) {
                auto* f=lookup(e.handle);
                if(!f){unresolved++;if(missing)fprintf(missing,"%08X,%u,%06X,\"%s\"\n",e.handle,e.key.plugin+legacySlots,e.key.local,(char*)loadedFiles[e.key.plugin+legacySlots]+0x20);continue;}
                if(*(uint32_t*)((unsigned char*)f+0xC)!=e.handle || getLocal(f,nullptr)!=e.key.local)stop("normal loader form identity mismatch");
                verified++;
            }
            if(missing)fclose(missing);
            fprintf(logFile,"FIRST_GAME_LOOP files=%u wide_forms_verified=%u unresolved_handles=%u\n",loadedCount,verified,unresolved);fflush(logFile);
            if(traceStewieLocale)localeSnapshot("first-loop");
        }
        if(diagnosticHold && GetTickCount()-firstLoop>=diagnosticHold*1000) {
            fprintf(logFile,"DIAGNOSTIC_TIMEOUT_SECONDS=%u\n",diagnosticHold);fflush(logFile);ExitProcess(0);
        }
    }
}
extern "C" __declspec(dllexport) bool NVSEPlugin_Query(const NVSEInterface* n,PluginInfo* info) {
    *info={1,"WideNormalLoader",1};return !n->isEditor && !n->isNogore && n->runtimeVersion==0x040020D0;
}
extern "C" __declspec(dllexport) bool NVSEPlugin_Load(const NVSEInterface* n) {
    HMODULE self=nullptr;GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,(const char*)&NVSEPlugin_Load,&self);
    char ini[MAX_PATH];GetModuleFileNameA(self,ini,MAX_PATH);auto* dot=strrchr(ini,'.');if(!dot)return false;strcpy(dot,".ini");
    if(GetPrivateProfileIntA("WideLoader","Enabled",0,ini)!=1)return false;
    char path[MAX_PATH];GetPrivateProfileStringA("WideLoader","LoadOrderFile","",path,MAX_PATH,ini);orderFile=path;
    GetPrivateProfileStringA("Diagnostics","AdditionalPluginDirectory","",path,MAX_PATH,ini);additionalDirectory=path;
    diagnosticHold=GetPrivateProfileIntA("Diagnostics","ExitAfterSeconds",0,ini);if(diagnosticHold>600)return false;
    GetPrivateProfileStringA("WideLoader","LogFile","WideNormalLoader.log",path,MAX_PATH,ini);logFile=fopen(path,"wb");if(!logFile)return false;
    startupModule=self;startupIniPath=wide::startup::modulePath(self);
    startupIniPath.replace(startupIniPath.find_last_of(L'.'),std::wstring::npos,L".ini");
    if(GetPrivateProfileIntA("Diagnostics","FaultReports",1,ini)==1){
        bool active=wide::faults::initialize();
        fprintf(logFile,"FAULT_REPORTER status=%s path=%ls mode=first_chance_observer\n",active?"active":"unavailable",wide::faults::reportPath);fflush(logFile);
    }
    unresolvedReport=std::string(path)+".unresolved.csv";dumpUnresolved=GetPrivateProfileIntA("Diagnostics","DumpUnresolved",0,ini)==1;
    traceUnresolvedOrigin=GetPrivateProfileIntA("Diagnostics","TraceUnresolvedOrigin",0,ini)==1;
    wideWeaponProjectileRefs=GetPrivateProfileIntA("Diagnostics","WideWeaponProjectileRefs",0,ini)==1;
    traceFunctions=GetPrivateProfileIntA("Diagnostics","TraceLocalFunctionInfo",0,ini)==1;
    traceDialogue=GetPrivateProfileIntA("Diagnostics","TraceDialogueLink",0,ini)==1;
    wideResponseRefs=GetPrivateProfileIntA("Diagnostics","WideResponseRefs",0,ini)==1;
    wideLambdaIds=GetPrivateProfileIntA("Diagnostics","WideLambdaIds",0,ini)==1;
    wideShowOffIni=GetPrivateProfileIntA("Diagnostics","WideShowOffIni",0,ini)==1;
    wideJIPFormLookup=GetPrivateProfileIntA("Diagnostics","WideJIPFormLookup",0,ini)==1;
    autoDetectOptionalAdapters=GetPrivateProfileIntA("WideLoader","AutoDetectOptionalAdapters",0,ini)==1;
    optionalAdaptersEnabled=GetPrivateProfileIntA("WideLoader","OptionalAdaptersEnabled",1,ini)==1;
    wideJipPrivateMaps=GetPrivateProfileIntA("Diagnostics","WideJipPrivateMaps",0,ini)==1;
    jipPrivateMapsProbeCommand=GetPrivateProfileIntA("Diagnostics","JipPrivateMapsProbeCommand",0,ini)==1;
    jipValuesProbeCommand=GetPrivateProfileIntA("Diagnostics","JipValuesProbeCommand",0,ini)==1;
    jipValueDiskScripts=GetPrivateProfileIntA("Diagnostics","JipValueDiskScripts",0,ini)==1;
    {char output[MAX_PATH]{};GetPrivateProfileStringA("Diagnostics","JipValueFixtureOutputDirectory","",output,sizeof(output),ini);jipValueFixtureOutput=output;}
    jipDialogueCaptureCommand=GetPrivateProfileIntA("Diagnostics","JipDialogueCaptureCommand",0,ini)==1;
    persistentArrayCapture=GetPrivateProfileIntA("Diagnostics","PersistentArrayCapture",0,ini)==1;
    persistentArrayProbeCommand=GetPrivateProfileIntA("Diagnostics","PersistentArrayProbeCommand",0,ini)==1;
    traceArrayOwners=GetPrivateProfileIntA("Diagnostics","TraceArrayOwners",0,ini)==1;
    traceArraySelfMoves=GetPrivateProfileIntA("Diagnostics","TraceArraySelfMoves",0,ini)==1;
    traceArrayPoolMoves=GetPrivateProfileIntA("Diagnostics","TraceArrayPoolMoves",0,ini)==1;
    traceArrayIssueInventory=GetPrivateProfileIntA("Diagnostics","TraceArrayIssueInventory",0,ini)==1;
    traceArrayInternalCalls=GetPrivateProfileIntA("Diagnostics","TraceArrayInternalCalls",0,ini)==1;
    traceArrayReferences=GetPrivateProfileIntA("Diagnostics","TraceArrayReferences",0,ini)==1;
    captureArrayRelease=GetPrivateProfileIntA("Diagnostics","CaptureArrayRelease",0,ini)==1;
    captureArraySharing=GetPrivateProfileIntA("Diagnostics","CaptureArraySharing",0,ini)==1;
    arrayReleaseProbe=GetPrivateProfileIntA("Diagnostics","ArrayReleaseProbe",0,ini)==1;
    arraySharingProbe=GetPrivateProfileIntA("Diagnostics","ArraySharingProbe",0,ini)==1;
    jipDialogueProbeCommand=GetPrivateProfileIntA("Diagnostics","JipDialogueProbeCommand",0,ini)==1;
    wideSaveProbeCommands=GetPrivateProfileIntA("Diagnostics","WideSaveProbeCommands",0,ini)==1;
    wideSaveIdentity=GetPrivateProfileIntA("Diagnostics","WideSaveIdentity",0,ini)==1;
    wideJipSave=GetPrivateProfileIntA("Diagnostics","WideJipSave",0,ini)==1;
    traceWideStrings=GetPrivateProfileIntA("Diagnostics","TraceWideStrings",0,ini)==1;
    traceCoreArrays=GetPrivateProfileIntA("Diagnostics","TraceCoreArrays",0,ini)==1;
    traceStringOwners=GetPrivateProfileIntA("Diagnostics","TraceStringOwners",0,ini)==1;
    wideStringSave=GetPrivateProfileIntA("Diagnostics","WideStringSave",0,ini)==1;
    wideArraySave=GetPrivateProfileIntA("Diagnostics","WideArraySave",0,ini)==1;
    wideArrayLoad=GetPrivateProfileIntA("Diagnostics","WideArrayLoad",0,ini)==1;
    if(wideArraySave && (!wideSaveIdentity || !traceArrayOwners || !traceArrayReferences))stop("array identity writer requires full identities and creator/reference tracking");
    if(traceStringOwners && !traceWideStrings)stop("string owner trace requires string snapshot");
    if(wideStringSave && (!traceStringOwners || !wideSaveIdentity))stop("string owner save requires lifetime tracking and full plugin identities");
    wideNativeSaveRefs=GetPrivateProfileIntA("Diagnostics","WideNativeSaveRefs",0,ini)==1;
    fixedOrderWideStrings=GetPrivateProfileIntA("Diagnostics","FixedOrderWideStrings",0,ini)==1;
    fixedOrderWideArrays=GetPrivateProfileIntA("Diagnostics","FixedOrderWideArrays",0,ini)==1;
    wideArrayReorder=GetPrivateProfileIntA("Diagnostics","WideArrayReorder",0,ini)==1;
    wideArrayBoundary=GetPrivateProfileIntA("Diagnostics","WideArrayBoundary",0,ini)==1;
    if(wideArrayBoundary && (!wideArrayReorder || !wideArrayLoad || !traceArrayPoolMoves))stop("array boundary migration requires full identity remapping and allocator tracking");
    if(wideArrayReorder && (!wideArrayLoad || !traceArrayPoolMoves))stop("array reorder requires validated identity reader and allocator reference tracking");
    if(wideArrayLoad && (!wideArraySave || !fixedOrderWideArrays))stop("array identity reader requires writer and tested fixed-order native array reader");
    traceArrayContents=GetPrivateProfileIntA("Diagnostics","TraceArrayContents",0,ini)==1;
    if(traceArrayContents && !fixedOrderWideArrays)stop("array content checks require validated array import gate");
    if(fixedOrderWideArrays && (!wideSaveIdentity || !traceCoreArrays))stop("fixed-order array adapter requires full identities and array snapshots");
    wideStringLoad=GetPrivateProfileIntA("Diagnostics","WideStringLoad",0,ini)==1;
    if(wideStringLoad && (!wideStringSave || !fixedOrderWideStrings))stop("full string owner reader requires tested writer and core string bridge");
    if(fixedOrderWideStrings && (!wideSaveIdentity || !wideNativeSaveRefs))stop("fixed-order string reader requires identity and native save adapters");
    if(wideNativeSaveRefs && !wideSaveIdentity)stop("native save FormID adapter requires full identity metadata");
    if(wideJipSave && (!wideSaveIdentity || !wideJipPrivateMaps))stop("JIP save adapter requires full identity and owner adapters");
    wideStewieModNames=GetPrivateProfileIntA("Diagnostics","WideStewieModNames",0,ini)==1;
    supLegacyCacheGuard=GetPrivateProfileIntA("Diagnostics","SupLegacyCacheGuard",0,ini)==1;
    supWideHudOwners=GetPrivateProfileIntA("Diagnostics","SupWideHudOwners",0,ini)==1;
    supHudProbeCommand=GetPrivateProfileIntA("Diagnostics","SupHudProbeCommand",0,ini)==1;
    showOffRandomOwners=GetPrivateProfileIntA("Diagnostics","WideShowOffRandomOwners",0,ini)==1;
    showOffRandomProbeCommand=GetPrivateProfileIntA("Diagnostics","ShowOffRandomProbeCommand",0,ini)==1;
    supHudDiskScripts=GetPrivateProfileIntA("Diagnostics","SupHudDiskScripts",0,ini)==1;
    {char output[MAX_PATH]{};GetPrivateProfileStringA("Diagnostics","SupHudFixtureOutputDirectory","",output,sizeof(output),ini);supHudFixtureOutput=output;}
    traceRuntime=GetPrivateProfileIntA("Diagnostics","TraceRuntimeTermination",0,ini)==1;
    traceNvseFastFail=GetPrivateProfileIntA("Diagnostics","TraceNvseFastFail",0,ini)==1;
    traceShowOffTimer=GetPrivateProfileIntA("Diagnostics","TraceShowOffTimer",0,ini)==1;
    combinedProbeCommand=GetPrivateProfileIntA("Diagnostics","CombinedCompatibilityProbeCommand",0,ini)==1;
    timerCallbackProbeCommand=GetPrivateProfileIntA("Diagnostics","TimerCallbackProbeCommand",0,ini)==1;
    wideJipAddedVariables=GetPrivateProfileIntA("Diagnostics","WideJipAddedVariables",0,ini)==1;
    wideJipScriptLinks=GetPrivateProfileIntA("Diagnostics","WideJipScriptLinks",0,ini)==1;
    jipScriptLinkProbeMode=GetPrivateProfileIntA("Diagnostics","JipScriptLinkProbeMode",0,ini);
    if(jipScriptLinkProbeMode>3 || (jipScriptLinkProbeMode && (!wideJipScriptLinks || timerCallbackProbeCommand)))stop("JIP script/link diagnostic mode mismatch");
    if(wideJipScriptLinks && (!wideSaveIdentity || !wideJipAddedVariables))stop("JIP script/link save adapter requires identity and added-variable ownership");
    wideShowOffTimers=GetPrivateProfileIntA("Diagnostics","WideShowOffTimers",0,ini)==1;
    timerRestoreOnly=GetPrivateProfileIntA("Diagnostics","TimerRestoreOnly",0,ini)==1;
    timerInstallAfterMenu=GetPrivateProfileIntA("Diagnostics","TimerInstallAfterMenu",0,ini)==1;
    timerInstallAfterPluginLoad=GetPrivateProfileIntA("Diagnostics","TimerInstallAfterPluginLoad",1,ini)==1;
    traceOverflow=GetPrivateProfileIntA("Diagnostics","TraceStackOverflow",0,ini)==1;
    traceStewieLocale=GetPrivateProfileIntA("Diagnostics","TraceStewieLocale",0,ini)==1;
    wideVoiceIds=GetPrivateProfileIntA("Diagnostics","WideVoiceIds",0,ini)==1;
    traceDialogueResults=GetPrivateProfileIntA("Diagnostics","TraceDialogueResults",0,ini)==1;
    if(traceOverflow || traceStewieLocale) {
        std::string capture=std::string(path)+".overflow.bin";
        overflowFile=CreateFileA(capture.c_str(),GENERIC_WRITE,FILE_SHARE_READ,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
        if(overflowFile==INVALID_HANDLE_VALUE)return false;
    }
    commands=(WideCommandTable*)n->QueryInterface(3);scripts=(WideScriptInterface*)n->QueryInterface(6);
    // These are xNVSE APIs. Core array/string ownership must not depend on a
    // JIP diagnostic command or the presence of SUP's HUD plugin.
    if(jipValuesProbeCommand || traceCoreArrays || traceWideStrings || traceArrayOwners || traceStringOwners ||
       wideArraySave || wideArrayLoad || wideStringSave || wideStringLoad){
        jipProbeStrings=(JipProbeStringApi*)n->QueryInterface(4);jipProbeArrays=(JipProbeArrayApi*)n->QueryInterface(5);
        if(!jipProbeStrings || jipProbeStrings->version<1 || !jipProbeArrays)return false;
        for(auto pointer:{(void*)jipProbeStrings->get,(void*)jipProbeStrings->set,(void*)jipProbeStrings->create,(void*)jipProbeArrays->create,(void*)jipProbeArrays->size}){
            HMODULE provider=nullptr;DWORD flags=GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT;
            if(!pointer || !GetModuleHandleExA(flags,(LPCSTR)pointer,&provider) || provider!=GetModuleHandleA("nvse_1_4.dll"))return false;
        }
    }
    if(supHudProbeCommand) {
        if(!supWideHudOwners || !commands || !scripts)return false;
        auto* parser=commands->getName("GetNumLoadedMods");auto* occupiedCommand=commands->getOpcode(0x7F01);
        if(!parser || !parser->parse || commands->getName(supHudProbe.longName) || (occupiedCommand && occupiedCommand->longName && occupiedCommand->longName[0]))return false;
        supHudProbe.parse=parser->parse;n->SetOpcodeBase(0x7F01);
        supProbeApi=(SupProbeScriptApi*)scripts;
        HMODULE callModule=nullptr,compileModule=nullptr;
        DWORD flags=GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT;
        if(!supProbeApi->call || !supProbeApi->expression ||
           !GetModuleHandleExA(flags,(LPCSTR)supProbeApi->call,&callModule) ||
           !GetModuleHandleExA(flags,(LPCSTR)supProbeApi->expression,&compileModule) ||
           callModule!=GetModuleHandleA("nvse_1_4.dll") || compileModule!=callModule)return false;
        if(!n->RegisterTypedCommand(&supHudProbe,0))return false;
    }
    if(showOffRandomProbeCommand) {
        if(!showOffRandomOwners || !supHudProbeCommand || !supProbeApi || !commands)return false;
        auto* parser=commands->getName("GetNumLoadedMods");auto* occupied=commands->getOpcode(0x7F02);
        if(!parser || !parser->parse || commands->getName(showOffRandomProbe.longName) || (occupied && occupied->longName && occupied->longName[0]))return false;
        showOffRandomProbe.parse=parser->parse;n->SetOpcodeBase(0x7F02);if(!n->RegisterTypedCommand(&showOffRandomProbe,0))return false;
    }
    auto* msg=(Messaging*)n->QueryInterface(2);
    reloadConsole=(ReloadConsole*)n->QueryInterface(1);
    if(jipPrivateMapsProbeCommand){
        if(!wideJipPrivateMaps || !supHudProbeCommand || !supProbeApi || !commands)return false;
        auto* parser=commands->getName("GetNumLoadedMods");auto* occupied=commands->getOpcode(0x7F03);
        if(!parser || !parser->parse || commands->getName(jipMapProbe.longName) || (occupied && occupied->longName && occupied->longName[0]))return false;
        jipMapProbe.parse=parser->parse;n->SetOpcodeBase(0x7F03);if(!n->RegisterTypedCommand(&jipMapProbe,0))return false;
    }
    if(jipValuesProbeCommand){
        if(!wideJipPrivateMaps || !supHudProbeCommand || !supProbeApi || !commands)return false;
        auto* parser=commands->getName("GetNumLoadedMods");auto* occupied=commands->getOpcode(0x7F04);
        if(!parser || !parser->parse || commands->getName(jipValuesProbe.longName) || (occupied && occupied->longName && occupied->longName[0]))return false;
        jipValuesProbe.parse=parser->parse;n->SetOpcodeBase(0x7F04);if(!n->RegisterTypedCommand(&jipValuesProbe,0))return false;
    }
    if(jipDialogueCaptureCommand){
        if(!wideJipPrivateMaps || !supHudProbeCommand || !supProbeApi || !supProbeApi->compile || !commands)return false;
        auto* parser=commands->getName("GetNumLoadedMods");auto* occupied=commands->getOpcode(0x7F05);
        if(!parser || !parser->parse || commands->getName(jipDialogueCapture.longName) || (occupied && occupied->longName && occupied->longName[0]))return false;
        jipDialogueCapture.parse=parser->parse;n->SetOpcodeBase(0x7F05);if(!n->RegisterTypedCommand(&jipDialogueCapture,0))return false;
    }
    if(jipDialogueProbeCommand){
        if(!wideJipPrivateMaps || !jipValuesProbeCommand || !supProbeApi || !jipProbeStrings || !commands)return false;
        auto* parser=commands->getName("GetNumLoadedMods");auto* occupied=commands->getOpcode(0x7F06);
        if(!parser || !parser->parse || commands->getName(jipDialogueProbe.longName) || (occupied && occupied->longName && occupied->longName[0]))return false;
        jipDialogueProbe.parse=parser->parse;n->SetOpcodeBase(0x7F06);if(!n->RegisterTypedCommand(&jipDialogueProbe,0))return false;
    }
    if(wideSaveProbeCommands){
        if(!wideJipPrivateMaps || !jipValuesProbeCommand || !supProbeApi || !jipProbeStrings || !commands)return false;
        auto* parser=commands->getName("GetNumLoadedMods");if(!parser || !parser->parse)return false;
        WideCommandInfo* probes[]={&wideSavePrepare,&wideSaveCheck};
        for(uint32_t i=0;i<2;++i){auto* occupied=commands->getOpcode(0x7F07+i);if(commands->getName(probes[i]->longName) || (occupied && occupied->longName && occupied->longName[0]))return false;}
        for(uint32_t i=0;i<2;++i){probes[i]->parse=parser->parse;n->SetOpcodeBase(0x7F07+i);if(!n->RegisterTypedCommand(probes[i],0))return false;}
    }
    if(persistentArrayProbeCommand){
        if(!jipValuesProbeCommand || !jipProbeArrays || !commands)return false;
        auto* parser=commands->getName("GetNumLoadedMods");auto* occupied=commands->getOpcode(0x7F0A);
        if(!parser || !parser->parse || commands->getName(persistentArrayCheck.longName) || (occupied && occupied->longName && occupied->longName[0]))return false;
        persistentArrayCheck.parse=parser->parse;n->SetOpcodeBase(0x7F0A);if(!n->RegisterTypedCommand(&persistentArrayCheck,0))return false;
    }
    if(combinedProbeCommand){
        if(!wideJipAddedVariables || !persistentArrayProbeCommand || !showOffRandomProbeCommand || !jipValuesProbeCommand || !supProbeApi || !supProbeApi->compile)return false;
        auto* parser=commands->getName("GetNumLoadedMods");auto* occupied=commands->getOpcode(0x7F0B);
        if(!parser || !parser->parse || commands->getName(combinedCompatibilityProbe.longName) || (occupied && occupied->longName && occupied->longName[0]))return false;
        combinedCompatibilityProbe.parse=parser->parse;n->SetOpcodeBase(0x7F0B);if(!n->RegisterTypedCommand(&combinedCompatibilityProbe,0))return false;
    }
    if(timerCallbackProbeCommand){
        if(!combinedProbeCommand || !wideShowOffTimers || !supProbeApi || !supProbeApi->compile)return false;
        // Route this diagnostic through the already registered 7F0B command.
        // Six callbacks dispatch by their exact session-owned script pointers.
    }
    if(wideSaveIdentity){
        if(!commands)return false;
        auto* parser=commands->getName("GetNumLoadedMods");auto* occupiedCommand=commands->getOpcode(0x7F09);
        if(!parser || !parser->parse || commands->getName(wideIdentityCheck.longName) || (occupiedCommand && occupiedCommand->longName && occupiedCommand->longName[0]))return false;
        saveSerialization=(WideSerialization*)n->QueryInterface(0);
        if(!saveSerialization || saveSerialization->version<2 || !saveSerialization->setSave || !saveSerialization->setLoad || !saveSerialization->setNewGame || !saveSerialization->setPreLoad || !saveSerialization->writeRecord || !saveSerialization->nextRecord || !saveSerialization->readData)return false;
        wideIdentityCheck.parse=parser->parse;n->SetOpcodeBase(0x7F09);if(!n->RegisterTypedCommand(&wideIdentityCheck,0))return false;
        uint32_t plugin=n->GetPluginHandle();saveSerialization->setSave(plugin,writeSaveIdentity);saveSerialization->setLoad(plugin,loadSaveIdentity);saveSerialization->setPreLoad(plugin,preloadSaveIdentity);saveSerialization->setNewGame(plugin,resetSaveIdentity);
        fputs("WIDE_SAVE_IDENTITY_CALLBACKS_REGISTERED version=1 record=WIDM values=not_migrated\n",logFile);fflush(logFile);
    }
    return msg && msg->version>=4 && msg->RegisterListener(n->GetPluginHandle(),"NVSE",onMessage);
}
