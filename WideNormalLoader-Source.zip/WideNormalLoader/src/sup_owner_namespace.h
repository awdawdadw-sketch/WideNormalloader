#pragma once
#include <cstdint>
#include <unordered_map>
#include <vector>

// Loader-owned storage only. Never exchange these C++ containers with supNVSE.
// This foundation is not an installed hook: every command producer, native
// export boundary and owner/name consumer must agree before enabling adapters.
namespace wide {
enum class SupOwnerKind : uint8_t { LegacyPlugin, ExtendedPlugin, NativeCustom, Console };
struct SupOwnerKey {
    SupOwnerKind kind;
    uint32_t value;
    bool operator==(const SupOwnerKey& other) const {
        return kind == other.kind && value == other.value;
    }
};
struct SupOwnerHash {
    size_t operator()(const SupOwnerKey& key) const {
        return std::hash<uint64_t>{}((uint64_t(key.kind) << 32) | key.value);
    }
};

class SupOwnerNamespace {
    uint32_t extendedCapacity;
    std::unordered_map<SupOwnerKey, uint32_t, SupOwnerHash> tokens;
    std::vector<SupOwnerKey> identities;
    bool allocate(SupOwnerKey key, uint32_t& token) {
        auto found = tokens.find(key);
        if (found != tokens.end()) { token = found->second; return true; }
        // Reserve FFFFFFFF for uninitialized/invalid internal fields. Never
        // turn failed ownership resolution into sup's FF wildcard lookup.
        if (identities.size() >= uint64_t(UINT32_MAX) - 256) return false;
        const uint32_t next = 256 + uint32_t(identities.size());
        identities.push_back(key);
        try { tokens.emplace(key, next); }
        catch (...) { identities.pop_back(); throw; }
        token = next;
        return true;
    }
public:
    explicit SupOwnerNamespace(uint32_t capacity = 1024 - 253) : extendedCapacity(capacity) {}

    // Script APIs use the loader's existing 00..FC / FF / 256+extended-owner
    // contract. Convert that contract to an internal SUP token, not an index.
    bool scriptOwner(uint32_t external, uint32_t& token) {
        if (external < 253 || external == 255) { token = external; return true; }
        if (external < 256 || external - 256 >= extendedCapacity) return false;
        return allocate({SupOwnerKind::ExtendedPlugin, external - 256}, token);
    }

    // Native exports accept numeric custom owners independently of script
    // plugin tokens. A raw native 1000 must not alias script token 1000.
    // Preserve legacy and Console conventions, including the FF wildcard.
    bool nativeOwner(uint32_t external, uint32_t& token) {
        if (external < 253 || external == 255) { token = external; return true; }
        return allocate({SupOwnerKind::NativeCustom, external}, token);
    }

    // Returns a value copy, avoiding references invalidated by vector growth.
    bool identity(uint32_t token, SupOwnerKey& key) const {
        if (token < 253) { key = {SupOwnerKind::LegacyPlugin, token}; return true; }
        if (token == 255) { key = {SupOwnerKind::Console, 0}; return true; }
        if (token < 256 || uint64_t(token - 256) >= identities.size()) return false;
        key = identities[token - 256];
        return true;
    }
};
} // namespace wide
