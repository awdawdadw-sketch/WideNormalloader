#pragma once
#include "sup_owner_namespace.h"
#include <cstring>
#include <string>

namespace wide {
// Installed creation formats %s_%d into a 0x4000-byte local buffer. Native
// identities retain that signed-decimal suffix. The extended suffix cannot be
// produced by that format, even if a native client's base name contains @wide.
inline bool supHudIdentifier(const SupOwnerKey& identity,const std::string& base,std::string& out) {
    std::string suffix;
    switch (identity.kind) {
    case SupOwnerKind::LegacyPlugin:
        if (identity.value>=253) return false;
        suffix="_"+std::to_string(identity.value); break;
    case SupOwnerKind::Console:
        if (identity.value!=0) return false;
        suffix="_255"; break;
    case SupOwnerKind::ExtendedPlugin:
        suffix="_@wide"+std::to_string(identity.value); break;
    case SupOwnerKind::NativeCustom: {
        if (identity.value<253 || identity.value==255) return false;
        int32_t signedOwner; std::memcpy(&signedOwner,&identity.value,4);
        suffix="_"+std::to_string(signedOwner); break;
    }
    default: return false;
    }
    if (base.find('\0')!=std::string::npos || base.size()>0x3FFF || suffix.size()>0x3FFF-base.size()) return false;
    out=base+suffix; return true;
}

// Registry-owned filename callback: legacy value is its legacy slot; extended
// value is its zero-based extended owner. No foreign C++ string is exchanged.
using SupFilenameLookup=const char*(*)(SupOwnerKind,uint32_t,void*);
inline const char* supHudOwnerName(const SupOwnerKey& identity,SupFilenameLookup lookup,void* context) {
    switch(identity.kind) {
    case SupOwnerKind::LegacyPlugin:
        if (identity.value>=253) return nullptr;
        return lookup ? lookup(identity.kind,identity.value,context) : nullptr;
    case SupOwnerKind::ExtendedPlugin:
        return lookup ? lookup(identity.kind,identity.value,context) : nullptr;
    case SupOwnerKind::Console:
        return identity.value==0 ? "Console" : nullptr;
    case SupOwnerKind::NativeCustom:
        if (identity.value<253 || identity.value==255) return nullptr;
        // Installed 2F458 uses unsigned JB. Values with their sign bit set
        // still name CustomPlugin. Other raw IDs are outside the bounded
        // legacy list and retain the empty-name behavior after loading.
        return identity.value>=1000 ? "CustomPlugin" : "";
    default: return nullptr;
    }
}
} // namespace wide
