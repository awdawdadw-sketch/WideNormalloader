#pragma once
#include <stdint.h>
#include <string.h>

// Runtime handles are opaque. Never extract an owner by shifting a handle.
// Canonical keys retain the entire existing ESP/ESM 24-bit local namespace.
struct CanonicalKey { uint32_t plugin; uint32_t local; };
struct WideEntry { CanonicalKey key; uint32_t handle; void* form; };
class WideRegistry {
public:
    static constexpr uint32_t capacity = 4096;
    WideEntry entries[capacity]{};
    uint32_t count = 0, next = 0xFD800000;
    using Occupied = bool (*)(uint32_t);
    WideEntry* find(CanonicalKey k) {
        for (uint32_t i=0;i<count;i++)
            if (entries[i].key.plugin==k.plugin && entries[i].key.local==k.local) return &entries[i];
        return nullptr;
    }
    WideEntry* reverse(uint32_t handle) {
        for (uint32_t i=0;i<count;i++) if (entries[i].handle==handle) return &entries[i];
        return nullptr;
    }
    WideEntry* intern(CanonicalKey k, Occupied occupied) {
        if (k.plugin>=1024 || k.local<0x800 || k.local>0xFFFFFF) return nullptr;
        if (auto* e=find(k)) return e;
        if (count==capacity) return nullptr;
        // A small experiment pool, NOT a permanent reservation in the engine.
        while (next<0xFD810000 && occupied && occupied(next)) ++next;
        if (next>=0xFD810000) return nullptr;
        auto* e=&entries[count++]; *e={k,next++,nullptr}; return e;
    }
};

struct FixtureGlobal { uint32_t local; float value; char editorID[80]; };
static inline uint16_t u16(const unsigned char* p) { return uint16_t(p[0]) | uint16_t(p[1])<<8; }
static inline uint32_t u32(const unsigned char* p) { return uint32_t(p[0]) | uint32_t(p[1])<<8 | uint32_t(p[2])<<16 | uint32_t(p[3])<<24; }

// Deliberately strict fixture importer: one FalloutNV.esm master, one GLOB group,
// three uncompressed self-owned float globals. Arbitrary plugins are rejected.
static inline bool parseFixture(const unsigned char* b, uint32_t n, FixtureGlobal (&out)[3]) {
    if (n<48 || memcmp(b,"TES4",4) || u32(b+8) || u32(b+12)) return false;
    uint32_t h=u32(b+4); if(h>n-24) return false;
    uint32_t p=24,end=24+h, masters=0; bool hedr=false,masterData=false;
    while(p<end) {
        if(end-p<6) return false;
        auto* tag=b+p; uint32_t s=u16(b+p+4); p+=6; if(s>end-p) return false;
        if(!memcmp(tag,"HEDR",4)) { if(hedr || s!=12 || u32(b+p+4)!=3) return false; hedr=true; }
        else if(!memcmp(tag,"MAST",4)) { if(masters++ || s!=14 || memcmp(b+p,"FalloutNV.esm\0",14)) return false; }
        else if(!memcmp(tag,"DATA",4)) { if(masters!=1 || masterData || s!=8) return false; masterData=true; }
        else if(memcmp(tag,"CNAM",4)) return false;
        p+=s;
    }
    if(!hedr || masters!=1 || !masterData || n-p<24 || memcmp(b+p,"GRUP",4) || u32(b+p+4)!=n-p || memcmp(b+p+8,"GLOB",4) || u32(b+p+12)) return false;
    p+=24;
    for(unsigned i=0;i<3;i++) {
        if(n-p<24 || memcmp(b+p,"GLOB",4) || u32(b+p+8)) return false;
        uint32_t s=u32(b+p+4), id=u32(b+p+12); if(s>n-p-24 || (id>>24)!=1 || (id&0xFFFFFF)<0x800) return false;
        out[i]={}; out[i].local=id&0xFFFFFF; p+=24; end=p+s;
        bool edid=false,fnam=false,value=false;
        while(p<end) {
            if(end-p<6) return false;
            auto* tag=b+p; s=u16(b+p+4); p+=6; if(s>end-p) return false;
            if(!memcmp(tag,"EDID",4)) { if(edid || s<2 || s>80 || b[p+s-1]) return false; memcpy(out[i].editorID,b+p,s); edid=true; }
            else if(!memcmp(tag,"FNAM",4)) { if(fnam || s!=1 || b[p]!='f') return false; fnam=true; }
            else if(!memcmp(tag,"FLTV",4)) { if(value || s!=4) return false; memcpy(&out[i].value,b+p,4); value=true; }
            else return false;
            p+=s;
        }
        if(!edid || !fnam || !value) return false;
        for(unsigned j=0;j<i;j++) if(out[j].local==out[i].local) return false;
    }
    return p==n;
}
