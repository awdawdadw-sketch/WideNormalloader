#pragma once
#include <stddef.h>
#define WIDE_COMMAND_ARGS void* params,void* scriptData,void* thisObj,void* containingObj,void* scriptObj,void* eventList,double* result,uint32_t* offset
#define WIDE_PASS_ARGS params,scriptData,thisObj,containingObj,scriptObj,eventList,result,offset
using CommandExecute=bool(__cdecl*)(WIDE_COMMAND_ARGS);
struct WideCommandInfo {
    const char* longName;const char* shortName;uint32_t opcode;const char* help;
    uint16_t needsParent,numParams;void* params;
    CommandExecute execute;void* parse;void* eval;uint32_t flags;
};
static_assert(sizeof(WideCommandInfo)==0x28 && offsetof(WideCommandInfo,execute)==0x18,"xNVSE command ABI");
struct WideCommandTable {
    uint32_t version;const WideCommandInfo* (__cdecl *start)();const WideCommandInfo* (__cdecl *end)();
    const WideCommandInfo* (__cdecl *getOpcode)(uint32_t);const WideCommandInfo* (__cdecl *getName)(const char*);
    uint32_t (__cdecl *getReturnType)(const WideCommandInfo*);uint32_t (__cdecl *getRequiredVersion)(const WideCommandInfo*);
    const PluginInfo* (__cdecl *getParent)(const WideCommandInfo*);
};
// This interface starts with function pointers, NOT a version DWORD.
struct WideScriptInterface {
    void* callFunction;void* getFunctionParams;
    bool (__cdecl *extract)(void*,void*,uint32_t*,void*,void*,...);
};
