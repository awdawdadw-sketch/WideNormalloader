#pragma once
#include <cstddef>
// Controlled inputs for the pinned evaluator. It reads only the quest's +1C
// script and +5C locals pointers; GetVariable walks locals+0C, node+0/+4 and
// variable+0/+8. These are diagnostic inputs, not constructed engine quests.
struct alignas(8) JipConditionVariable {uint32_t id,unused;double number;uint8_t type,padding[7];};
struct JipConditionNode {JipConditionVariable* variable;JipConditionNode* next;};
struct JipConditionLocals {void* script;uint32_t flags;void* events;JipConditionNode* variables;void* effects;};
struct JipConditionQuestInput {uint8_t prefix[0x1c];void* script;uint8_t middle[0x3c];JipConditionLocals* locals;};
static_assert(offsetof(JipConditionVariable,number)==8 && sizeof(JipConditionVariable)==24,"JIP ScriptVar subset ABI");
static_assert(offsetof(JipConditionLocals,variables)==0xc,"JIP ScriptLocals subset ABI");
static_assert(offsetof(JipConditionQuestInput,script)==0x1c && offsetof(JipConditionQuestInput,locals)==0x5c,"JIP TESQuest read subset ABI");
