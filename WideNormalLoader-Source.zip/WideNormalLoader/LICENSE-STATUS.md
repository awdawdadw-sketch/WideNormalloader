# License status and upstream references

No project-wide license was specified for this work. This export does not invent a copyright holder, select an open-source license, or relicense any upstream material. Before public release, the repository owner should choose and document the project's license and preserve any applicable upstream notices. Uploading source by itself does not provide a reuse license.

This archive contains the maintained loader source, selected tests, generic configuration and build/package scripts. It excludes upstream source repositories, DLLs, PDBs, game files and developer dependencies. Adapter manifests contain audited machine-code signatures and interface/layout declarations used for compatibility checks.

Upstream projects consulted during implementation include:

- xNVSE: https://github.com/xNVSE/NVSE
- Original JIP LN: https://github.com/jazzisparis/JIP-LN-NVSE
- JIP PP LN: https://github.com/Pistol-Payback/JIP-PP-LN

Upstream repositories retain their own licenses. This file is a provenance note, not a replacement for those licenses or a determination of their application to this project.
