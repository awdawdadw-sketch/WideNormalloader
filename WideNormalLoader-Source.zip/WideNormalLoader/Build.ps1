param(
    [string]$ZigPath = 'zig',
    [switch]$RunTests,
    [string]$OriginalJipDll = '',
    [string]$JipPPDll = ''
)
$ErrorActionPreference = 'Stop'
$repoDir = $PSScriptRoot
$buildDir = Join-Path $repoDir 'build'
New-Item -ItemType Directory -Path $buildDir -Force | Out-Null
$env:ZIG_LOCAL_CACHE_DIR = Join-Path $buildDir 'zig-cache'
$common = @('-target', 'x86-windows-gnu', '-O2', '-std=c++17', '-fno-omit-frame-pointer')
function Invoke-Zig([string[]]$CompilerArguments) {
    & $ZigPath @CompilerArguments
    if ($LASTEXITCODE -ne 0) { throw "Compiler failed with exit code $LASTEXITCODE" }
}
Invoke-Zig (@('c++', (Join-Path $repoDir 'src/normal_loader.cpp')) + $common + @('-shared', '-ladvapi32', '-luser32', '-lshell32', '-lole32', '-o', (Join-Path $buildDir 'WideNormalLoader.dll')))
Write-Host 'Built build/WideNormalLoader.dll'
if ($RunTests) {
    $testDir = Join-Path $buildDir 'tests'
    New-Item -ItemType Directory -Path $testDir -Force | Out-Null
    function Invoke-Test([string]$Name, [string[]]$Defines = @(), [string]$Suffix = '', [string[]]$RunArguments = @()) {
        $exePath = Join-Path $testDir ($Name + $Suffix + '.exe')
        Invoke-Zig (@('c++', (Join-Path $repoDir ('tests/' + $Name + '.cpp'))) + $common + $Defines + @('-ladvapi32', '-luser32', '-lshell32', '-lole32', '-o', $exePath))
        & $exePath @RunArguments
        if ($LASTEXITCODE -ne 0) { throw "$Name$Suffix failed with exit code $LASTEXITCODE" }
        Write-Host "PASS $Name$Suffix"
    }
    foreach ($profile in @('original', 'pp')) {
        $defines = @()
        if ($profile -eq 'pp') { $defines = @('-DWIDE_JIP_PP_PROFILE') }
        foreach ($name in @('jip_profiles_private_maps_tests', 'jip_profiles_added_variables_bridge_tests', 'test_jip_profiles_link_owners', 'test_jip_profiles_script_link')) {
            Invoke-Test -Name $name -Defines $defines -Suffix ('-' + $profile)
        }
    }
    Invoke-Test -Name 'test_startup_preflight'
    Invoke-Test -Name 'test_fault_report'
    Invoke-Test -Name 'test_timer_bridges' -Defines @('-DWIDE_TIMER_RUNTIME_TEST', '-DWIDE_UPDATED_OPTIONAL')
    if ($OriginalJipDll -and $JipPPDll) {
        Invoke-Test -Name 'test_jip_profiles_binary' -Suffix '-original' -RunArguments @('original', $OriginalJipDll)
        Invoke-Test -Name 'test_jip_profiles_binary' -Suffix '-pp' -RunArguments @('pp', $JipPPDll)
    } elseif ($OriginalJipDll -or $JipPPDll) {
        throw 'Supply both OriginalJipDll and JipPPDll for binary-image checks.'
    }
}
