# WideNormalLoader

Experimental native xNVSE plugin for Fallout: New Vegas with an explicit load order of up to **1,024 ESP/ESM files**.

This source export corresponds to the 2026-10-08 manual package with original JIP/JIP PP LN detection, ShowOff timer installation after engine plugin loading, native startup checks and fault reports. It is C++17, compiled as a 32-bit Windows DLL; it is not an xNVSE script.

## Features

- Preserves existing ESP/ESM files and their full local FormIDs. Keeps canonical plugin/local identities in a registry and assigns runtime handles for extended owners.
- Retains a bounded legacy loaded-file view for extensions while the loader maintains the complete selected-file table.
- Adapts identified engine and xNVSE paths that otherwise assume byte-sized owners.
- Detects optional JIP LN, JIP PP LN 57.54, SUP, ShowOff and Stewie DLLs; selects audited build profiles and checks hook signatures before patching.
- Checks plugin files, masters, explicit order, xNVSE caching settings and supported binaries at startup. Changes to the reviewed modlist require acknowledgement.
- Records first-chance hardware faults and deliberate loader stops without suppressing Windows or Crash Logger handling.

## Getting started

See [BUILD.md](BUILD.md) to build and test, [INSTALL.txt](INSTALL.txt) to install the resulting mod, and [docs/COMPATIBILITY.md](docs/COMPATIBILITY.md) for supported builds and test limits.

The game and audited xNVSE 6.4.9 are the runtime requirements. Optional native mods are not required, but their features may need adapters when those mods are installed. Other native DLLs can retain incompatible assumptions. This is not a universal fix for every mod or save.

`config/NVSE/Plugins/WideNormalLoader-order.txt` is a vanilla/DLC template. Users must supply their own selection. No personal modlist, dummy plugins, game binaries, upstream DLLs, savegames or developer toolchain is included.

## Source layout

- `src/normal_loader.cpp`: plugin entrypoints, engine hooks, runtime identity and save integration.
- `src/jip_build_profile.h`, `src/jip_pp_private_map_sites.h`: distinct original/PP JIP address profiles and owner transfer sites.
- `src/*runtime.h`: optional native adapters and checked x86 bridges.
- `src/startup_preflight.h`: native startup checks and baseline review.
- `src/fault_report.h`: bounded hardware fault observations and deliberate-stop reports.
- `src/*codec.h`, `src/*tracker.h`: identity serialization and ownership bookkeeping.
- `tests/`: selected offline tests; real game validation remains separate.
- `config/`: generic manual-install configuration.

Before publishing, see [LICENSE-STATUS.md](LICENSE-STATUS.md). This export does not choose a project license on the author's behalf.
