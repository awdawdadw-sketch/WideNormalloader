$ErrorActionPreference = 'Stop'
$repoDir = $PSScriptRoot
$dllPath = Join-Path $repoDir 'build/WideNormalLoader.dll'
if (-not (Test-Path -LiteralPath $dllPath)) { throw 'Build the DLL with Build.ps1 first.' }
$distDir = Join-Path $repoDir 'dist'
New-Item -ItemType Directory -Path $distDir -Force | Out-Null
# Unique staging avoids deleting or overwriting someone else's working folder.
$stageDir = Join-Path $distDir ('manual-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $stageDir | Out-Null
Copy-Item -LiteralPath (Join-Path $repoDir 'config/NVSE') -Destination $stageDir -Recurse
Copy-Item -LiteralPath $dllPath -Destination (Join-Path $stageDir 'NVSE/Plugins/WideNormalLoader.dll')
Copy-Item -LiteralPath (Join-Path $repoDir 'INSTALL.txt') -Destination (Join-Path $stageDir 'README.txt')
$zipPath = Join-Path $distDir 'WideNormalLoader-Manual.zip'
Compress-Archive -Path (Join-Path $stageDir 'NVSE'), (Join-Path $stageDir 'README.txt') -DestinationPath $zipPath -Force
Get-FileHash -LiteralPath $zipPath -Algorithm SHA256 | Format-List
Write-Host "Manual ZIP created: $zipPath"
Write-Host "Packaging staging folder retained: $stageDir"
