# Compatibility and verification

## Audited binaries

Selection uses loaded DLL names and exact SHA256 fingerprints, followed by hook checks. The optional mods are external dependencies only when installed; their binaries and sources are not bundled.

| Component | SHA256 |
|---|---|
| FalloutNV.exe | `518c87f58a6c4d9826e9ef8fbb7f4213882fa70822675610d45aea2464502a57` |
| xNVSE 6.4.9 nvse_1_4.dll | `e82c5d348bac255a8ff4cf477df2e48149304b18f02b42b2a835c3cba71f3dfb` |
| Original JIP jip_nvse.dll | `9d2779647ed0ce63043390f47fc978e3234af8e558dc6cb6bcb231478a2d74d4` |
| JIP PP LN 57.54 jip_nvse.dll | `348c834fafd8af7b081fef20aef3d8c38308fbaaee6573ef17d84b5c3863ba2b` |
| SUP supNVSE.dll | `61b0f1760a643ee749c785bf989f22b18f7b445891d2595f55445281c8a22e6c` |
| ShowOffNVSE.dll | `37cb22c5288fedd0d57196c8c2f6bbaba5a1dafd9ce58f14dac9410dbee7ef3e` |
| Stewie nvse_stewie_tweaks.dll | `c19007b47f39df2ce07cfc1add1a27090302cf35e1673ba35bee61cb5800db95` |

The reference manual-package loader DLL has SHA256 `7352a6baa02f4871bfbf92c0d075f4ab52356249b29b53e271c75b8c8adf37a3`.

## What passed

- Local user testing reached gameplay with 1,024 selected plugins.
- Original and PP JIP profiles passed eight optimized x86 synthetic checks covering owner transfer, added variables, linked-reference retention, script/link snapshots and legacy/public save filtering.
- Both JIP binaries passed hook checks in relocated PE copies without invoking their entrypoints or native helpers.
- The PP DLL's supplied PDB GUID/age and relevant ownership/value structure layouts were verified.
- ShowOff bridge checks passed 208 x86 calls across 13 spans, including empty-map rejection, relocation handling and rollback.
- Fault reporting passed main/worker-thread observations and downstream handler recovery checks.
- Startup parser and baseline tests passed.
- The earlier ShowOff installation point passed the local gameplay run with JIP PP LN.

## What remains unverified

JIP PP LN live saved-data restoration was skipped at the user's request. Existing xNVSE 6.4.9 array save/reorder limitations remain; do not infer arbitrary save migration or plugin removal support. A successful local gameplay run does not establish support for every modlist, DLL revision, feature or long session.

The loader does not expand an individual ESP/ESM's master-selector width. Other native DLLs can retain 8-bit plugin assumptions. Unsupported optional builds are skipped with a warning and remain loaded; that can still cause failure. Fault logs identify observation locations, not definitive root causes.

Only the maintained normal-loader implementation is exported. Historical prototypes, personal diagnostics and generated test plugin sets are omitted. Swanick reload compatibility is removed.
